# e-Institution

A school management prototype with separate portals for higher authority, teachers, and parents.

## Requirements
- Node.js (LTS)
- npm

## Run locally
1. Extract the project folder.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the development server:

   ```bash
   npm run dev
   ```

5. Open the local address shown in the terminal.

## Useful commands
- `npm run dev` — start the development server
- `npm run build` — create a production build
- `npm run preview` — preview the production build
- `npm run lint` — check TypeScript types

## Project layout
- `src/portals/` — authority, teacher, and parent portal screens
- `src/pages/` — shared pages and navigation
- `src/components/` — reusable interface components
- `src/services/` — browser-side storage helpers
- `src/utils/` — attendance calculations and related helpers
- `public` assets are not used; the app's manifest and service worker are in the project root.

## Current limitations
This project is a frontend prototype. Its shared data is stored in the browser, not in a hosted database. Different devices and browsers do not automatically share changes. Browser storage is not a substitute for secure user accounts or server-side access control. The service worker and offline behavior should be tested after deployment over HTTPS.
