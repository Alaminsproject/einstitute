import {
  AppSettings,
  ClassRoom,
  Homework,
  Notice,
  ParentGuardian,
  School,
  Student,
  StudentAttendanceRecord,
  Teacher,
  TeacherAttendanceRecord,
  LocationData,
  LeaveApplication,
  DismissalNotice,
  Message,
  AttendanceStatus,
} from '../types';

const STORAGE_KEYS = {
  TEACHERS: 'einst_teachers_v2',
  SCHOOLS: 'einst_schools_v2',
  TEACHER_ATTENDANCE: 'einst_teacher_attendance_v2',
  STUDENTS: 'einst_students_v2',
  PARENTS: 'einst_parents_v2',
  CLASSES: 'einst_classes_v2',
  HOMEWORK: 'einst_homework_v2',
  NOTICES: 'einst_notices_v2',
  STUDENT_ATTENDANCE: 'einst_student_attendance_v2',
  LEAVE_APPLICATIONS: 'einst_leave_applications_v1',
  DISMISSAL_NOTICES: 'einst_dismissal_notices_v1',
  MESSAGES: 'einst_messages_v1',
  SETTINGS: 'einst_settings_v2',
};

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatTime12h(date = new Date()): string {
  let hours = date.getHours();
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  return `${String(hours).padStart(2, '0')}:${minutes} ${ampm}`;
}

// 1. Initial Schools
export const INITIAL_SCHOOLS: School[] = [
  {
    id: 'SCH-01',
    name: 'Chatkhil Panchgaon Mahbub Government College',
    nameBn: 'চাটখিল পাঁচগাঁও মাহবুব সরকারি কলেজ',
    eiin: '112450',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Higher Secondary College',
    status: 'active',
    contactPhone: '01712-345670',
    address: 'Chatkhil, Noakhali',
    establishedYear: 1968,
  },
  {
    id: 'SCH-02',
    name: 'Chatkhil PG Government High School',
    nameBn: 'চাটখিল পিজি সরকারি উচ্চ বিদ্যালয়',
    eiin: '112451',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Secondary High School',
    status: 'active',
    contactPhone: '01819-876541',
    address: 'Chatkhil, Noakhali',
    establishedYear: 1984,
  },
  {
    id: 'SCH-03',
    name: 'Bhimpur ML School',
    nameBn: 'ভীমপুর এমএল হাই স্কুল',
    eiin: '112452',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Higher Secondary College',
    status: 'active',
    contactPhone: '01914-554433',
    address: 'Chatkhil, Noakhali',
    establishedYear: 1995,
  },
  {
    id: 'SCH-04',
    name: "Chatkhil Government Girls School",
    nameBn: 'চাটখিল সরকারি বালিকা উচ্চ বিদ্যালয়',
    eiin: '112453',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Secondary High School',
    status: 'active',
    contactPhone: '01611-998877',
    address: 'Chatkhil, Noakhali',
    establishedYear: 1991,
  },
  {
    id: 'SCH-05',
    name: "Chatkhil Womens College",
    nameBn: 'চাটখিল মহিলা কলেজ',
    eiin: '112454',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Higher Secondary College',
    status: 'active',
    contactPhone: '01733-112233',
    address: 'Chatkhil, Noakhali',
    establishedYear: 2005,
  },
  {
    id: 'SCH-06',
    name: 'Chatkhil Government Technical School and College',
    nameBn: 'চাটখিল সরকারি টেকনিক্যাল স্কুল ও কলেজ',
    eiin: '112455',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Secondary High School',
    status: 'active',
    contactPhone: '01755-667788',
    address: 'Chatkhil, Noakhali',
    establishedYear: 2001,
  },
];

// 2. Initial Teachers
export const INITIAL_TEACHERS: Teacher[] = [
  {
    id: 'TCH-1001',
    name: 'Mohammad Rafiqul Islam',
    nameBn: 'মোহাম্মদ রফিকুল ইসলাম',
    designation: 'Head Teacher',
    designationBn: 'প্রধান শিক্ষক',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    phone: '01712-340001',
    email: 'rafiqul.head@institution.edu.bd',
    subject: 'Administration & Social Science',
    joinDate: '2012-03-01',
    status: 'active',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 'TCH-1002',
    name: 'Syeda Nusrat Jahan',
    nameBn: 'সৈয়দা নুসরাত জাহান',
    designation: 'Senior Teacher',
    designationBn: 'সিনিয়র শিক্ষক',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    phone: '01815-440002',
    email: 'nusrat.jahan@institution.edu.bd',
    subject: 'Mathematics & Higher Math',
    joinDate: '2016-08-15',
    status: 'active',
  },
  {
    id: 'TCH-1003',
    name: 'Tanvir Ahmed',
    nameBn: 'তানভীর আহমেদ',
    designation: 'Assistant Teacher (ICT)',
    designationBn: 'সহকারী শিক্ষক (আইসিটি)',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    phone: '01918-550003',
    email: 'tanvir.ict@institution.edu.bd',
    subject: 'Information & Communication Technology',
    joinDate: '2020-01-10',
    status: 'active',
  },
  {
    id: 'TCH-1004',
    name: 'Farzana Akter',
    nameBn: 'ফারজানা আক্তার',
    designation: 'Assistant Teacher (English)',
    designationBn: 'সহকারী শিক্ষক (ইংরেজি)',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    phone: '01711-660004',
    email: 'farzana.eng@institution.edu.bd',
    subject: 'English Language & Literature',
    joinDate: '2019-04-20',
    status: 'active',
  },
  {
    id: 'TCH-1005',
    name: 'Abul Kalam Azad',
    nameBn: 'আবুল কালাম আজাদ',
    designation: 'Head Teacher',
    designationBn: 'প্রধান শিক্ষক',
    schoolId: 'SCH-02',
    schoolName: 'Chatkhil PG Government High School',
    phone: '01713-770005',
    email: 'azad.head@institution.edu.bd',
    subject: 'General Science & Administration',
    joinDate: '2014-06-12',
    status: 'active',
  },
  {
    id: 'TCH-1006',
    name: 'Mahmuda Begum',
    nameBn: 'মাহমুদা বেগম',
    designation: 'Senior Teacher',
    designationBn: 'সিনিয়র শিক্ষক',
    schoolId: 'SCH-02',
    schoolName: 'Chatkhil PG Government High School',
    phone: '01817-880006',
    email: 'mahmuda.b@institution.edu.bd',
    subject: 'Bangla First & Second Paper',
    joinDate: '2015-11-01',
    status: 'active',
  },
  {
    id: 'TCH-1007',
    name: 'Kazi Mostafa Kamal',
    nameBn: 'কাজী মোস্তফা কামাল',
    designation: 'Assistant Teacher (Science)',
    designationBn: 'সহকারী শিক্ষক (বিজ্ঞান)',
    schoolId: 'SCH-02',
    schoolName: 'Chatkhil PG Government High School',
    phone: '01920-990007',
    email: 'mostafa.kamal@institution.edu.bd',
    subject: 'Physics & Chemistry',
    joinDate: '2021-02-01',
    status: 'active',
  },
  {
    id: 'TCH-1008',
    name: 'Dr. Mizanur Rahman',
    nameBn: 'ড. মিজানুর রহমান',
    designation: 'Head Teacher',
    designationBn: 'অধ্যক্ষ / প্রধান শিক্ষক',
    schoolId: 'SCH-03',
    schoolName: 'Bhimpur ML School',
    phone: '01714-110008',
    email: 'mizan.principal@institution.edu.bd',
    subject: 'Higher Mathematics',
    joinDate: '2011-09-01',
    status: 'active',
  },
  {
    id: 'TCH-1010',
    name: 'Maulana Azizul Haque',
    nameBn: 'মাওলানা আজিজুল হক',
    designation: 'Head Teacher',
    designationBn: 'সুপারিনটেনডেন্ট',
    schoolId: 'SCH-04',
    schoolName: 'Chatkhil Government Girls School',
    phone: '01715-330010',
    email: 'azizul.super@institution.edu.bd',
    subject: 'Arabic & Islamic Studies',
    joinDate: '2013-02-15',
    status: 'active',
  },
  {
    id: 'TCH-1012',
    name: 'Golam Sarwar',
    nameBn: 'গোলাম সারোয়ার',
    designation: 'Head Teacher',
    designationBn: 'প্রধান শিক্ষক',
    schoolId: 'SCH-05',
    schoolName: 'Chatkhil Womens College',
    phone: '01716-550012',
    email: 'sarwar.head@institution.edu.bd',
    subject: 'Primary Pedagogy & Bangla',
    joinDate: '2015-04-10',
    status: 'active',
  },
];

// 3. Initial Parents / Guardians
export const INITIAL_PARENTS: ParentGuardian[] = [
  {
    id: 'PRN-101',
    name: 'Mrs. Shamima Begum',
    nameBn: 'শামীমা বেগম',
    relation: 'Mother',
    phone: '01722-114455',
    email: 'shamima.b@example.com',
    occupation: 'Government Service',
    address: 'Chatkhil, Noakhali',
    studentIds: ['STD-901'],
  },
  {
    id: 'PRN-102',
    name: 'Engr. Zahirul Islam',
    nameBn: 'প্রকো. জহিরুল ইসলাম',
    relation: 'Father',
    phone: '01833-225566',
    email: 'zahirul.eng@example.com',
    occupation: 'Civil Engineer',
    address: 'Chatkhil, Noakhali',
    studentIds: ['STD-902'],
  },
  {
    id: 'PRN-103',
    name: 'Rokeya Parveen',
    nameBn: 'রোকেয়া পারভীন',
    relation: 'Mother',
    phone: '01944-336677',
    email: 'rokeya.p@example.com',
    occupation: 'Bank Officer',
    address: 'Chatkhil, Noakhali',
    studentIds: ['STD-903'],
  },
  {
    id: 'PRN-104',
    name: 'Al-Haj Abdul Mannan',
    nameBn: 'আলহাজ্ব আব্দুল মান্নান',
    relation: 'Father',
    phone: '01655-447788',
    email: 'mannan.trader@example.com',
    occupation: 'Business Proprietor',
    address: 'Chatkhil, Noakhali',
    studentIds: ['STD-904'],
  },
];

// 4. Initial Students
export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'STD-901',
    name: 'Ayan Ahmed',
    nameBn: 'আয়ান আহমেদ',
    rollNo: '01',
    classId: 'CLS-9A',
    className: 'Class 9',
    section: 'A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    parentId: 'PRN-101',
    parentName: 'Mrs. Shamima Begum',
    parentPhone: '01722-114455',
    gender: 'Male',
    dob: '2011-04-12',
    status: 'active',
    attendanceRate: 95.8,
  },
  {
    id: 'STD-902',
    name: 'Sadia Islam',
    nameBn: 'সাদিয়া ইসলাম',
    rollNo: '02',
    classId: 'CLS-9A',
    className: 'Class 9',
    section: 'A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    parentId: 'PRN-102',
    parentName: 'Engr. Zahirul Islam',
    parentPhone: '01833-225566',
    gender: 'Female',
    dob: '2011-08-23',
    status: 'active',
    attendanceRate: 91.2,
  },
  {
    id: 'STD-903',
    name: 'Tanvir Hossain',
    nameBn: 'তানভীর হোসেন',
    rollNo: '03',
    classId: 'CLS-9A',
    className: 'Class 9',
    section: 'A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    parentId: 'PRN-103',
    parentName: 'Rokeya Parveen',
    parentPhone: '01944-336677',
    gender: 'Male',
    dob: '2011-02-17',
    status: 'active',
    attendanceRate: 88.0,
  },
  {
    id: 'STD-904',
    name: 'Fatima Zohra',
    nameBn: 'ফাতিমা জোহরা',
    rollNo: '04',
    classId: 'CLS-9A',
    className: 'Class 9',
    section: 'A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    parentId: 'PRN-104',
    parentName: 'Al-Haj Abdul Mannan',
    parentPhone: '01655-447788',
    gender: 'Female',
    dob: '2011-10-05',
    status: 'active',
    attendanceRate: 97.4,
  },
  {
    id: 'STD-1001',
    name: 'Rifat Chowdhury',
    nameBn: 'রিফাত চৌধুরী',
    rollNo: '01',
    classId: 'CLS-10A',
    className: 'Class 10',
    section: 'A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    parentId: 'PRN-101',
    parentName: 'Mrs. Shamima Begum',
    parentPhone: '01722-114455',
    gender: 'Male',
    dob: '2010-01-15',
    status: 'active',
    attendanceRate: 93.1,
  },
  {
    id: 'STD-801',
    name: 'Nabil Hasan',
    nameBn: 'নাবিল হাসান',
    rollNo: '01',
    classId: 'CLS-8B',
    className: 'Class 8',
    section: 'B',
    schoolId: 'SCH-02',
    schoolName: 'Chatkhil PG Government High School',
    parentId: 'PRN-102',
    parentName: 'Engr. Zahirul Islam',
    parentPhone: '01833-225566',
    gender: 'Male',
    dob: '2012-05-19',
    status: 'active',
    attendanceRate: 90.0,
  },
];

// 5. Initial Classes
export const INITIAL_CLASSES: ClassRoom[] = [
  {
    id: 'CLS-9A',
    name: 'Class 9',
    section: 'Section A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    classTeacherId: 'TCH-1002',
    classTeacherName: 'Syeda Nusrat Jahan',
    totalStudents: 42,
    schedule: [
      { day: 'Sunday', time: '09:00 AM - 09:45 AM', subject: 'Higher Mathematics', teacherName: 'Syeda Nusrat Jahan' },
      { day: 'Sunday', time: '09:45 AM - 10:30 AM', subject: 'English 1st Paper', teacherName: 'Farzana Akter' },
      { day: 'Monday', time: '09:00 AM - 09:45 AM', subject: 'ICT & Computing', teacherName: 'Tanvir Ahmed' },
      { day: 'Monday', time: '10:30 AM - 11:15 AM', subject: 'General Science', teacherName: 'Kazi Mostafa Kamal' },
      { day: 'Tuesday', time: '09:00 AM - 09:45 AM', subject: 'Higher Mathematics', teacherName: 'Syeda Nusrat Jahan' },
    ],
  },
  {
    id: 'CLS-10A',
    name: 'Class 10',
    section: 'Section A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    classTeacherId: 'TCH-1003',
    classTeacherName: 'Tanvir Ahmed',
    totalStudents: 38,
    schedule: [
      { day: 'Sunday', time: '10:30 AM - 11:15 AM', subject: 'ICT Lab Practical', teacherName: 'Tanvir Ahmed' },
      { day: 'Monday', time: '09:00 AM - 09:45 AM', subject: 'Physics', teacherName: 'Kazi Mostafa Kamal' },
      { day: 'Tuesday', time: '11:15 AM - 12:00 PM', subject: 'English 2nd Paper', teacherName: 'Farzana Akter' },
    ],
  },
  {
    id: 'CLS-8B',
    name: 'Class 8',
    section: 'Section B',
    schoolId: 'SCH-02',
    schoolName: 'Chatkhil PG Government High School',
    classTeacherId: 'TCH-1006',
    classTeacherName: 'Mahmuda Begum',
    totalStudents: 45,
    schedule: [
      { day: 'Sunday', time: '09:00 AM - 09:45 AM', subject: 'Bangla Sahitya', teacherName: 'Mahmuda Begum' },
      { day: 'Monday', time: '10:00 AM - 10:45 AM', subject: 'General Science', teacherName: 'Abul Kalam Azad' },
    ],
  },
];

// 6. Initial Homework
export const INITIAL_HOMEWORK: Homework[] = [
  {
    id: 'HW-501',
    title: 'Algebraic Expressions & Quadratic Equations (Exercise 3.2)',
    subject: 'Higher Mathematics',
    classId: 'CLS-9A',
    className: 'Class 9',
    section: 'Section A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    teacherId: 'TCH-1002',
    teacherName: 'Syeda Nusrat Jahan',
    assignedDate: getTodayDateString(),
    dueDate: (() => {
      const d = new Date();
      d.setDate(d.getDate() + 2);
      return d.toISOString().split('T')[0];
    })(),
    instructions: 'Complete problems 1 through 10 from Chapter 3. Show step-by-step factoring on your homework notebook. Review formula sheet on page 64.',
    status: 'active',
    reviewedByParent: false,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'HW-502',
    title: 'Formal Letter Writing: Application for Leave of Absence',
    subject: 'English 1st Paper',
    classId: 'CLS-9A',
    className: 'Class 9',
    section: 'Section A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    teacherId: 'TCH-1004',
    teacherName: 'Farzana Akter',
    assignedDate: getTodayDateString(),
    dueDate: (() => {
      const d = new Date();
      d.setDate(d.getDate() + 3);
      return d.toISOString().split('T')[0];
    })(),
    instructions: 'Draft a formal application to the Headmaster requesting 3 days leave of absence due to illness. Follow standard British formal letter formatting.',
    status: 'active',
    reviewedByParent: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'HW-503',
    title: 'Digital Security & Password Best Practices Report',
    subject: 'Information & Communication Technology',
    classId: 'CLS-10A',
    className: 'Class 10',
    section: 'Section A',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    teacherId: 'TCH-1003',
    teacherName: 'Tanvir Ahmed',
    assignedDate: getTodayDateString(),
    dueDate: (() => {
      const d = new Date();
      d.setDate(d.getDate() + 4);
      return d.toISOString().split('T')[0];
    })(),
    instructions: 'Write a 200-word summary on why two-factor authentication (2FA) is critical in modern cyberspace. Include 3 examples of strong passphrase creation.',
    status: 'active',
    reviewedByParent: false,
    createdAt: new Date().toISOString(),
  },
];

// 7. Initial Notices
export const INITIAL_NOTICES: Notice[] = [
  {
    id: 'NTC-301',
    title: 'Chatkhil Upazila Inter-School Science Fair 2026 Registration',
    message: 'All secondary institutions under Chatkhil Upazila are hereby invited to nominate project teams for the upcoming Annual Science and Innovation Fair. Each school may register up to 3 student projects in Junior and Senior categories. Submit project abstracts to the Upazila Education Office by November 15, 2026.',
    category: 'Academic',
    audience: 'all',
    publishedBy: 'Upazila Secondary Education Office',
    publishedDate: getTodayDateString(),
    isPinned: true,
    status: 'published',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'NTC-302',
    title: 'Term-End Examination Schedule & Assessment Guidelines',
    message: 'The final assessment for Class 6 through Class 10 will commence from December 1st, 2026. Class teachers are requested to complete continuous assessments and submit practical marks by November 25th. Parents should ensure regular student attendance leading up to revision sessions.',
    category: 'Examination',
    audience: 'all',
    publishedBy: 'Headmaster & Academic Council',
    publishedDate: getTodayDateString(),
    isPinned: false,
    status: 'published',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'NTC-303',
    title: 'Quarterly Parent-Teacher Meeting (PTM) for Class 9 & 10',
    message: 'A mandatory Parent-Teacher Consultation meeting is scheduled for Saturday, 10:00 AM in the school main auditorium. Progress cards and attendance records will be shared. Parents are encouraged to discuss student academic milestones with subject educators.',
    category: 'Academic',
    audience: 'parents',
    publishedBy: 'Syeda Nusrat Jahan (Academic Coordinator)',
    publishedDate: getTodayDateString(),
    isPinned: true,
    status: 'published',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil Panchgaon Mahbub Government College',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'NTC-304',
    title: 'Teacher Digital Attendance Verification Guidelines',
    message: 'All teaching faculty are reminded to record daily check-in before 09:15 AM via the e-Institution Teacher Portal. In case of field duty, examination proctoring, or connectivity interruptions, use offline check-in mode.',
    category: 'Administrative',
    audience: 'teachers',
    publishedBy: 'District Education Directorate',
    publishedDate: getTodayDateString(),
    isPinned: false,
    status: 'published',
    createdAt: new Date().toISOString(),
  },
];

// 8. Initial Teacher Attendance
function createInitialTeacherAttendance(): TeacherAttendanceRecord[] {
  const today = getTodayDateString();
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const yesterday = d.toISOString().split('T')[0];

  return [
    {
      id: 'att-today-01',
      teacherId: 'TCH-1001',
      teacherName: 'Mohammad Rafiqul Islam',
      schoolId: 'SCH-01',
      schoolName: 'Chatkhil Panchgaon Mahbub Government College',
      date: today,
      checkInTime: '08:42 AM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      location: {
        latitude: 23.6489,
        longitude: 90.5982,
        accuracy: 12,
        capturedAt: new Date().toISOString(),
        permissionGranted: true,
      },
      remarks: 'Morning assembly inspection duty',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-today-02',
      teacherId: 'TCH-1002',
      teacherName: 'Syeda Nusrat Jahan',
      schoolId: 'SCH-01',
      schoolName: 'Chatkhil Panchgaon Mahbub Government College',
      date: today,
      checkInTime: '08:58 AM',
      checkOutTime: '04:10 PM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      remarks: 'Conducted 5 class sessions',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-today-03',
      teacherId: 'TCH-1003',
      teacherName: 'Tanvir Ahmed',
      schoolId: 'SCH-01',
      schoolName: 'Chatkhil Panchgaon Mahbub Government College',
      date: today,
      checkInTime: '09:18 AM',
      status: 'late',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      remarks: 'Traffic slowdown on Mograpara bridge',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-today-04',
      teacherId: 'TCH-1005',
      teacherName: 'Abul Kalam Azad',
      schoolId: 'SCH-02',
      schoolName: 'Chatkhil PG Government High School',
      date: today,
      checkInTime: '08:35 AM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-today-05',
      teacherId: 'TCH-1006',
      teacherName: 'Mahmuda Begum',
      schoolId: 'SCH-02',
      schoolName: 'Chatkhil PG Government High School',
      date: today,
      checkInTime: '08:50 AM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-today-06',
      teacherId: 'TCH-1008',
      teacherName: 'Dr. Mizanur Rahman',
      schoolId: 'SCH-03',
      schoolName: 'Bhimpur ML School',
      date: today,
      checkInTime: '08:40 AM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-today-07',
      teacherId: 'TCH-1010',
      teacherName: 'Maulana Azizul Haque',
      schoolId: 'SCH-04',
      schoolName: 'Chatkhil Government Girls School',
      date: today,
      checkInTime: '08:48 AM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-today-08',
      teacherId: 'TCH-1012',
      teacherName: 'Golam Sarwar',
      schoolId: 'SCH-05',
      schoolName: 'Chatkhil Womens College',
      date: today,
      checkInTime: '08:39 AM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    },
    {
      id: 'att-yest-01',
      teacherId: 'TCH-1001',
      teacherName: 'Mohammad Rafiqul Islam',
      schoolId: 'SCH-01',
      schoolName: 'Chatkhil Panchgaon Mahbub Government College',
      date: yesterday,
      checkInTime: '08:40 AM',
      checkOutTime: '04:30 PM',
      status: 'present',
      syncStatus: 'synced',
      syncTimestamp: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    },
  ];
}

// 9. Initial Student Attendance
export const INITIAL_STUDENT_ATTENDANCE: StudentAttendanceRecord[] = [
  {
    id: 'satt-01',
    studentId: 'STD-901',
    studentName: 'Ayan Ahmed',
    classId: 'CLS-9A',
    className: 'Class 9-A',
    schoolId: 'SCH-01',
    date: getTodayDateString(),
    status: 'present',
    remarks: 'On time for morning roll call',
  },
  {
    id: 'satt-02',
    studentId: 'STD-902',
    studentName: 'Sadia Islam',
    classId: 'CLS-9A',
    className: 'Class 9-A',
    schoolId: 'SCH-01',
    date: getTodayDateString(),
    status: 'present',
  },
  {
    id: 'satt-03',
    studentId: 'STD-903',
    studentName: 'Tanvir Hossain',
    classId: 'CLS-9A',
    className: 'Class 9-A',
    schoolId: 'SCH-01',
    date: getTodayDateString(),
    status: 'late',
    remarks: 'Arrived after 09:20 AM',
  },
  {
    id: 'satt-04',
    studentId: 'STD-904',
    studentName: 'Fatima Zohra',
    classId: 'CLS-9A',
    className: 'Class 9-A',
    schoolId: 'SCH-01',
    date: getTodayDateString(),
    status: 'present',
  },
];

const DEFAULT_SETTINGS: AppSettings = {
  isOfflineMode: false,
  upazilaName: 'Chatkhil',
  districtName: 'Noakhali',
  autoSimulateDelayMs: 1200,
  lastSimulatedSync: new Date().toLocaleTimeString(),
  language: 'en',
  currentTeacherId: 'TCH-1002', // Default active teacher: Syeda Nusrat Jahan
  currentParentId: 'PRN-101', // Default active parent: Mrs. Shamima Begum (Child: Ayan Ahmed)
};

function safeGet<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.warn(`Failed to parse ${key} from localStorage, using fallback:`, err);
    return fallback;
  }
}

function safeSet<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Failed to write ${key} to localStorage:`, err);
  }
}

export const StorageService = {
  // --- Schools ---
  getSchools(): School[] {
    const schools = safeGet<School[]>(STORAGE_KEYS.SCHOOLS, []);
    if (!schools || schools.length === 0) {
      safeSet(STORAGE_KEYS.SCHOOLS, INITIAL_SCHOOLS);
      return INITIAL_SCHOOLS;
    }
    const missing = INITIAL_SCHOOLS.filter((init) => !schools.some((s) => s.id === init.id));
    if (missing.length > 0) {
      const merged = [...schools, ...missing];
      safeSet(STORAGE_KEYS.SCHOOLS, merged);
      return merged;
    }
    return schools;
  },

  saveSchools(schools: School[]): void {
    safeSet(STORAGE_KEYS.SCHOOLS, schools);
  },

  addSchool(schoolData: Omit<School, 'id'>): School {
    const schools = this.getSchools();
    const newId = `SCH-${String(schools.length + 1).padStart(2, '0')}`;
    const newSchool: School = { ...schoolData, id: newId };
    schools.push(newSchool);
    this.saveSchools(schools);
    return newSchool;
  },

  updateSchool(school: School): void {
    const schools = this.getSchools().map((s) => (s.id === school.id ? school : s));
    this.saveSchools(schools);
  },

  deleteSchool(id: string): void {
    const schools = this.getSchools().filter((s) => s.id !== id);
    this.saveSchools(schools);
  },

  // --- Teachers ---
  getTeachers(): Teacher[] {
    const teachers = safeGet<Teacher[]>(STORAGE_KEYS.TEACHERS, []);
    if (!teachers || teachers.length === 0) {
      safeSet(STORAGE_KEYS.TEACHERS, INITIAL_TEACHERS);
      return INITIAL_TEACHERS;
    }
    return teachers;
  },

  saveTeachers(teachers: Teacher[]): void {
    safeSet(STORAGE_KEYS.TEACHERS, teachers);
  },

  addTeacher(teacherData: Omit<Teacher, 'id'>): Teacher {
    const teachers = this.getTeachers();
    const maxNum = teachers.reduce((max, t) => {
      const match = t.id.match(/\d+/);
      const num = match ? parseInt(match[0], 10) : 1000;
      return Math.max(max, num);
    }, 1000);
    const newId = `TCH-${maxNum + 1}`;
    const newTeacher: Teacher = { ...teacherData, id: newId };
    teachers.push(newTeacher);
    this.saveTeachers(teachers);
    return newTeacher;
  },

  updateTeacher(teacher: Teacher): void {
    const teachers = this.getTeachers().map((t) => (t.id === teacher.id ? teacher : t));
    this.saveTeachers(teachers);
  },

  deleteTeacher(id: string): void {
    const teachers = this.getTeachers().filter((t) => t.id !== id);
    this.saveTeachers(teachers);
  },

  // --- Students ---
  getStudents(): Student[] {
    const students = safeGet<Student[]>(STORAGE_KEYS.STUDENTS, []);
    if (!students || students.length === 0) {
      safeSet(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
      return INITIAL_STUDENTS;
    }
    return students;
  },

  saveStudents(students: Student[]): void {
    safeSet(STORAGE_KEYS.STUDENTS, students);
  },

  addStudent(studentData: Omit<Student, 'id'>): Student {
    const students = this.getStudents();
    const newId = `STD-${900 + students.length + 1}`;
    const newStudent: Student = { ...studentData, id: newId };
    students.push(newStudent);
    this.saveStudents(students);
    return newStudent;
  },

  updateStudent(student: Student): void {
    const students = this.getStudents().map((s) => (s.id === student.id ? student : s));
    this.saveStudents(students);
  },

  // --- Parents ---
  getParents(): ParentGuardian[] {
    const parents = safeGet<ParentGuardian[]>(STORAGE_KEYS.PARENTS, []);
    if (!parents || parents.length === 0) {
      safeSet(STORAGE_KEYS.PARENTS, INITIAL_PARENTS);
      return INITIAL_PARENTS;
    }
    return parents;
  },

  saveParents(parents: ParentGuardian[]): void {
    safeSet(STORAGE_KEYS.PARENTS, parents);
  },

  // --- Classes ---
  getClasses(): ClassRoom[] {
    const classes = safeGet<ClassRoom[]>(STORAGE_KEYS.CLASSES, []);
    if (!classes || classes.length === 0) {
      safeSet(STORAGE_KEYS.CLASSES, INITIAL_CLASSES);
      return INITIAL_CLASSES;
    }
    return classes;
  },

  // --- Homework ---
  getHomework(): Homework[] {
    const homework = safeGet<Homework[]>(STORAGE_KEYS.HOMEWORK, []);
    if (!homework || homework.length === 0) {
      safeSet(STORAGE_KEYS.HOMEWORK, INITIAL_HOMEWORK);
      return INITIAL_HOMEWORK;
    }
    return homework;
  },

  saveHomework(homework: Homework[]): void {
    safeSet(STORAGE_KEYS.HOMEWORK, homework);
  },

  addHomework(data: Omit<Homework, 'id' | 'createdAt'>): Homework {
    const all = this.getHomework();
    const newId = `HW-${500 + all.length + 1}`;
    const item: Homework = {
      ...data,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    all.unshift(item);
    this.saveHomework(all);
    return item;
  },

  updateHomework(item: Homework): void {
    const all = this.getHomework().map((h) => (h.id === item.id ? item : h));
    this.saveHomework(all);
  },

  deleteHomework(id: string): void {
    const all = this.getHomework().filter((h) => h.id !== id);
    this.saveHomework(all);
  },

  toggleHomeworkReviewed(id: string): boolean {
    const all = this.getHomework();
    const item = all.find((h) => h.id === id);
    if (!item) return false;
    item.reviewedByParent = !item.reviewedByParent;
    this.saveHomework(all);
    return item.reviewedByParent;
  },

  // --- Notices ---
  getNotices(): Notice[] {
    const notices = safeGet<Notice[]>(STORAGE_KEYS.NOTICES, []);
    if (!notices || notices.length === 0) {
      safeSet(STORAGE_KEYS.NOTICES, INITIAL_NOTICES);
      return INITIAL_NOTICES;
    }
    return notices;
  },

  saveNotices(notices: Notice[]): void {
    safeSet(STORAGE_KEYS.NOTICES, notices);
  },

  addNotice(data: Omit<Notice, 'id' | 'createdAt'>): Notice {
    const all = this.getNotices();
    const newId = `NTC-${300 + all.length + 1}`;
    const notice: Notice = {
      ...data,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    all.unshift(notice);
    this.saveNotices(all);
    return notice;
  },

  updateNotice(notice: Notice): void {
    const all = this.getNotices().map((n) => (n.id === notice.id ? notice : n));
    this.saveNotices(all);
  },

  deleteNotice(id: string): void {
    const all = this.getNotices().filter((n) => n.id !== id);
    this.saveNotices(all);
  },

  // --- Teacher Attendance ---
  getTeacherAttendance(): TeacherAttendanceRecord[] {
    const records = safeGet<TeacherAttendanceRecord[]>(STORAGE_KEYS.TEACHER_ATTENDANCE, []);
    if (!records || records.length === 0) {
      const seed = createInitialTeacherAttendance();
      safeSet(STORAGE_KEYS.TEACHER_ATTENDANCE, seed);
      return seed;
    }
    return records;
  },

  saveTeacherAttendance(records: TeacherAttendanceRecord[]): void {
    safeSet(STORAGE_KEYS.TEACHER_ATTENDANCE, records);
  },

  recordCheckIn(
    teacher: Teacher,
    options?: {
      location?: LocationData;
      status?: AttendanceStatus;
      remarks?: string;
      customTime?: string;
      customDate?: string;
    }
  ): TeacherAttendanceRecord {
    const settings = this.getSettings();
    const records = this.getTeacherAttendance();
    const today = options?.customDate || getTodayDateString();
    const checkInTime = options?.customTime || formatTime12h();

    let determinedStatus: AttendanceStatus = options?.status || 'present';
    if (!options?.status) {
      const now = new Date();
      if (now.getHours() > 9 || (now.getHours() === 9 && now.getMinutes() > 15)) {
        determinedStatus = 'late';
      }
    }

    const syncStatus = settings.isOfflineMode ? 'pending' : 'synced';
    const newRecord: TeacherAttendanceRecord = {
      id: `att_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      teacherId: teacher.id,
      teacherName: teacher.name,
      schoolId: teacher.schoolId,
      schoolName: teacher.schoolName,
      date: today,
      checkInTime,
      status: determinedStatus,
      syncStatus,
      syncTimestamp: syncStatus === 'synced' ? new Date().toISOString() : undefined,
      location: options?.location,
      remarks: options?.remarks || (settings.isOfflineMode ? 'Recorded in Offline Queue' : ''),
      createdAt: new Date().toISOString(),
    };

    records.unshift(newRecord);
    this.saveTeacherAttendance(records);
    return newRecord;
  },

  recordCheckOut(teacherId: string, customTime?: string): TeacherAttendanceRecord | null {
    const today = getTodayDateString();
    const records = this.getTeacherAttendance();
    const index = records.findIndex((r) => r.teacherId === teacherId && r.date === today);

    if (index === -1) return null;

    const existing = records[index];
    const settings = this.getSettings();
    const updated: TeacherAttendanceRecord = {
      ...existing,
      checkOutTime: customTime || formatTime12h(),
      syncStatus: settings.isOfflineMode ? 'pending' : existing.syncStatus,
    };

    records[index] = updated;
    this.saveTeacherAttendance(records);
    return updated;
  },

  async simulateSync(): Promise<{ syncedCount: number; timestamp: string }> {
    const records = this.getTeacherAttendance();
    let count = 0;
    const nowIso = new Date().toISOString();

    const updated = records.map((r) => {
      if (r.syncStatus === 'pending') {
        count++;
        return {
          ...r,
          syncStatus: 'synced' as const,
          syncTimestamp: nowIso,
          remarks: r.remarks ? `${r.remarks} [Synced Locally]` : '[Synced Locally]',
        };
      }
      return r;
    });

    this.saveTeacherAttendance(updated);

    const settings = this.getSettings();
    settings.lastSimulatedSync = formatTime12h();
    this.saveSettings(settings);

    return { syncedCount: count, timestamp: settings.lastSimulatedSync };
  },

  // --- Student Attendance ---
  getStudentAttendance(): StudentAttendanceRecord[] {
    const records = safeGet<StudentAttendanceRecord[]>(STORAGE_KEYS.STUDENT_ATTENDANCE, []);
    if (!records || records.length === 0) {
      safeSet(STORAGE_KEYS.STUDENT_ATTENDANCE, INITIAL_STUDENT_ATTENDANCE);
      return INITIAL_STUDENT_ATTENDANCE;
    }
    return records;
  },

  saveStudentAttendance(records: StudentAttendanceRecord[]): void {
    safeSet(STORAGE_KEYS.STUDENT_ATTENDANCE, records);
  },

  // --- Leave Applications ---
  getLeaveApplications(): LeaveApplication[] {
    return safeGet<LeaveApplication[]>(STORAGE_KEYS.LEAVE_APPLICATIONS, []);
  },
  saveLeaveApplication(application: LeaveApplication): void {
    const apps = this.getLeaveApplications();
    const index = apps.findIndex((a) => a.id === application.id);
    if (index !== -1) {
      apps[index] = application;
    } else {
      apps.push(application);
    }
    safeSet(STORAGE_KEYS.LEAVE_APPLICATIONS, apps);
  },

  // --- Dismissal Notices ---
  getDismissalNotices(): DismissalNotice[] {
    return safeGet<DismissalNotice[]>(STORAGE_KEYS.DISMISSAL_NOTICES, []);
  },
  saveDismissalNotice(notice: DismissalNotice): void {
    const notices = this.getDismissalNotices();
    notices.push(notice);
    safeSet(STORAGE_KEYS.DISMISSAL_NOTICES, notices);
  },

  // --- Messages ---
  getMessages(): Message[] {
    return safeGet<Message[]>(STORAGE_KEYS.MESSAGES, []);
  },
  saveMessage(message: Message): void {
    const messages = this.getMessages();
    messages.push(message);
    safeSet(STORAGE_KEYS.MESSAGES, messages);
  },

  // --- Settings ---
  getSettings(): AppSettings {
    const settings = safeGet<AppSettings>(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    return { ...DEFAULT_SETTINGS, ...settings };
  },

  saveSettings(settings: AppSettings): void {
    safeSet(STORAGE_KEYS.SETTINGS, settings);
  },

  toggleOfflineMode(): boolean {
    const settings = this.getSettings();
    const newMode = !settings.isOfflineMode;
    settings.isOfflineMode = newMode;
    this.saveSettings(settings);
    return newMode;
  },

  setLanguage(lang: 'en' | 'bn'): void {
    const settings = this.getSettings();
    settings.language = lang;
    this.saveSettings(settings);
  },

  setCurrentTeacherId(id: string): void {
    const settings = this.getSettings();
    settings.currentTeacherId = id;
    this.saveSettings(settings);
  },

  setCurrentParentId(id: string): void {
    const settings = this.getSettings();
    settings.currentParentId = id;
    this.saveSettings(settings);
  },

  // --- Reset & Backup ---
  resetToDefault(): void {
    safeSet(STORAGE_KEYS.SCHOOLS, INITIAL_SCHOOLS);
    safeSet(STORAGE_KEYS.TEACHERS, INITIAL_TEACHERS);
    safeSet(STORAGE_KEYS.STUDENTS, INITIAL_STUDENTS);
    safeSet(STORAGE_KEYS.PARENTS, INITIAL_PARENTS);
    safeSet(STORAGE_KEYS.CLASSES, INITIAL_CLASSES);
    safeSet(STORAGE_KEYS.HOMEWORK, INITIAL_HOMEWORK);
    safeSet(STORAGE_KEYS.NOTICES, INITIAL_NOTICES);
    safeSet(STORAGE_KEYS.TEACHER_ATTENDANCE, createInitialTeacherAttendance());
    safeSet(STORAGE_KEYS.STUDENT_ATTENDANCE, INITIAL_STUDENT_ATTENDANCE);
    safeSet(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  },

  clearAll(): void {
    safeSet(STORAGE_KEYS.SCHOOLS, []);
    safeSet(STORAGE_KEYS.TEACHERS, []);
    safeSet(STORAGE_KEYS.STUDENTS, []);
    safeSet(STORAGE_KEYS.PARENTS, []);
    safeSet(STORAGE_KEYS.CLASSES, []);
    safeSet(STORAGE_KEYS.HOMEWORK, []);
    safeSet(STORAGE_KEYS.NOTICES, []);
    safeSet(STORAGE_KEYS.TEACHER_ATTENDANCE, []);
    safeSet(STORAGE_KEYS.STUDENT_ATTENDANCE, []);
  },

  exportBackupJson(): string {
    return JSON.stringify(
      {
        platform: 'e-Institution',
        version: '2.0.0',
        exportedAt: new Date().toISOString(),
        schools: this.getSchools(),
        teachers: this.getTeachers(),
        students: this.getStudents(),
        parents: this.getParents(),
        classes: this.getClasses(),
        homework: this.getHomework(),
        notices: this.getNotices(),
        teacherAttendance: this.getTeacherAttendance(),
        studentAttendance: this.getStudentAttendance(),
        settings: this.getSettings(),
      },
      null,
      2
    );
  },

  importBackupJson(rawJson: string): boolean {
    try {
      const data = JSON.parse(rawJson);
      if (Array.isArray(data.schools)) safeSet(STORAGE_KEYS.SCHOOLS, data.schools);
      if (Array.isArray(data.teachers)) safeSet(STORAGE_KEYS.TEACHERS, data.teachers);
      if (Array.isArray(data.students)) safeSet(STORAGE_KEYS.STUDENTS, data.students);
      if (Array.isArray(data.parents)) safeSet(STORAGE_KEYS.PARENTS, data.parents);
      if (Array.isArray(data.classes)) safeSet(STORAGE_KEYS.CLASSES, data.classes);
      if (Array.isArray(data.homework)) safeSet(STORAGE_KEYS.HOMEWORK, data.homework);
      if (Array.isArray(data.notices)) safeSet(STORAGE_KEYS.NOTICES, data.notices);
      if (Array.isArray(data.teacherAttendance)) safeSet(STORAGE_KEYS.TEACHER_ATTENDANCE, data.teacherAttendance);
      if (Array.isArray(data.studentAttendance)) safeSet(STORAGE_KEYS.STUDENT_ATTENDANCE, data.studentAttendance);
      if (data.settings) safeSet(STORAGE_KEYS.SETTINGS, data.settings);
      return true;
    } catch (err) {
      console.error('Failed to parse backup JSON:', err);
      return false;
    }
  },
};

// Safe Migration for LocalStorage to Chatkhil, Noakhali
function migrateStoredData(): void {
  if (typeof window === "undefined") return;
  try {
    const migrationFlagKey = "einst_chatkhil_migrated_v3";
    if (localStorage.getItem(migrationFlagKey) === "true") return;

    // Migrate schools
    const rawSchools = localStorage.getItem(STORAGE_KEYS.SCHOOLS);
    if (rawSchools) {
      const schools: School[] = JSON.parse(rawSchools);
      const nameMap: Record<string, { name: string; nameBn: string; category?: string }> = {
        "SCH-01": { name: "Chatkhil Panchgaon Mahbub Government College", nameBn: "চাটখিল পাঁচগাঁও মাহবুব সরকারি কলেজ", category: "College" },
        "SCH-02": { name: "Chatkhil PG Government High School", nameBn: "চাটখিল পিজি সরকারি উচ্চ বিদ্যালয়" },
        "SCH-03": { name: "Bhimpur ML School", nameBn: "ভীমপুর এমএল হাই স্কুল" },
        "SCH-04": { name: "Chatkhil Government Girls School", nameBn: "চাটখিল সরকারি বালিকা উচ্চ বিদ্যালয়" },
        "SCH-05": { name: "Chatkhil Womens College", nameBn: "চাটখিল মহিলা কলেজ", category: "College" },
        "SCH-06": { name: "Chatkhil Government Technical School and College", nameBn: "চাটখিল সরকারি টেকনিক্যাল স্কুল ও কলেজ", category: "Technical School and College" },
      };
      const updated = schools.map((s) => {
        const info = nameMap[s.id];
        return {
          ...s,
          name: info?.name || s.name.replace(/Sonargaon/gi, "Chatkhil"),
          nameBn: info?.nameBn || s.nameBn,
          upazila: "Chatkhil",
          district: "Noakhali",
          address: "Chatkhil, Noakhali",
          category: info?.category || s.category,
        };
      });
      localStorage.setItem(STORAGE_KEYS.SCHOOLS, JSON.stringify(updated));
    }

    // Migrate settings
    const rawSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (rawSettings) {
      const settings = JSON.parse(rawSettings);
      settings.upazilaName = "Chatkhil";
      settings.districtName = "Noakhali";
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    }

    // Helper to replace old names in collections
    const collectionsToUpdate = [
      STORAGE_KEYS.TEACHERS,
      STORAGE_KEYS.TEACHER_ATTENDANCE,
      STORAGE_KEYS.STUDENTS,
      STORAGE_KEYS.STUDENT_ATTENDANCE,
      STORAGE_KEYS.CLASSES,
      STORAGE_KEYS.HOMEWORK,
      STORAGE_KEYS.NOTICES,
    ];

    for (const key of collectionsToUpdate) {
      const raw = localStorage.getItem(key);
      if (raw) {
        let text = raw;
        text = text.replace(/Sonargaon Govt\. Model High School/g, "Chatkhil Panchgaon Mahbub Government College");
        text = text.replace(/Meghna Adarsha High School/g, "Chatkhil PG Government High School");
        text = text.replace(/Brahmaputra Collegiate Academy/g, "Bhimpur ML School");
        text = text.replace(/Shitalakshya Dakhil Madrasah/g, "Chatkhil Government Girls School");
        text = text.replace(/Padma Model Primary & Junior High/g, "Chatkhil Womens College");
        text = text.replace(/Kachpur Public High School/g, "Chatkhil Government Technical School and College");
        text = text.replace(/Sonargaon/g, "Chatkhil");
        text = text.replace(/Narayanganj/g, "Noakhali");
        localStorage.setItem(key, text);
      }
    }

    localStorage.setItem(migrationFlagKey, "true");
  } catch (e) {
    console.warn("Storage migration failed safely:", e);
  }
}

migrateStoredData();
