/**
 * Core TypeScript definitions for e-Institution
 * Unified School Management Platform for Bangladesh
 */

export type PortalRole = 'landing' | 'authority' | 'teacher' | 'parent';

export type Language = 'en' | 'bn';

export type TeacherDesignation =
  | 'Head Teacher'
  | 'Assistant Head Teacher'
  | 'Senior Teacher'
  | 'Assistant Teacher (Bangla)'
  | 'Assistant Teacher (English)'
  | 'Assistant Teacher (Mathematics)'
  | 'Assistant Teacher (Science)'
  | 'Assistant Teacher (Social Science)'
  | 'Assistant Teacher (ICT)'
  | 'Assistant Teacher (Physical Education)'
  | 'Junior Teacher';

export interface Teacher {
  id: string; // e.g. "TCH-1001"
  name: string;
  nameBn?: string;
  designation: TeacherDesignation | string;
  designationBn?: string;
  schoolId: string;
  schoolName: string;
  phone: string;
  email: string;
  subject: string;
  joinDate: string; // YYYY-MM-DD
  status: 'active' | 'inactive';
  avatar?: string;
}

export type SchoolCategory =
  | 'Secondary High School'
  | 'Higher Secondary College'
  | 'Dakhil Madrasah'
  | 'Model Primary';

export interface School {
  id: string; // e.g. "SCH-01"
  name: string;
  nameBn?: string;
  eiin: string; // e.g. "112450"
  upazila: string;
  district: string;
  category: SchoolCategory | string;
  status: 'active' | 'inactive';
  contactPhone: string;
  address: string;
  establishedYear: number;
}

export interface Student {
  id: string; // e.g. "STD-901"
  name: string;
  nameBn?: string;
  rollNo: string;
  classId: string; // e.g. "CLS-9A"
  className: string; // "Class 9"
  section: string; // "A"
  schoolId: string;
  schoolName: string;
  parentId: string; // e.g. "PRN-101"
  parentName: string;
  parentPhone: string;
  guardianName?: string;
  guardianPhone?: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string; // YYYY-MM-DD
  bloodGroup?: string;
  status: 'active' | 'inactive';
  attendanceRate: number; // e.g. 92.5
  attendanceStatusToday?: 'present' | 'absent' | 'late' | 'excused';
}

export interface ParentGuardian {
  id: string; // e.g. "PRN-101"
  name: string;
  nameBn?: string;
  relation: 'Mother' | 'Father' | 'Guardian';
  phone: string;
  email: string;
  occupation: string;
  address: string;
  studentIds: string[]; // Connected child IDs
}

export interface ClassScheduleItem {
  day: string;
  time: string;
  subject: string;
  teacherName: string;
}

export interface ClassRoom {
  id: string; // e.g. "CLS-9A"
  name: string; // "Class 9"
  section: string; // "A"
  roomNo?: string;
  schoolId: string;
  schoolName: string;
  classTeacherId: string;
  classTeacherName: string;
  totalStudents: number;
  schedule: ClassScheduleItem[];
}

export type AttendanceStatus = 'present' | 'late' | 'half_day' | 'absent' | 'leave';
export type SyncStatus = 'synced' | 'pending';

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number; // in meters
  capturedAt: string; // ISO
  permissionGranted: boolean;
}

export interface TeacherAttendanceRecord {
  id: string;
  teacherId: string;
  teacherName: string;
  schoolId: string;
  schoolName: string;
  date: string; // YYYY-MM-DD
  checkInTime: string; // e.g. "08:45 AM"
  checkOutTime?: string; // e.g. "04:15 PM"
  status: AttendanceStatus;
  syncStatus: SyncStatus;
  syncTimestamp?: string;
  location?: LocationData;
  remarks?: string;
  createdAt: string; // ISO
}

// Alias for backwards compatibility
export type AttendanceRecord = TeacherAttendanceRecord;

export interface StudentAttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  classId: string;
  className: string;
  schoolId: string;
  date: string; // YYYY-MM-DD
  status: 'present' | 'absent' | 'late';
  remarks?: string;
}

export interface Homework {
  id: string;
  title: string;
  subject: string;
  classId: string;
  className: string;
  section: string;
  schoolId: string;
  schoolName: string;
  teacherId: string;
  teacherName: string;
  assignedDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  instructions: string;
  status: 'active' | 'past_due' | 'completed';
  reviewedByParent?: boolean;
  createdAt: string;
}

export type NoticeAudience = 'all' | 'teachers' | 'parents' | 'authority';
export type NoticeCategory =
  | 'Academic'
  | 'Administrative'
  | 'Examination'
  | 'Holiday'
  | 'Emergency';

export interface Notice {
  id: string;
  title: string;
  message: string;
  category: NoticeCategory;
  audience: NoticeAudience;
  publishedBy: string;
  publishedDate: string; // YYYY-MM-DD
  schoolId?: string; // 'all' or specific school ID
  schoolName?: string;
  isPinned?: boolean;
  status: 'published' | 'archived';
  createdAt: string;
}

export interface LeaveApplication {
  id: string;
  studentId: string;
  studentName: string;
  date: string;
  type: 'full_day' | 'partial';
  reason?: string;
  status: 'pending' | 'approved' | 'rejected';
  teacherId: string;
}

export interface DismissalNotice {
  id: string;
  date: string;
  classId?: string; // Optional if for whole institution
  schoolId: string;
  message: string;
  sentAt: string;
}

export interface AppSettings {
  isOfflineMode: boolean;
  upazilaName: string;
  districtName: string;
  autoSimulateDelayMs: number;
  lastSimulatedSync?: string;
  language: Language;
  currentTeacherId: string;
  currentParentId: string;
}

export interface Message {
  id: string;
  senderId: string; // teacherId or parentId
  senderName: string;
  receiverId: string; // parentId or teacherId
  receiverName: string;
  content: string;
  timestamp: string;
  read: boolean;
  studentId?: string; // context
}

export type AuthorityPage =
  | 'overview'
  | 'schools'
  | 'attendance'
  | 'teachers'
  | 'students'
  | 'notices'
  | 'reports'
  | 'settings'
  | 'dashboard'
  | 'upazila';

export type TeacherPage =
  | 'dashboard'
  | 'attendance'
  | 'classes'
  | 'students'
  | 'student-attendance'
  | 'leave-management'
  | 'homework'
  | 'notices'
  | 'messaging' // New
  | 'profile';

export type ParentPage =
  | 'home'
  | 'attendance'
  | 'homework'
  | 'notices'
  | 'profile'
  | 'dismissal-messages'
  | 'messaging'; // New

export type NavigationPage = AuthorityPage;
