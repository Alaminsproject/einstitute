import React, { useState, useMemo } from 'react';
import {
  Home,
  CalendarCheck,
  BookOpen,
  Bell,
  User,
  CheckCircle2,
  Clock,
  AlertCircle,
  Calendar,
  Building2,
  ChevronRight,
  Phone,
  Mail,
  Check,
  School as SchoolIcon,
  X,
  FileText,
  HeartHandshake,
  CheckSquare,
  Square,
} from 'lucide-react';
import {
  Homework,
  Notice,
  ParentGuardian,
  ParentPage,
  School,
  Student,
  StudentAttendanceRecord,
  Teacher,
  Message,
  LeaveApplication,
  DismissalNotice,
} from '../../types';
import { getTodayDateString } from '../../services/storageService';

interface ParentPortalProps {
  currentParent: ParentGuardian;
  allParents: ParentGuardian[];
  onSelectParentId: (id: string) => void;
  students: Student[];
  schools: School[];
  teachers: Teacher[];
  homeworkList: Homework[];
  onToggleHomeworkReviewed: (id: string) => void;
  notices: Notice[];
  studentAttendance: StudentAttendanceRecord[];
  leaveApplications: LeaveApplication[];
  dismissalNotices: DismissalNotice[];
  messages: Message[];
  onSaveMessage: (message: Message) => void;
}

export const ParentPortal: React.FC<ParentPortalProps> = ({
  currentParent,
  allParents,
  onSelectParentId,
  students,
  schools,
  teachers,
  homeworkList,
  onToggleHomeworkReviewed,
  notices,
  studentAttendance,
  leaveApplications,
  dismissalNotices,
  messages,
  onSaveMessage,
}) => {
  const [currentPage, setCurrentPage] = useState<ParentPage>('home');
  const [selectedChildId, setSelectedChildId] = useState<string>(
    currentParent.studentIds[0] || ''
  );
  const [selectedNotice, setSelectedNotice] = useState<Notice | null>(null);
  const [homeworkFilter, setHomeworkFilter] = useState<'all' | 'pending' | 'reviewed'>('all');

  const todayStr = getTodayDateString();

  // Connected children for this parent
  const children = useMemo(() => {
    return students.filter((s) => currentParent.studentIds.includes(s.id));
  }, [students, currentParent]);

  // Active selected child
  const child = useMemo(() => {
    return children.find((c) => c.id === selectedChildId) || children[0] || null;
  }, [children, selectedChildId]);

  // Child's school
  const school = useMemo(() => {
    if (!child) return null;
    return schools.find((s) => s.id === child.schoolId) || null;
  }, [schools, child]);

  // Child's attendance today
  const childTodayAttendance = useMemo(() => {
    if (!child) return null;
    return studentAttendance.find((r) => r.studentId === child.id && r.date === todayStr);
  }, [studentAttendance, child, todayStr]);

  // Child's attendance history
  const childAttendanceHistory = useMemo(() => {
    if (!child) return [];
    return studentAttendance.filter((r) => r.studentId === child.id);
  }, [studentAttendance, child]);

  // Child's relevant homework
  const childHomework = useMemo(() => {
    if (!child) return [];
    return homeworkList.filter(
      (h) => h.classId === child.classId || h.schoolId === child.schoolId
    );
  }, [homeworkList, child]);

  // Filtered homework
  const filteredHomework = useMemo(() => {
    return childHomework.filter((h) => {
      if (homeworkFilter === 'pending') return !h.reviewedByParent;
      if (homeworkFilter === 'reviewed') return h.reviewedByParent;
      return true;
    });
  }, [childHomework, homeworkFilter]);

  // Relevant notices
  const parentNotices = useMemo(() => {
    return notices.filter(
      (n) =>
        n.status === 'published' &&
        (n.audience === 'all' || n.audience === 'parents') &&
        (!n.schoolId || n.schoolId === 'all' || (child && n.schoolId === child.schoolId))
    );
  }, [notices, child]);

  const navItems = [
    { id: 'home' as ParentPage, label: 'Today', icon: Home },
    { id: 'attendance' as ParentPage, label: 'Attendance', icon: CalendarCheck },
    { id: 'homework' as ParentPage, label: 'Homework', icon: BookOpen },
    { id: 'notices' as ParentPage, label: 'Notices', icon: Bell },
    { id: 'profile' as ParentPage, label: 'Profile', icon: User },
  ];

  if (!child) {
    return (
      <div className="max-w-md mx-auto my-12 p-6 bg-white rounded-2xl border border-slate-200 text-center">
        <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-2" />
        <h2 className="text-base font-bold text-slate-900">No Student Profile Linked</h2>
        <p className="text-xs text-slate-500 mt-1">
          No child profile found linked to this guardian record.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-[85vh] flex flex-col pb-20 md:pb-6">
      {/* 1. Warm, Friendly Header & Active Child Switcher */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-orange-50 border border-orange-200 text-orange-600 flex items-center justify-center font-bold text-lg shadow-2xs">
              {child.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                  {child.name}
                </h1>
                {child.nameBn && (
                  <span className="text-xs text-slate-400">({child.nameBn})</span>
                )}
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-orange-50 text-orange-800 border border-orange-200">
                  {child.className} · {child.section} (Roll: {child.rollNo})
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                <SchoolIcon className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span>{child.schoolName}</span>
              </p>
            </div>
          </div>

          {/* Child Switcher Tabs if multiple children */}
          <div className="flex items-center gap-2 self-start sm:self-auto bg-slate-50 p-1.5 rounded-xl border border-slate-200">
            <span className="text-[11px] font-semibold text-slate-500 pl-1.5">Child:</span>
            {children.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedChildId(c.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  child.id === c.id
                    ? 'bg-orange-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                {c.name.split(' ')[0]} ({c.className})
              </button>
            ))}
          </div>
        </div>

        {/* Desktop Portal Navigation Tabs */}
        <div className="hidden md:flex items-center gap-2 mt-5 pt-4 border-t border-slate-100">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setCurrentPage(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-orange-500 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Main Child Perspective Content */}
      <div className="space-y-6">
        {/* --- PAGE: HOME (TODAY AT A GLANCE) --- */}
        {currentPage === 'home' && (
          <div className="space-y-6">
            {/* Friendly Attendance Status Card for Today */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-2xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-orange-700">
                Today's Attendance Status
              </span>

              <div className="mt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-orange-50/50 border border-orange-200/70">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-bold text-slate-900">
                        {child.name} is Present Today
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                        VERIFIED
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Check-in recorded at 08:42 AM · Chatkhil Campus
                    </p>
                  </div>
                </div>

                <div className="text-right sm:border-l sm:border-orange-200/60 sm:pl-4">
                  <span className="text-[11px] text-slate-500 block">Class Teacher</span>
                  <span className="text-xs font-bold text-slate-800">
                    Mohammad Rafiqul Islam
                  </span>
                </div>
              </div>
            </div>

            {/* Recent 5-Day Attendance Streak */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900">
                  Recent 5-Day School Attendance
                </h3>
                <span className="text-xs font-semibold text-emerald-700">
                  98% Attendance Streak
                </span>
              </div>

              <div className="grid grid-cols-5 gap-2 text-center text-xs">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Today'].map((day, idx) => (
                  <div
                    key={day}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex flex-col items-center gap-1.5"
                  >
                    <span className="text-[11px] text-slate-500 font-medium">{day}</span>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span className="text-[10px] font-bold text-emerald-700">Present</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Today's Homework Overview with Review Action */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Assigned Homework Tasks ({childHomework.length})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Review and confirm completion for {child.name}'s classes
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setCurrentPage('homework')}
                  className="text-xs font-bold text-orange-600 hover:text-orange-700 cursor-pointer"
                >
                  View All Tasks →
                </button>
              </div>

              <div className="space-y-3">
                {childHomework.slice(0, 3).map((hw) => (
                  <div
                    key={hw.id}
                    className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-orange-300 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                          {hw.subject}
                        </span>
                        <span className="text-xs font-bold text-slate-900">{hw.title}</span>
                      </div>
                      <p className="text-xs text-slate-600">{hw.instructions}</p>
                      <span className="text-[11px] font-mono text-rose-600 font-semibold block">
                        Due: {hw.dueDate}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onToggleHomeworkReviewed(hw.id)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer ${
                        hw.reviewedByParent
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white border border-slate-300 text-slate-700 hover:border-orange-500 hover:text-orange-600'
                      }`}
                    >
                      {hw.reviewedByParent ? (
                        <>
                          <CheckSquare className="w-4 h-4" />
                          <span>Reviewed at Home</span>
                        </>
                      ) : (
                        <>
                          <Square className="w-4 h-4" />
                          <span>Mark as Reviewed</span>
                        </>
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* School Circulars Feed */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-3">
              <h3 className="text-sm font-bold text-slate-900">
                School Notices for Parents
              </h3>
              <div className="space-y-2.5">
                {parentNotices.slice(0, 2).map((notice) => (
                  <div
                    key={notice.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/70 space-y-1"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-900">{notice.title}</span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {notice.publishedDate}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">{notice.message}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* --- PAGE: ATTENDANCE CALENDAR --- */}
        {currentPage === 'attendance' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">
                {child.name}'s Attendance Log
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Detailed record of punctuality and presence for the academic term.
              </p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Class</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Remark</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-800">
                  {childAttendanceHistory.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/60">
                      <td className="py-3 px-4 font-mono font-semibold">{rec.date}</td>
                      <td className="py-3 px-4">{child.className} ({child.section})</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-md font-semibold text-[10px] ${
                            rec.status === 'present'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-rose-50 text-rose-700'
                          }`}
                        >
                          {rec.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-500">{rec.remarks || 'Regular Attendance'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* --- PAGE: HOMEWORK --- */}
        {currentPage === 'homework' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  Homework & Assignments
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Tasks assigned by {child.schoolName} teachers.
                </p>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setHomeworkFilter('all')}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    homeworkFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  All ({childHomework.length})
                </button>
                <button
                  type="button"
                  onClick={() => setHomeworkFilter('pending')}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    homeworkFilter === 'pending'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Pending Review
                </button>
                <button
                  type="button"
                  onClick={() => setHomeworkFilter('reviewed')}
                  className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    homeworkFilter === 'reviewed'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Reviewed
                </button>
              </div>
            </div>

            <div className="space-y-3.5">
              {filteredHomework.map((hw) => (
                <div
                  key={hw.id}
                  className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-orange-300 transition-colors"
                >
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-50 text-orange-700 border border-orange-200">
                        {hw.subject}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900">{hw.title}</h3>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">{hw.instructions}</p>

                    <div className="flex items-center gap-4 text-xs text-slate-500 pt-1 font-mono">
                      <span>Assigned: {hw.assignedDate}</span>
                      <span className="text-rose-600 font-semibold">Due: {hw.dueDate}</span>
                      <span className="text-slate-400">Teacher: {hw.teacherName}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onToggleHomeworkReviewed(hw.id)}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer ${
                      hw.reviewedByParent
                        ? 'bg-emerald-600 text-white shadow-2xs'
                        : 'bg-white border border-slate-300 text-slate-700 hover:border-orange-500 hover:text-orange-600'
                    }`}
                  >
                    {hw.reviewedByParent ? (
                      <>
                        <CheckSquare className="w-4 h-4" />
                        <span>Reviewed at Home</span>
                      </>
                    ) : (
                      <>
                        <Square className="w-4 h-4" />
                        <span>Mark as Reviewed</span>
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- PAGE: NOTICES --- */}
        {currentPage === 'notices' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">
                School Notices & Circulars
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Official announcements published for student guardians.
              </p>
            </div>

            <div className="space-y-3.5">
              {parentNotices.map((n) => (
                <div
                  key={n.id}
                  className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-2 hover:border-purple-200 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                      {n.category}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">{n.publishedDate}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">{n.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                  <div className="pt-2 text-[11px] text-slate-400">
                    Published by: {n.publishedBy}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- PAGE: PROFILE --- */}
        {currentPage === 'profile' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">
                Student & Guardian Information
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Official institutional record for {child.name}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Student Record */}
              <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-3 text-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-orange-700 block mb-2">
                  Student Record
                </span>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Student Name:</span>
                  <span className="font-bold text-slate-900">{child.name}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Class & Section:</span>
                  <span className="font-bold text-slate-900">{child.className} ({child.section})</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Roll Number:</span>
                  <span className="font-mono font-bold text-slate-900">{child.rollNo}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Institution:</span>
                  <span className="font-semibold text-slate-800">{child.schoolName}</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-500">Blood Group:</span>
                  <span className="font-mono text-slate-900">{child.bloodGroup || 'B+'}</span>
                </div>
              </div>

              {/* Guardian Contact Record */}
              <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-3 text-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-blue-700 block mb-2">
                  Guardian Contact
                </span>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Guardian Name:</span>
                  <span className="font-bold text-slate-900">{currentParent.name}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Relationship:</span>
                  <span className="font-bold text-slate-900">{currentParent.relation}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Emergency Phone:</span>
                  <span className="font-mono font-bold text-slate-900">{currentParent.phone}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-100">
                  <span className="text-slate-500">Email:</span>
                  <span className="text-slate-700">{currentParent.email}</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-500">Home Address:</span>
                  <span className="text-slate-700">{currentParent.address}</span>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* --- PAGE: MESSAGING --- */}
        {currentPage === 'messaging' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">Messaging Center</h1>
              <p className="text-xs text-slate-500 mt-0.5">Communicate with your child's teachers.</p>
            </div>
            
            <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs min-h-[400px]">
              <p className="text-xs text-slate-500 italic">Messaging interface placeholder. Select a teacher to start a conversation.</p>
            </div>
          </div>
        )}
      </div>

      {/* 3. Mobile Bottom Navigation Bar (Large Touch Targets >= 44px) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 flex items-center justify-around h-16 px-2 shadow-lg">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setCurrentPage(item.id)}
              className={`flex flex-col items-center justify-center flex-1 h-full py-1 min-h-[44px] cursor-pointer transition-colors ${
                isActive
                  ? 'text-orange-600 font-bold'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};
