import React, { useState, useMemo } from 'react';
import {
  LayoutDashboard,
  Building2,
  UserCheck,
  Users,
  GraduationCap,
  Bell,
  FileSpreadsheet,
  Settings as SettingsIcon,
  Search,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  Download,
  CheckCircle2,
  XCircle,
  Clock,
  WifiOff,
  MapPin,
  ChevronRight,
  X,
  Phone,
  Mail,
  RotateCcw,
  Upload,
  AlertCircle,
  ShieldCheck,
  Filter,
} from 'lucide-react';
import {
  AppSettings,
  AuthorityPage,
  Notice,
  NoticeAudience,
  NoticeCategory,
  School,
  SchoolCategory,
  Student,
  Teacher,
  TeacherAttendanceRecord,
} from '../../types';
import {
  calculateAttendanceStats,
  calculateSchoolSummaries,
  generateAttendanceCsv,
  generateStudentAttendanceCsv,
  filterRecords,
} from '../../utils/attendanceLogic';
import { getTodayDateString, StorageService } from '../../services/storageService';

interface AuthorityPortalProps {
  schools: School[];
  teachers: Teacher[];
  students: Student[];
  attendanceRecords: TeacherAttendanceRecord[];
  notices: Notice[];
  settings: AppSettings;
  onAddSchool: (school: Omit<School, 'id'>) => void;
  onUpdateSchool: (school: School) => void;
  onDeleteSchool: (id: string) => void;
  onAddTeacher: (teacher: Omit<Teacher, 'id'>) => void;
  onUpdateTeacher: (teacher: Teacher) => void;
  onDeleteTeacher: (id: string) => void;
  onAddNotice: (notice: Omit<Notice, 'id' | 'createdAt'>) => void;
  onUpdateNotice: (notice: Notice) => void;
  onDeleteNotice: (id: string) => void;
  onResetToDefault: () => void;
  onClearAll: () => void;
  onExportBackup: () => void;
  onImportBackup: (jsonStr: string) => boolean;
}

export const AuthorityPortal: React.FC<AuthorityPortalProps> = ({
  schools,
  teachers,
  students,
  attendanceRecords,
  notices,
  settings,
  onAddSchool,
  onUpdateSchool,
  onDeleteSchool,
  onAddTeacher,
  onUpdateTeacher,
  onDeleteTeacher,
  onAddNotice,
  onUpdateNotice,
  onDeleteNotice,
  onResetToDefault,
  onClearAll,
  onExportBackup,
  onImportBackup,
}) => {
  const isBn = settings.language === 'bn';
  const [currentPage, setCurrentPage] = useState<AuthorityPage>('overview');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());
  const todayStr = getTodayDateString();

  // Dynamic calculations
  const stats = calculateAttendanceStats(teachers, attendanceRecords, selectedDate);
  const schoolSummaries = calculateSchoolSummaries(
    schools,
    teachers,
    attendanceRecords,
    selectedDate
  );

  // --- Notice Form State ---
  const [isNoticeModalOpen, setIsNoticeModalOpen] = useState(false);
  const [noticeFormData, setNoticeFormData] = useState({
    title: '',
    message: '',
    category: 'Academic' as NoticeCategory,
    audience: 'all' as NoticeAudience,
    publishedBy: 'Upazila Secondary Education Directorate',
  });

  const handlePublishNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeFormData.title.trim() || !noticeFormData.message.trim()) return;
    onAddNotice({
      ...noticeFormData,
      publishedDate: todayStr,
      status: 'published',
    });
    setIsNoticeModalOpen(false);
    setNoticeFormData({
      title: '',
      message: '',
      category: 'Academic',
      audience: 'all',
      publishedBy: 'Upazila Secondary Education Directorate',
    });
  };

  // --- School Modal State ---
  const [isSchoolModalOpen, setIsSchoolModalOpen] = useState(false);
  const [editingSchool, setEditingSchool] = useState<School | null>(null);
  const [schoolFormData, setSchoolFormData] = useState({
    name: '',
    nameBn: '',
    eiin: '',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Secondary High School' as SchoolCategory,
    status: 'active' as ('active' | 'inactive'),
    contactPhone: '',
    address: '',
    establishedYear: 1990,
  });

  const handleOpenAddSchool = () => {
    setEditingSchool(null);
    setSchoolFormData({
      name: '',
      nameBn: '',
      eiin: '',
      upazila: 'Chatkhil',
      district: 'Noakhali',
      category: 'Secondary High School',
      status: 'active',
      contactPhone: '',
      address: '',
      establishedYear: 1990,
    });
    setIsSchoolModalOpen(true);
  };

  const handleOpenEditSchool = (s: School) => {
    setEditingSchool(s);
    setSchoolFormData({
      name: s.name,
      nameBn: s.nameBn || '',
      eiin: s.eiin,
      upazila: s.upazila,
      district: s.district,
      category: s.category as SchoolCategory,
      status: s.status as 'active' | 'inactive',
      contactPhone: s.contactPhone,
      address: s.address,
      establishedYear: s.establishedYear,
    });
    setIsSchoolModalOpen(true);
  };

  const handleSaveSchool = (e: React.FormEvent) => {
    e.preventDefault();
    if (!schoolFormData.name.trim() || !schoolFormData.eiin.trim()) return;
    if (editingSchool) {
      onUpdateSchool({
        ...editingSchool,
        ...schoolFormData,
      });
    } else {
      onAddSchool(schoolFormData);
    }
    setIsSchoolModalOpen(false);
  };

  // --- Teacher Modal State ---
  const [isTeacherModalOpen, setIsTeacherModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [teacherFormData, setTeacherFormData] = useState({
    name: '',
    nameBn: '',
    designation: 'Assistant Teacher',
    designationBn: 'সহকারী শিক্ষক',
    schoolId: schools[0]?.id || 'SCH-01',
    schoolName: schools[0]?.name || 'Chatkhil Panchgaon Mahbub Government College',
    phone: '',
    email: '',
    subject: 'General Science',
    joinDate: todayStr,
    status: 'active' as ('active' | 'inactive'),
  });

  const handleOpenAddTeacher = () => {
    setEditingTeacher(null);
    setTeacherFormData({
      name: '',
      nameBn: '',
      designation: 'Assistant Teacher',
      designationBn: 'সহকারী শিক্ষক',
      schoolId: schools[0]?.id || 'SCH-01',
      schoolName: schools[0]?.name || 'Chatkhil Panchgaon Mahbub Government College',
      phone: '',
      email: '',
      subject: 'General Science',
      joinDate: todayStr,
      status: 'active',
    });
    setIsTeacherModalOpen(true);
  };

  const handleOpenEditTeacher = (t: Teacher) => {
    setEditingTeacher(t);
    setTeacherFormData({
      name: t.name,
      nameBn: t.nameBn || '',
      designation: t.designation,
      designationBn: t.designationBn || '',
      schoolId: t.schoolId,
      schoolName: t.schoolName,
      phone: t.phone,
      email: t.email,
      subject: t.subject,
      joinDate: t.joinDate,
      status: t.status as 'active' | 'inactive',
    });
    setIsTeacherModalOpen(true);
  };

  const handleSaveTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!teacherFormData.name.trim()) return;
    const targetSchool = schools.find((s) => s.id === teacherFormData.schoolId);
    const resolvedData = {
      ...teacherFormData,
      schoolName: targetSchool ? targetSchool.name : teacherFormData.schoolName,
    };
    if (editingTeacher) {
      onUpdateTeacher({
        ...editingTeacher,
        ...resolvedData,
      });
    } else {
      onAddTeacher(resolvedData);
    }
    setIsTeacherModalOpen(false);
  };

  // --- Filtering States ---
  const [attendanceSearch, setAttendanceSearch] = useState('');
  const [attendanceStatusFilter, setAttendanceStatusFilter] = useState<string>('all');
  const [schoolCategoryFilter, setSchoolCategoryFilter] = useState<string>('all');
  const [teacherSearch, setTeacherSearch] = useState('');
  const [studentSearch, setStudentSearch] = useState('');
  const [studentClassFilter, setStudentClassFilter] = useState('all');

  // Filtered attendance records for selected date
  const filteredAttendance = useMemo(() => {
    const records = filterRecords(attendanceRecords, {
      startDate: selectedDate,
      endDate: selectedDate,
      status: attendanceStatusFilter === 'all' ? undefined : (attendanceStatusFilter as any),
      searchQuery: attendanceSearch,
    });
    return records;
  }, [attendanceRecords, selectedDate, attendanceStatusFilter, attendanceSearch]);

  // Filtered schools
  const filteredSchools = useMemo(() => {
    return schools.filter((s) => {
      const matchCat =
        schoolCategoryFilter === 'all' ||
        (schoolCategoryFilter === 'secondary' && s.category.includes('Secondary')) ||
        (schoolCategoryFilter === 'madrasah' && s.category.includes('Madrasah')) ||
        (schoolCategoryFilter === 'primary' && s.category.includes('Primary'));
      return matchCat;
    });
  }, [schools, schoolCategoryFilter]);

  // Filtered teachers
  const filteredTeachers = useMemo(() => {
    return teachers.filter(
      (t) =>
        t.name.toLowerCase().includes(teacherSearch.toLowerCase()) ||
        t.schoolName.toLowerCase().includes(teacherSearch.toLowerCase()) ||
        t.subject.toLowerCase().includes(teacherSearch.toLowerCase())
    );
  }, [teachers, teacherSearch]);

  // Filtered students
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchSearch =
        s.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
        s.rollNo.includes(studentSearch) ||
        s.schoolName.toLowerCase().includes(studentSearch.toLowerCase());
      const matchClass =
        studentClassFilter === 'all' || s.className.toLowerCase().includes(studentClassFilter);
      return matchSearch && matchClass;
    });
  }, [students, studentSearch, studentClassFilter]);

  // Download CSV Handler
  const handleDownloadAttendanceCsv = () => {
    const csv = generateAttendanceCsv(filteredAttendance);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `attendance-report-${selectedDate}.csv`;
    link.click();
  };

  // Nav Items
  const navItems = [
    { id: 'overview' as AuthorityPage, label: isBn ? 'সার্বিক চিত্র' : 'Overview', icon: LayoutDashboard },
    { id: 'schools' as AuthorityPage, label: isBn ? 'প্রতিষ্ঠানসমূহ' : 'Schools', icon: Building2 },
    { id: 'attendance' as AuthorityPage, label: isBn ? 'শিক্ষক উপস্থিতি' : 'Teacher Attendance', icon: UserCheck },
    { id: 'teachers' as AuthorityPage, label: isBn ? 'শিক্ষক তালিকা' : 'Teacher Directory', icon: Users },
    { id: 'students' as AuthorityPage, label: isBn ? 'শিক্ষার্থীবৃন্দ' : 'Students', icon: GraduationCap },
    { id: 'notices' as AuthorityPage, label: isBn ? 'সরকারি নোটিশ' : 'Notices', icon: Bell },
    { id: 'reports' as AuthorityPage, label: isBn ? 'রিপোর্ট ও বিশ্লেষণ' : 'Reports & Analytics', icon: FileSpreadsheet },
    { id: 'settings' as AuthorityPage, label: isBn ? 'সেটিংস ও ব্যাকআপ' : 'Settings', icon: SettingsIcon },
  ];

  return (
    <div className="flex flex-col md:flex-row gap-6 min-h-[85vh]">
      {/* 1. Authority Sidebar (Crisp White with Navy Typography) */}
      <aside className="w-full md:w-64 flex-shrink-0">
        <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-2xs space-y-4">
          <div className="px-3 py-2 border-b border-slate-100 space-y-1">
            <span className="text-[10px] uppercase font-bold text-blue-600 tracking-wider block">
              {isBn ? 'উপজেলা শিক্ষা কার্যালয়' : 'Upazila Education Office'}
            </span>
            <h2 className="text-sm font-bold text-slate-900">
              {isBn ? 'উপজেলা: চাটখিল' : 'Upazila: Chatkhil'}
            </h2>
            <div className="text-[11px] text-slate-600 space-y-0.5 pt-0.5 border-t border-slate-50">
              <div>{isBn ? 'জেলা: নোয়াখালী' : 'District: Noakhali'}</div>
              <div>{isBn ? 'বিভাগ: চট্টগ্রাম' : 'Division: Chattogram'}</div>
              <div>{isBn ? 'দেশ: বাংলাদেশ' : 'Country: Bangladesh'}</div>
            </div>
          </div>

          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCurrentPage(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all text-left cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="whitespace-nowrap truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </aside>

      {/* 2. Main Authority Viewport */}
      <div className="flex-1 space-y-6">
        {/* --- PAGE: OVERVIEW --- */}
        {currentPage === 'overview' && (
          <div className="space-y-6">
            {/* Top Bar with Date Selector */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {isBn ? 'প্রাতিষ্ঠানিক সার্বিক চিত্র ও পরিদর্শন' : 'Institutional Overview & Monitoring'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isBn
                    ? 'চাটখিল উপজেলার শিক্ষাপ্রতিষ্ঠানসমূহের সামগ্রিক উপস্থিতি ও প্রশাসনিক পরিসংখ্যান।'
                    : 'Aggregate administration metrics for schools in Chatkhil Upazila.'}
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span className="font-semibold text-slate-700">
                  {isBn ? 'তারিখ:' : 'Date:'}
                </span>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold bg-white text-slate-800 outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* KPI Summary Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5">
              <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
                <span className="text-[11px] font-semibold text-slate-500 uppercase">{isBn ? 'প্রতিষ্ঠান' : 'Schools'}</span>
                <p className="text-2xl font-black text-slate-900 mt-1 tabular-nums font-mono">{schools.length}</p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
                <span className="text-[11px] font-semibold text-slate-500 uppercase">{isBn ? 'শিক্ষার্থী' : 'Students'}</span>
                <p className="text-2xl font-black text-slate-900 mt-1 tabular-nums font-mono">{students.length}</p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
                <span className="text-[11px] font-semibold text-slate-500 uppercase">{isBn ? 'শিক্ষক' : 'Teachers'}</span>
                <p className="text-2xl font-black text-slate-900 mt-1 tabular-nums font-mono">{teachers.length}</p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
                <span className="text-[11px] font-semibold text-slate-500 uppercase">{isBn ? 'আজ উপস্থিত' : 'Present'}</span>
                <p className="text-2xl font-black text-emerald-700 mt-1 tabular-nums font-mono">{stats.presentCount}</p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
                <span className="text-[11px] font-semibold text-slate-500 uppercase">{isBn ? 'অনুপস্থিত' : 'Absent'}</span>
                <p className="text-2xl font-black text-rose-700 mt-1 tabular-nums font-mono">{stats.absentCount}</p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-2xs">
                <span className="text-[11px] font-semibold text-slate-500 uppercase">{isBn ? 'ছুটি' : 'Leave'}</span>
                <p className="text-2xl font-black text-amber-700 mt-1 tabular-nums font-mono">0</p>
              </div>
            </div>

            {/* School-Wise Comparative Breakdown Table */}
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-slate-900">
                    {isBn ? 'বিদ্যালয়ভিত্তিক উপস্থিতি বিবরণী' : 'School-Wise Attendance Summary'}
                  </h2>
                  <p className="text-xs text-slate-500">
                    {isBn
                      ? 'প্রতিটি প্রতিষ্ঠানের শিক্ষক উপস্থিতির হার ও অবস্থা'
                      : 'Real-time attendance rate for each participating school'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleDownloadAttendanceCsv}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 border border-blue-200/60 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সিএসভি ডাউনলোড' : 'Export CSV'}</span>
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-100">
                    <tr>
                      <th className="py-3 px-4">{isBn ? 'বিদ্যালয়ের নাম' : 'Institution'}</th>
                      <th className="py-3 px-4">{isBn ? 'EIIN' : 'EIIN'}</th>
                      <th className="py-3 px-4">{isBn ? 'মোট শিক্ষক' : 'Teachers'}</th>
                      <th className="py-3 px-4">{isBn ? 'উপস্থিত' : 'Present'}</th>
                      <th className="py-3 px-4">{isBn ? 'দেরিতে' : 'Late'}</th>
                      <th className="py-3 px-4">{isBn ? 'অনুপস্থিত' : 'Absent'}</th>
                      <th className="py-3 px-4">{isBn ? 'উপস্থিতির হার' : 'Rate'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {schoolSummaries.map((summary) => (
                      <tr key={summary.schoolId} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3 px-4 font-semibold text-slate-900">
                          {summary.schoolName}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-500">
                          {summary.eiin}
                        </td>
                        <td className="py-3 px-4 tabular-nums font-mono">
                          {summary.totalTeachers}
                        </td>
                        <td className="py-3 px-4 tabular-nums font-mono text-emerald-600 font-semibold">
                          {summary.presentCount}
                        </td>
                        <td className="py-3 px-4 tabular-nums font-mono text-amber-600">
                          {summary.totalTeachers - summary.presentCount - summary.absentCount}
                        </td>
                        <td className="py-3 px-4 tabular-nums font-mono text-rose-600">
                          {summary.absentCount}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <span className="font-bold tabular-nums font-mono text-slate-900">
                              {summary.attendanceRate}%
                            </span>
                            <div className="w-16 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                              <div
                                style={{ width: `${summary.attendanceRate}%` }}
                                className={`h-full ${
                                  summary.attendanceRate >= 80
                                    ? 'bg-emerald-500'
                                    : summary.attendanceRate >= 50
                                    ? 'bg-amber-500'
                                    : 'bg-rose-500'
                                }`}
                              />
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* --- PAGE: SCHOOLS --- */}
        {currentPage === 'schools' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {isBn ? 'অন্তর্ভুক্ত শিক্ষাপ্রতিষ্ঠানসমূহ' : 'Registered Institutions'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isBn
                    ? 'চাটখিল উপজেলার আওতাধীন সকল প্রাথমিক, মাধ্যমিক ও মাদ্রাসা প্রতিষ্ঠান।'
                    : 'Manage school records, inspection profiles, and administrative contacts.'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddSchool}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-xs cursor-pointer transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'নতুন প্রতিষ্ঠান যোগ করুন' : 'Add Institution'}</span>
              </button>
            </div>

            {/* School Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {schools.map((school) => (
                <div
                  key={school.id}
                  className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs flex flex-col justify-between hover:border-blue-300 transition-colors"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditSchool(school)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-slate-50 cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteSchool(school.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-50 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div>
                      <span className="text-[11px] font-mono font-semibold text-slate-500">
                        EIIN: {school.eiin}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 leading-snug">
                        {isBn && school.nameBn ? school.nameBn : school.name}
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">{school.category}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{school.address}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{school.contactPhone}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span>Est. {school.establishedYear}</span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 font-semibold">
                      Active
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- PAGE: TEACHER ATTENDANCE --- */}
        {currentPage === 'attendance' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {isBn ? 'শিক্ষকদের দৈনিক উপস্থিতি নিরীক্ষা' : 'Teacher Attendance Monitoring'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isBn
                    ? 'জিপিএস অবস্থান ও সময়সহ শিক্ষকদের উপস্থিতির লাইভ ও সংরক্ষিত রেকর্ড।'
                    : 'Punctuality records, geolocation check-ins, and daily status logs.'}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold bg-white text-slate-800"
                />
                <button
                  type="button"
                  onClick={handleDownloadAttendanceCsv}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সিএসভি এক্সপোর্ট' : 'Download CSV'}</span>
                </button>
              </div>
            </div>

            {/* Attendance Filters */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200/90">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder={isBn ? 'শিক্ষক বা বিদ্যালয়ের নাম দিয়ে খুঁজুন...' : 'Search teacher or school...'}
                  value={attendanceSearch}
                  onChange={(e) => setAttendanceSearch(e.target.value)}
                  className="pl-9 pr-3 py-1.5 rounded-lg text-xs border border-slate-200 w-full outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center gap-1.5">
                <Filter className="w-4 h-4 text-slate-400" />
                <select
                  value={attendanceStatusFilter}
                  onChange={(e) => setAttendanceStatusFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg text-xs border border-slate-200 bg-white text-slate-800 outline-none"
                >
                  <option value="all">{isBn ? 'সকল স্ট্যাটাস' : 'All Statuses'}</option>
                  <option value="present">{isBn ? 'উপস্থিত' : 'Present'}</option>
                  <option value="late">{isBn ? 'বিলম্বিত' : 'Late'}</option>
                  <option value="absent">{isBn ? 'অনুপস্থিত' : 'Absent'}</option>
                  <option value="leave">{isBn ? 'ছুটিতে' : 'On Leave'}</option>
                </select>
              </div>
            </div>

            {/* Attendance Table */}
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-100">
                    <tr>
                      <th className="py-3 px-4">{isBn ? 'শিক্ষক' : 'Teacher'}</th>
                      <th className="py-3 px-4">{isBn ? 'প্রতিষ্ঠান' : 'School'}</th>
                      <th className="py-3 px-4">{isBn ? 'চেক-ইন' : 'Check-In'}</th>
                      <th className="py-3 px-4">{isBn ? 'চেক-আউট' : 'Check-Out'}</th>
                      <th className="py-3 px-4">{isBn ? 'অবস্থা' : 'Status'}</th>
                      <th className="py-3 px-4">{isBn ? 'জিপিএস অবস্থান' : 'GPS Location'}</th>
                      <th className="py-3 px-4">{isBn ? 'সিঙ্ক' : 'Sync'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {filteredAttendance.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-400">
                          {isBn ? 'কোনো উপস্থিতি রেকর্ড পাওয়া যায়নি।' : 'No attendance records found for this date.'}
                        </td>
                      </tr>
                    ) : (
                      filteredAttendance.map((rec) => (
                        <tr key={rec.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-900">{rec.teacherName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{rec.teacherId}</div>
                          </td>
                          <td className="py-3 px-4 text-slate-600 truncate max-w-[200px]">
                            {rec.schoolName}
                          </td>
                          <td className="py-3 px-4 tabular-nums font-mono text-slate-700">
                            {rec.checkInTime || '—'}
                          </td>
                          <td className="py-3 px-4 tabular-nums font-mono text-slate-700">
                            {rec.checkOutTime || '—'}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-0.5 rounded-md font-semibold text-[10px] ${
                                rec.status === 'present'
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                                  : rec.status === 'late'
                                  ? 'bg-amber-50 text-amber-700 border border-amber-200/60'
                                  : rec.status === 'leave'
                                  ? 'bg-blue-50 text-blue-700 border border-blue-200/60'
                                  : 'bg-rose-50 text-rose-700 border border-rose-200/60'
                              }`}
                            >
                              {rec.status.toUpperCase()}
                            </span>
                          </td>
                          <td className="py-3 px-4 font-mono text-[10px] text-slate-500">
                            {rec.location ? (
                              <span title={`Accuracy: ${rec.location.accuracy || 15}m`}>
                                {rec.location.latitude.toFixed(4)}, {rec.location.longitude.toFixed(4)}
                              </span>
                            ) : (
                              'Local Terminal'
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`text-[10px] font-semibold ${
                                rec.syncStatus === 'synced' ? 'text-emerald-600' : 'text-amber-600'
                              }`}
                            >
                              {rec.syncStatus}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* --- PAGE: TEACHERS --- */}
        {currentPage === 'teachers' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {isBn ? 'উপজেলা শিক্ষক ডিরেক্টরি' : 'Teacher Directory'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isBn
                    ? 'চাটখিল উপজেলার আওতাধীন সকল শিক্ষকের তালিকা ও দায়িত্ব।'
                    : 'Faculty records, assigned subjects, and institutional affiliations.'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleOpenAddTeacher}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-xs cursor-pointer transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'নতুন শিক্ষক যোগ করুন' : 'Add Teacher'}</span>
              </button>
            </div>

            {/* Teachers Table */}
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-100">
                <input
                  type="text"
                  placeholder={isBn ? 'শিক্ষক বা বিষয় দিয়ে ফিল্টার করুন...' : 'Search teacher by name or subject...'}
                  value={teacherSearch}
                  onChange={(e) => setTeacherSearch(e.target.value)}
                  className="px-3 py-1.5 rounded-lg text-xs border border-slate-200 w-full sm:w-72 outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-100">
                    <tr>
                      <th className="py-3 px-4">{isBn ? 'শিক্ষকের নাম' : 'Name'}</th>
                      <th className="py-3 px-4">{isBn ? 'পদবী ও বিষয়' : 'Designation & Subject'}</th>
                      <th className="py-3 px-4">{isBn ? 'বিদ্যালয়' : 'School'}</th>
                      <th className="py-3 px-4">{isBn ? 'যোগাযোগ' : 'Contact'}</th>
                      <th className="py-3 px-4">{isBn ? 'যোগদানের তারিখ' : 'Joined'}</th>
                      <th className="py-3 px-4 text-right">{isBn ? 'অ্যাকশন' : 'Actions'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {filteredTeachers.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">{t.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{t.id}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-800">{t.designation}</div>
                          <div className="text-[11px] text-blue-600">{t.subject}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-600">{t.schoolName}</td>
                        <td className="py-3 px-4 text-slate-500 text-[11px]">
                          <div>{t.phone}</div>
                          <div className="text-slate-400">{t.email}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                          {t.joinDate}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              onClick={() => handleOpenEditTeacher(t)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-slate-50 cursor-pointer"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteTeacher(t.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-50 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* --- PAGE: STUDENTS --- */}
        {currentPage === 'students' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {isBn ? 'শিক্ষার্থী তথ্যাবলী' : 'Student Directory'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isBn
                    ? 'শ্রেণিভিত্তিক শিক্ষার্থী রোল, অভিভাবকের যোগাযোগ ও উপস্থিতির বিবরণী।'
                    : 'Enrolled students across upazila schools with guardian linkages.'}
                </p>
              </div>
            </div>

            {/* Students Table */}
            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  placeholder={isBn ? 'শিক্ষার্থীর নাম বা রোল দিয়ে খুঁজুন...' : 'Search student by name or roll...'}
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  className="px-3 py-1.5 rounded-lg text-xs border border-slate-200 w-full sm:w-72 outline-none focus:ring-1 focus:ring-blue-500"
                />

                <select
                  value={studentClassFilter}
                  onChange={(e) => setStudentClassFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-lg text-xs border border-slate-200 bg-white text-slate-800 outline-none"
                >
                  <option value="all">{isBn ? 'সকল শ্রেণি' : 'All Classes'}</option>
                  <option value="class 6">{isBn ? 'ষষ্ঠ শ্রেণি' : 'Class 6'}</option>
                  <option value="class 7">{isBn ? 'সপ্তম শ্রেণি' : 'Class 7'}</option>
                  <option value="class 8">{isBn ? 'অষ্টম শ্রেণি' : 'Class 8'}</option>
                  <option value="class 9">{isBn ? 'নবম শ্রেণি' : 'Class 9'}</option>
                  <option value="class 10">{isBn ? 'দশম শ্রেণি' : 'Class 10'}</option>
                </select>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-100">
                    <tr>
                      <th className="py-3 px-4">{isBn ? 'শিক্ষার্থী' : 'Student'}</th>
                      <th className="py-3 px-4">{isBn ? 'শ্রেণি ও রোল' : 'Class & Roll'}</th>
                      <th className="py-3 px-4">{isBn ? 'বিদ্যালয়' : 'School'}</th>
                      <th className="py-3 px-4">{isBn ? 'অভিভাবকের নাম' : 'Guardian'}</th>
                      <th className="py-3 px-4">{isBn ? 'যোগাযোগ নম্বর' : 'Emergency Contact'}</th>
                      <th className="py-3 px-4">{isBn ? 'স্ট্যাটাস' : 'Status'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {filteredStudents.map((st) => (
                      <tr key={st.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3 px-4 font-semibold text-slate-900">{st.name}</td>
                        <td className="py-3 px-4 font-mono">
                          {st.className} ({st.section}) · Roll {st.rollNo}
                        </td>
                        <td className="py-3 px-4 text-slate-600">{st.schoolName}</td>
                        <td className="py-3 px-4 text-slate-800">{st.guardianName}</td>
                        <td className="py-3 px-4 font-mono text-slate-600">{st.guardianPhone}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-semibold ${
                              st.attendanceStatusToday === 'present'
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {st.attendanceStatusToday ? st.attendanceStatusToday.toUpperCase() : 'PENDING'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* --- PAGE: NOTICES --- */}
        {currentPage === 'notices' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {isBn ? 'সরকারি নোটিশ ও পরিপত্র' : 'Official Circulars & Notices'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isBn
                    ? 'উপজেলা কার্যালয় থেকে শিক্ষক ও অভিভাবকদের উদ্দেশ্যে প্রকাশিত জরুরি নির্দেশনাবলী।'
                    : 'Broadcast circulars and official instructions across schools and parent feeds.'}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsNoticeModalOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-xs cursor-pointer transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'নতুন নোটিশ জারি করুন' : 'Issue Circular'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {notices.map((n) => (
                <div
                  key={n.id}
                  className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs flex flex-col justify-between hover:border-blue-200 transition-colors"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200/60">
                        {n.category}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {n.publishedDate}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900">{n.title}</h3>
                    <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-400 text-[11px]">
                      {isBn ? 'প্রাপক:' : 'Audience:'} {n.audience.toUpperCase()}
                    </span>
                    <button
                      type="button"
                      onClick={() => onDeleteNotice(n.id)}
                      className="p-1 rounded text-slate-400 hover:text-rose-600 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- PAGE: REPORTS & ANALYTICS --- */}
        {currentPage === 'reports' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  {isBn ? 'বিশ্লেষণ ও এক্সপোর্টযোগ্য প্রতিবেদন' : 'Analytics & Official Reports'}
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isBn
                    ? 'সরকারি নিরীক্ষা ও মাসিক পর্যালোচনার জন্য ডাউনলোডযোগ্য সিএসভি ফাইল।'
                    : 'Download audit-ready attendance spreadsheets for Chatkhil Upazila.'}
                </p>
              </div>

              <button
                type="button"
                onClick={handleDownloadAttendanceCsv}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-xs cursor-pointer transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>{isBn ? 'সিএসভি ডাউনলোড করুন' : 'Export Full CSV'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isBn ? 'শিক্ষক উপস্থিতি রিপোর্ট' : 'Teacher Attendance Report'}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {isBn
                    ? 'তারিখভিত্তিক শিক্ষক চেক-ইন, চেক-আউট ও জিপিএস স্থানাঙ্কের বিস্তারিত তথ্য।'
                    : 'Contains teacher timestamps, punch status, work duration, and verified coordinates.'}
                </p>
                <button
                  type="button"
                  onClick={handleDownloadAttendanceCsv}
                  className="w-full py-2 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold border border-blue-200/60 cursor-pointer"
                >
                  {isBn ? 'ডাউনলোড (.CSV)' : 'Download (.CSV)'}
                </button>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isBn ? 'শিক্ষার্থী উপস্থিতি সারাংশ' : 'Student Attendance Export'}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {isBn
                    ? 'শ্রেণি ও সেকশন অনুযায়ী শিক্ষার্থীদের দৈনিক উপস্থিতি ডাটা।'
                    : 'Class-wise student roster logs, guardian phone numbers, and daily roll call stats.'}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    const csv = generateStudentAttendanceCsv(StorageService.getStudentAttendance(), students);
                    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = `student-attendance-${selectedDate}.csv`;
                    link.click();
                  }}
                  className="w-full py-2 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100 text-xs font-semibold border border-purple-200/60 cursor-pointer"
                >
                  {isBn ? 'ডাউনলোড (.CSV)' : 'Download (.CSV)'}
                </button>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <Building2 className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isBn ? 'উপজেলা প্রাতিষ্ঠানিক পরিসংখ্যান' : 'Institutional Directory'}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {isBn
                    ? 'EIIN, প্রধান শিক্ষকের নাম, যোগাযোগ ও শিক্ষার্থী পরিসংখ্যান সমৃদ্ধ নথি।'
                    : 'Official institutional master list with EIIN codes and headmaster contact credentials.'}
                </p>
                <button
                  type="button"
                  onClick={onExportBackup}
                  className="w-full py-2 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-semibold border border-emerald-200/60 cursor-pointer"
                >
                  {isBn ? 'সম্পূর্ণ ব্যাকআপ (.JSON)' : 'Complete Backup (.JSON)'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* --- PAGE: SETTINGS & BACKUP --- */}
        {currentPage === 'settings' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">
                {isBn ? 'সেটিংস ও ব্যাকআপ ব্যবস্থাপনা' : 'System Administration & Data Controls'}
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                {isBn
                  ? 'লোকাল ডেটাসেট পুনরুদ্ধার, ব্যাকআপ ডাউনলোড এবং পরীক্ষামূলক ডেটা রিসেট।'
                  : 'Manage local datasets, backup storage, and test database states.'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                    <RotateCcw className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {isBn ? 'ডিফল্ট ডেটাসেট পুনরুদ্ধার' : 'Reset to Default Dataset'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {isBn ? 'চাটখিল উপজেলার ডেমো ডেটা পুনঃস্থাপন' : 'Restores initial 6 schools and faculty'}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {isBn
                    ? 'পুনরুদ্ধার করলে সকল ডেমো বিদ্যালয়, শিক্ষক, শিক্ষার্থী এবং নোটিশ প্রারম্ভিক অবস্থায় ফিরে আসবে।'
                    : 'Reverts local storage back to the pristine Bangladeshi school dataset.'}
                </p>

                <button
                  type="button"
                  onClick={onResetToDefault}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors cursor-pointer"
                >
                  {isBn ? 'প্রারম্ভিক তথ্য পুনরুদ্ধার করুন' : 'Restore Default Data'}
                </button>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                    <Download className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {isBn ? 'প্ল্যাটফর্ম ব্যাকআপ ও রিস্টোর' : 'Platform Backup & Restore'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {isBn ? 'JSON আকারে সংরক্ষণ' : 'JSON state snapshot export'}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {isBn
                    ? 'আপনার বর্তমান ব্রাউজারের সকল উপস্থিতি ও হোমওয়ার্ক রেকর্ড এক ফাইলে ডাউনলোড করুন।'
                    : 'Download full local state or upload an exported snapshot to continue demonstration.'}
                </p>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={onExportBackup}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white cursor-pointer"
                  >
                    {isBn ? 'ব্যাকআপ ডাউনলোড' : 'Export Snapshot'}
                  </button>

                  <label className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 cursor-pointer">
                    <span>{isBn ? 'ফাইল থেকে রিস্টোর' : 'Import JSON'}</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            const content = event.target?.result as string;
                            if (content) onImportBackup(content);
                          };
                          reader.readAsText(file);
                        }
                      }}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Notice Publisher Modal */}
      {isNoticeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                {isBn ? 'নতুন সার্কুলার / নোটিশ জারি করুন' : 'Issue Official Circular'}
              </h3>
              <button
                type="button"
                onClick={() => setIsNoticeModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePublishNotice} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'নোটিশের শিরোনাম' : 'Notice Title'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={isBn ? 'যেমন: বার্ষিক মূল্যায়ন ও ছুটির নোটিশ' : 'e.g. Assessment Schedule 2026'}
                  value={noticeFormData.title}
                  onChange={(e) => setNoticeFormData({ ...noticeFormData, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={noticeFormData.category}
                    onChange={(e) => setNoticeFormData({ ...noticeFormData, category: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                  >
                    <option value="Academic">Academic</option>
                    <option value="Administrative">Administrative</option>
                    <option value="Emergency">Emergency</option>
                    <option value="Holiday">Holiday</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {isBn ? 'প্রাপক' : 'Target Audience'}
                  </label>
                  <select
                    value={noticeFormData.audience}
                    onChange={(e) => setNoticeFormData({ ...noticeFormData, audience: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                  >
                    <option value="all">Everyone (All)</option>
                    <option value="teachers">Teachers Only</option>
                    <option value="parents">Parents Only</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'বিস্তারিত বার্তা' : 'Notice Content'}
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder={isBn ? 'পরিপত্রের বিস্তারিত লিখুন...' : 'Write circular details...'}
                  value={noticeFormData.message}
                  onChange={(e) => setNoticeFormData({ ...noticeFormData, message: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsNoticeModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold"
                >
                  {isBn ? 'প্রকাশ করুন' : 'Publish Circular'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* School Add/Edit Modal */}
      {isSchoolModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                {editingSchool
                  ? (isBn ? 'বিদ্যালয়ের তথ্য সংশোধন' : 'Edit Institution')
                  : (isBn ? 'নতুন বিদ্যালয় অন্তর্ভুক্তি' : 'Add New Institution')}
              </h3>
              <button
                type="button"
                onClick={() => setIsSchoolModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSchool} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'বিদ্যালয়ের নাম (English)' : 'School Name'}
                </label>
                <input
                  type="text"
                  required
                  value={schoolFormData.name}
                  onChange={(e) => setSchoolFormData({ ...schoolFormData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'বিদ্যালয়ের নাম (বাংলা)' : 'School Name (Bengali)'}
                </label>
                <input
                  type="text"
                  value={schoolFormData.nameBn}
                  onChange={(e) => setSchoolFormData({ ...schoolFormData, nameBn: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">EIIN</label>
                  <input
                    type="text"
                    required
                    value={schoolFormData.eiin}
                    onChange={(e) => setSchoolFormData({ ...schoolFormData, eiin: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {isBn ? 'প্রতিষ্ঠার বছর' : 'Est. Year'}
                  </label>
                  <input
                    type="number"
                    value={schoolFormData.establishedYear}
                    onChange={(e) => setSchoolFormData({ ...schoolFormData, establishedYear: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'ক্যাটাগরি' : 'Category'}
                </label>
                <select
                  value={schoolFormData.category}
                  onChange={(e) => setSchoolFormData({ ...schoolFormData, category: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                >
                  <option value="Secondary High School">Secondary High School</option>
                  <option value="Higher Secondary College">Higher Secondary College</option>
                  <option value="Dakhil Madrasah">Dakhil Madrasah</option>
                  <option value="Model Primary">Model Primary</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'যোগাযোগ নম্বর' : 'Phone'}
                </label>
                <input
                  type="text"
                  value={schoolFormData.contactPhone}
                  onChange={(e) => setSchoolFormData({ ...schoolFormData, contactPhone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'ঠিকানা' : 'Address'}
                </label>
                <input
                  type="text"
                  value={schoolFormData.address}
                  onChange={(e) => setSchoolFormData({ ...schoolFormData, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsSchoolModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Institution'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Teacher Add/Edit Modal */}
      {isTeacherModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                {editingTeacher
                  ? (isBn ? 'শিক্ষক প্রোফাইল সংশোধন' : 'Edit Teacher Profile')
                  : (isBn ? 'নতুন শিক্ষক অন্তর্ভুক্তি' : 'Add New Teacher')}
              </h3>
              <button
                type="button"
                onClick={() => setIsTeacherModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTeacher} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'শিক্ষকের নাম' : 'Teacher Name'}
                </label>
                <input
                  type="text"
                  required
                  value={teacherFormData.name}
                  onChange={(e) => setTeacherFormData({ ...teacherFormData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {isBn ? 'পদবী' : 'Designation'}
                  </label>
                  <input
                    type="text"
                    required
                    value={teacherFormData.designation}
                    onChange={(e) => setTeacherFormData({ ...teacherFormData, designation: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {isBn ? 'বিষয়' : 'Subject'}
                  </label>
                  <input
                    type="text"
                    required
                    value={teacherFormData.subject}
                    onChange={(e) => setTeacherFormData({ ...teacherFormData, subject: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {isBn ? 'বিদ্যালয়' : 'School'}
                </label>
                <select
                  value={teacherFormData.schoolId}
                  onChange={(e) => setTeacherFormData({ ...teacherFormData, schoolId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-white"
                >
                  {schools.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {isBn ? 'মোবাইল নম্বর' : 'Phone'}
                  </label>
                  <input
                    type="text"
                    value={teacherFormData.phone}
                    onChange={(e) => setTeacherFormData({ ...teacherFormData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {isBn ? 'ইমেইল' : 'Email'}
                  </label>
                  <input
                    type="email"
                    value={teacherFormData.email}
                    onChange={(e) => setTeacherFormData({ ...teacherFormData, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsTeacherModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Teacher'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
