import React, { useState, useMemo } from 'react';
import {
  LayoutDashboard,
  Clock,
  BookOpen,
  Users,
  FileText,
  Bell,
  User,
  CheckCircle2,
  AlertCircle,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  MapPin,
  LogOut,
  ChevronRight,
  School as SchoolIcon,
  Search,
  Check,
  X,
  Phone,
  GraduationCap,
  CheckSquare,
} from 'lucide-react';
import {
  ClassRoom,
  Homework,
  LocationData,
  Notice,
  School,
  Student,
  StudentAttendanceRecord,
  Teacher,
  TeacherAttendanceRecord,
  TeacherPage,
  LeaveApplication,
  DismissalNotice,
  Message,
} from '../../types';
import { GeolocationWidget } from '../../components/GeolocationWidget';
import { canCheckIn, canCheckOut } from '../../utils/attendanceLogic';
import { formatTime12h, getTodayDateString } from '../../services/storageService';

interface TeacherPortalProps {
  currentTeacher: Teacher;
  allTeachers: Teacher[];
  onSelectTeacherId: (id: string) => void;
  schools: School[];
  classes: ClassRoom[];
  students: Student[];
  homeworkList: Homework[];
  onAddHomework: (data: Omit<Homework, 'id' | 'createdAt'>) => void;
  onUpdateHomework: (item: Homework) => void;
  onDeleteHomework: (id: string) => void;
  notices: Notice[];
  attendanceRecords: TeacherAttendanceRecord[];
  studentAttendance: StudentAttendanceRecord[];
  onRecordCheckIn: (
    teacher: Teacher,
    options?: { location?: LocationData; status?: any; remarks?: string }
  ) => void;
  onRecordCheckOut: (teacherId: string) => void;
  onUpdateTeacher: (teacher: Teacher) => void;
  onUpdateStudentAttendance: (records: StudentAttendanceRecord[]) => void;
  leaveApplications: LeaveApplication[];
  dismissalNotices: DismissalNotice[];
  messages: Message[]; // New
  onSaveLeaveApplication: (app: LeaveApplication) => void;
  onSendDismissalNotice: (notice: DismissalNotice) => void;
  onSaveMessage: (message: Message) => void; // New
  isOfflineMode: boolean;
}

export const TeacherPortal: React.FC<TeacherPortalProps> = ({
  currentTeacher,
  allTeachers,
  onSelectTeacherId,
  schools,
  classes,
  students,
  homeworkList,
  onAddHomework,
  onUpdateHomework,
  onDeleteHomework,
  notices,
  attendanceRecords,
  studentAttendance,
  onRecordCheckIn,
  onRecordCheckOut,
  onUpdateTeacher,
  onUpdateStudentAttendance,
  leaveApplications,
  dismissalNotices,
  messages,
  onSaveLeaveApplication,
  onSendDismissalNotice,
  onSaveMessage,
  isOfflineMode,
}) => {
  const [currentPage, setCurrentPage] = useState<TeacherPage>('dashboard');
  const todayStr = getTodayDateString();

  // Selected class for drilldown
  const [selectedClassId, setSelectedClassId] = useState<string | null>(null);

  // Homework modal states
  const [isAddHwOpen, setIsAddHwOpen] = useState(false);
  const [editingHw, setEditingHw] = useState<Homework | null>(null);
  const [hwFormData, setHwFormData] = useState({
    title: '',
    subject: currentTeacher.subject.split('&')[0]?.trim() || 'Mathematics',
    classId: classes[0]?.id || '',
    instructions: '',
    dueDate: (() => {
      const d = new Date();
      d.setDate(d.getDate() + 2);
      return d.toISOString().split('T')[0];
    })(),
  });

  // Location and feedback
  const [capturedLocation, setCapturedLocation] = useState<LocationData | undefined>(undefined);
  const [attendanceFeedback, setAttendanceFeedback] = useState<string | null>(null);

  // Profile edit
  const [profilePhone, setProfilePhone] = useState(currentTeacher.phone);
  const [profileEmail, setProfileEmail] = useState(currentTeacher.email);
  const [profileSaved, setProfileSaved] = useState(false);

  // Today's attendance record
  const myTodayRecord = useMemo(() => {
    return attendanceRecords.find(
      (r) => r.teacherId === currentTeacher.id && r.date === todayStr
    );
  }, [attendanceRecords, currentTeacher, todayStr]);

  // Validation
  const checkInValidation = useMemo(() => {
    return canCheckIn(currentTeacher.id, todayStr, attendanceRecords);
  }, [currentTeacher.id, todayStr, attendanceRecords]);

  const checkOutValidation = useMemo(() => {
    return canCheckOut(currentTeacher.id, todayStr, attendanceRecords);
  }, [currentTeacher.id, todayStr, attendanceRecords]);

  // Classes taught by teacher
  const myClasses = useMemo(() => {
    return classes.filter(
      (c) =>
        c.classTeacherId === currentTeacher.id ||
        c.schedule.some((s) => s.teacherName.includes(currentTeacher.name.split(' ')[1] || ''))
    );
  }, [classes, currentTeacher]);

  const displayClasses = myClasses.length > 0 ? myClasses : classes;

  // Homework assigned by teacher
  const myHomework = useMemo(() => {
    return homeworkList.filter((h) => h.teacherId === currentTeacher.id);
  }, [homeworkList, currentTeacher]);

  // Teacher attendance history
  const myHistory = useMemo(() => {
    return attendanceRecords.filter((r) => r.teacherId === currentTeacher.id);
  }, [attendanceRecords, currentTeacher]);

  // Relevant notices
  const teacherNotices = useMemo(() => {
    return notices.filter(
      (n) =>
        n.status === 'published' &&
        (n.audience === 'all' || n.audience === 'teachers')
    );
  }, [notices]);

  // Actions
  const handleCheckIn = () => {
    if (!checkInValidation.allowed) {
      setAttendanceFeedback(checkInValidation.reason || 'Already marked today');
      return;
    }
    onRecordCheckIn(currentTeacher, {
      location: capturedLocation,
    });
    setAttendanceFeedback('Check-in recorded successfully!');
  };

  const handleCheckOut = () => {
    if (!checkOutValidation.allowed) {
      setAttendanceFeedback(checkOutValidation.reason || 'Cannot check out');
      return;
    }
    onRecordCheckOut(currentTeacher.id);
    setAttendanceFeedback('Check-out recorded successfully!');
  };

  const handleSaveHomework = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hwFormData.title.trim() || !hwFormData.instructions.trim()) return;

    const targetClass = classes.find((c) => c.id === hwFormData.classId);

    if (editingHw) {
      onUpdateHomework({
        ...editingHw,
        title: hwFormData.title,
        subject: hwFormData.subject,
        classId: hwFormData.classId,
        className: targetClass?.name || editingHw.className,
        section: targetClass?.section || editingHw.section,
        instructions: hwFormData.instructions,
        dueDate: hwFormData.dueDate,
      });
      setEditingHw(null);
    } else {
      onAddHomework({
        title: hwFormData.title,
        subject: hwFormData.subject,
        classId: hwFormData.classId,
        className: targetClass?.name || 'Class 9',
        section: targetClass?.section || 'Section A',
        schoolId: currentTeacher.schoolId,
        schoolName: currentTeacher.schoolName,
        teacherId: currentTeacher.id,
        teacherName: currentTeacher.name,
        assignedDate: todayStr,
        dueDate: hwFormData.dueDate,
        instructions: hwFormData.instructions,
        status: 'active',
      });
      setIsAddHwOpen(false);
    }

    setHwFormData({
      title: '',
      subject: currentTeacher.subject.split('&')[0]?.trim() || 'Mathematics',
      classId: classes[0]?.id || '',
      instructions: '',
      dueDate: (() => {
        const d = new Date();
        d.setDate(d.getDate() + 2);
        return d.toISOString().split('T')[0];
      })(),
    });
  };

  const navItems = [
    { id: 'dashboard' as TeacherPage, label: 'Workstation', icon: LayoutDashboard },
    { id: 'attendance' as TeacherPage, label: 'Daily Attendance', icon: Clock },
    { id: 'classes' as TeacherPage, label: 'My Classes & Routine', icon: Users },
    { id: 'homework' as TeacherPage, label: 'Homework Assignments', icon: BookOpen },
    { id: 'student-attendance' as TeacherPage, label: 'Student Attendance', icon: CheckSquare },
    { id: 'notices' as TeacherPage, label: 'Notices & Circulars', icon: Bell },
    { id: 'profile' as TeacherPage, label: 'Faculty Profile', icon: User },
  ];

  return (
    <div className="flex flex-col md:flex-row gap-6 min-h-[85vh]">
      {/* 1. Teacher Sidebar (White Background, Green & Teal Accents) */}
      <aside className="w-full md:w-64 flex-shrink-0">
        <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-2xs space-y-4">
          {/* Active Teacher Card with Switcher */}
          <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200/80 space-y-2.5">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-2xs">
                {currentTeacher.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <span className="font-bold text-slate-900 text-xs block truncate">
                  {currentTeacher.name}
                </span>
                <span className="text-[11px] font-semibold text-emerald-800 block truncate">
                  {currentTeacher.designation}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-emerald-200/60">
              <label className="block text-[10px] font-bold text-emerald-900 uppercase tracking-wider mb-1">
                Active Faculty Profile:
              </label>
              <select
                value={currentTeacher.id}
                onChange={(e) => onSelectTeacherId(e.target.value)}
                className="w-full px-2 py-1.5 rounded-lg text-xs font-semibold bg-white border border-emerald-200 text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500 cursor-pointer"
              >
                {allTeachers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.id})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCurrentPage(item.id)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all text-left cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="whitespace-nowrap truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </aside>

      {/* 2. Main Workstation Area */}
      <div className="flex-1 space-y-6">
        {/* --- PAGE: DASHBOARD --- */}
        {currentPage === 'dashboard' && (
          <div className="space-y-6">
            {/* Top Attendance Terminal Card (Very Prominent & Accessible) */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-1">
                    <Clock className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Daily Attendance Kiosk</span>
                  </div>
                  <h1 className="text-xl font-bold text-slate-900">
                    Welcome, {currentTeacher.name}
                  </h1>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {currentTeacher.schoolName} · {currentTeacher.subject}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {myTodayRecord ? (
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Checked In: {myTodayRecord.checkInTime}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold">
                      <Clock className="w-4 h-4 text-amber-600" />
                      <span>Pending Today's Check-In</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Attendance Terminal Actions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">
                {/* Check In Action Box */}
                <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200/80 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
                      Step 1: Morning Check-In
                    </span>
                    <p className="text-xs text-slate-600 mt-1">
                      Official arrival recording. Geolocation coordinates will be stamped automatically.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleCheckIn}
                    disabled={!checkInValidation.allowed}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer ${
                      checkInValidation.allowed
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {myTodayRecord ? 'Already Checked In Today' : 'Record Check-In Now'}
                    </span>
                  </button>
                </div>

                {/* Check Out Action Box */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-700">
                      Step 2: Afternoon Check-Out
                    </span>
                    <p className="text-xs text-slate-600 mt-1">
                      Punch departure after completing scheduled academic periods.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleCheckOut}
                    disabled={!checkOutValidation.allowed}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer ${
                      checkOutValidation.allowed
                        ? 'bg-blue-600 hover:bg-blue-700 text-white'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    }`}
                  >
                    <LogOut className="w-4 h-4" />
                    <span>
                      {myTodayRecord?.checkOutTime
                        ? `Checked Out at ${myTodayRecord.checkOutTime}`
                        : 'Record Check-Out Now'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Geolocation Widget */}
              <div className="mt-4 pt-4 border-t border-slate-100">
                <GeolocationWidget onLocationCaptured={setCapturedLocation} />
              </div>

              {attendanceFeedback && (
                <div className="mt-3 p-2.5 rounded-lg bg-blue-50 border border-blue-200 text-blue-800 text-xs font-medium flex items-center gap-2">
                  <Check className="w-4 h-4 text-blue-600" />
                  <span>{attendanceFeedback}</span>
                </div>
              )}
            </div>

            {/* Today's Schedule & Routine */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-slate-900">
                    Today's Academic Schedule
                  </h2>
                  <p className="text-xs text-slate-500">
                    Class periods and assignments for {currentTeacher.name}
                  </p>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700">
                  {todayStr}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {displayClasses.slice(0, 3).map((c, idx) => (
                  <div
                    key={c.id}
                    className="p-4 rounded-xl bg-slate-50 border border-slate-200/70 hover:border-emerald-300 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900">
                        {c.name} ({c.section})
                      </span>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                        Room {c.roomNo}
                      </span>
                    </div>
                    <p className="text-xs text-emerald-700 font-semibold mt-1">
                      {currentTeacher.subject}
                    </p>
                    <div className="mt-3 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
                      <span>Period {idx + 1}</span>
                      <span>10:00 AM – 10:45 AM</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">Homework Hub</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentPage('homework');
                      setIsAddHwOpen(true);
                    }}
                    className="text-xs font-bold text-emerald-700 hover:text-emerald-800"
                  >
                    + Assign New
                  </button>
                </div>
                <p className="text-xs text-slate-600">
                  You have assigned {myHomework.length} homework task(s). Newly added assignments are immediately visible in the Parent Portal feed.
                </p>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                      <Bell className="w-4 h-4" />
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">Notices</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCurrentPage('notices')}
                    className="text-xs font-bold text-purple-700 hover:text-purple-800"
                  >
                    View All ({teacherNotices.length})
                  </button>
                </div>
                <p className="text-xs text-slate-600">
                  {teacherNotices[0]?.title || 'No urgent announcements at this moment.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* --- PAGE: ATTENDANCE HISTORY --- */}
        {currentPage === 'attendance' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  My Attendance History
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Verified punch records for {currentTeacher.name} ({currentTeacher.id})
                </p>
              </div>

              <button
                type="button"
                onClick={handleCheckIn}
                disabled={!checkInValidation.allowed}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  checkInValidation.allowed
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    : 'bg-slate-100 text-slate-400 cursor-not-allowed border'
                }`}
              >
                {myTodayRecord ? 'Today Checked In' : 'Check In Now'}
              </button>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Check-In</th>
                    <th className="py-3 px-4">Check-Out</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Location</th>
                    <th className="py-3 px-4">Sync Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-800">
                  {myHistory.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/60">
                      <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                        {rec.date}
                      </td>
                      <td className="py-3 px-4 tabular-nums font-mono">{rec.checkInTime || '—'}</td>
                      <td className="py-3 px-4 tabular-nums font-mono">{rec.checkOutTime || '—'}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-md font-semibold text-[10px] ${
                            rec.status === 'present'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {rec.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-[10px] text-slate-500">
                        {rec.location
                          ? `${rec.location.latitude.toFixed(4)}, ${rec.location.longitude.toFixed(4)}`
                          : 'Campus Terminal'}
                      </td>
                      <td className="py-3 px-4 text-emerald-600 font-medium capitalize">
                        {rec.syncStatus}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* --- PAGE: STUDENT ATTENDANCE --- */}
        {currentPage === 'student-attendance' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">Digital Attendance Register</h1>
              <p className="text-xs text-slate-500 mt-0.5">Mark daily attendance for class.</p>
            </div>
            
            <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Select Class</label>
                  <select
                    value={selectedClassId || ''}
                    onChange={(e) => setSelectedClassId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs"
                  >
                    <option value="">Select a class...</option>
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name} ({c.section})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={todayStr}
                    disabled
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-xs"
                  />
                </div>
              </div>
              
              {selectedClassId && (
                <div className="mt-6">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-100">
                      <tr>
                        <th className="py-3 px-4">Roll</th>
                        <th className="py-3 px-4">Student Name</th>
                        <th className="py-3 px-4 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {students.filter(s => s.classId === selectedClassId).map(student => {
                        const record = studentAttendance.find(
                          r => r.studentId === student.id && r.date === todayStr
                        );
                        return (
                          <tr key={student.id} className="hover:bg-slate-50/60">
                            <td className="py-3 px-4 font-mono">{student.rollNo}</td>
                            <td className="py-3 px-4 font-semibold">{student.name}</td>
                            <td className="py-3 px-4 flex justify-center gap-2">
                              <button
                                onClick={() => {
                                  onUpdateStudentAttendance([...studentAttendance.filter(r => !(r.studentId === student.id && r.date === todayStr)), {
                                    id: `att-${Date.now()}-${student.id}`,
                                    studentId: student.id,
                                    studentName: student.name,
                                    classId: selectedClassId,
                                    className: student.className,
                                    schoolId: student.schoolId,
                                    date: todayStr,
                                    status: 'present',
                                    remarks: ''
                                  }]);
                                }}
                                className={`p-2 rounded-lg ${record?.status === 'present' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100'}`}
                              >
                                <Check className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  onUpdateStudentAttendance([...studentAttendance.filter(r => !(r.studentId === student.id && r.date === todayStr)), {
                                    id: `att-${Date.now()}-${student.id}`,
                                    studentId: student.id,
                                    studentName: student.name,
                                    classId: selectedClassId,
                                    className: student.className,
                                    schoolId: student.schoolId,
                                    date: todayStr,
                                    status: 'absent',
                                    remarks: ''
                                  }]);
                                }}
                                className={`p-2 rounded-lg ${record?.status === 'absent' ? 'bg-rose-100 text-rose-700' : 'bg-slate-100'}`}
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* --- PAGE: MESSAGING --- */}
        {currentPage === 'messaging' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">Messaging Center</h1>
              <p className="text-xs text-slate-500 mt-0.5">Communicate with parents securely.</p>
            </div>
            
            <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-2xs min-h-[400px]">
              <p className="text-xs text-slate-500 italic">Messaging interface placeholder. Select a parent to start a conversation.</p>
            </div>
          </div>
        )}

        {/* --- PAGE: CLASSES & ROUTINE --- */}
        {currentPage === 'classes' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">
                Assigned Classes & Student Rosters
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Review class sections, routine periods, and student rosters for your school.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {displayClasses.map((cls) => {
                const classStudents = students.filter(
                  (s) => s.classId === cls.id || s.className === cls.name
                );
                return (
                  <div
                    key={cls.id}
                    className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs flex flex-col justify-between hover:border-emerald-300 transition-colors"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-700 uppercase">
                          Room {cls.roomNo}
                        </span>
                        <span className="text-xs text-slate-400">
                          {classStudents.length} Students
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-slate-900 mt-1">
                        {cls.name} ({cls.section})
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Class Teacher: {cls.classTeacherName}
                      </p>

                      <div className="mt-4 pt-3 border-t border-slate-100 space-y-1 text-xs text-slate-600">
                        <span className="font-semibold text-slate-800 block mb-1">
                          Weekly Schedule:
                        </span>
                        {cls.schedule.slice(0, 3).map((item, idx) => (
                          <div key={idx} className="flex justify-between text-[11px]">
                            <span className="text-slate-500">{item.day} · {item.time}</span>
                            <span className="font-medium text-slate-800">{item.subject}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs text-slate-500 font-mono">ID: {cls.id}</span>
                      <button
                        type="button"
                        onClick={() => setSelectedClassId(cls.id)}
                        className="text-xs font-bold text-emerald-600 hover:text-emerald-700"
                      >
                        View Students →
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* --- PAGE: HOMEWORK ASSIGNMENTS --- */}
        {currentPage === 'homework' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-xl font-bold text-slate-900">
                  Homework Assignments Hub
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Assign tasks to your classes. Homework published here instantly updates the Parent Portal.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setEditingHw(null);
                  setIsAddHwOpen(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Assign Homework</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {myHomework.map((hw) => (
                <div
                  key={hw.id}
                  className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs flex flex-col justify-between hover:border-emerald-300 transition-colors"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                        {hw.subject} · {hw.className} ({hw.section})
                      </span>
                      <span className="text-xs font-semibold text-rose-600 font-mono">
                        Due: {hw.dueDate}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900">{hw.title}</h3>
                    <p className="text-xs text-slate-600 leading-relaxed">{hw.instructions}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-400 text-[11px]">
                      Assigned: {hw.assignedDate}
                    </span>
                    <button
                      type="button"
                      onClick={() => onDeleteHomework(hw.id)}
                      className="p-1 rounded text-slate-400 hover:text-rose-600 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- PAGE: NOTICES --- */}
        {currentPage === 'notices' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">
                Official Notices & Circulars
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Administrative notices broadcasted by the Upazila Directorate and school authority.
              </p>
            </div>

            <div className="space-y-4">
              {teacherNotices.map((n) => (
                <div
                  key={n.id}
                  className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-2 hover:border-purple-200 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 text-[10px] font-bold border border-purple-200">
                      {n.category}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">{n.publishedDate}</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900">{n.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- PAGE: FACULTY PROFILE --- */}
        {currentPage === 'profile' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
              <h1 className="text-xl font-bold text-slate-900">
                Faculty Profile & Credentials
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Official faculty registry details for {currentTeacher.name}
              </p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-2xs max-w-xl space-y-4">
              <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
                <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold text-xl">
                  {currentTeacher.name.charAt(0)}
                </div>
                <div>
                  <h2 className="text-base font-bold text-slate-900">{currentTeacher.name}</h2>
                  <p className="text-xs text-emerald-700 font-semibold">{currentTeacher.designation}</p>
                  <p className="text-[11px] text-slate-400">{currentTeacher.schoolName}</p>
                </div>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Teacher ID</label>
                  <input
                    type="text"
                    disabled
                    value={currentTeacher.id}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 font-mono text-slate-700"
                  />
                </div>

                <div>
                  <label className="block text-slate-500 font-semibold mb-1">Subject</label>
                  <input
                    type="text"
                    disabled
                    value={currentTeacher.subject}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-700"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Contact Phone</label>
                  <input
                    type="text"
                    value={profilePhone}
                    onChange={(e) => setProfilePhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Official Email</label>
                  <input
                    type="email"
                    value={profileEmail}
                    onChange={(e) => setProfileEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-slate-900"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onUpdateTeacher({
                      ...currentTeacher,
                      phone: profilePhone,
                      email: profileEmail,
                    });
                    setProfileSaved(true);
                    setTimeout(() => setProfileSaved(false), 3000);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer"
                >
                  Save Profile Changes
                </button>

                {profileSaved && (
                  <p className="text-xs text-emerald-600 font-semibold mt-2">
                    ✓ Profile updated successfully!
                  </p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Homework Creation Modal */}
      {isAddHwOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">
                Assign Homework Task
              </h3>
              <button
                type="button"
                onClick={() => setIsAddHwOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveHomework} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Homework Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chapter 4: Algebraic Fractions Exercises"
                  value={hwFormData.title}
                  onChange={(e) => setHwFormData({ ...hwFormData, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Class</label>
                  <select
                    value={hwFormData.classId}
                    onChange={(e) => setHwFormData({ ...hwFormData, classId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                  >
                    {classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.section})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Due Date</label>
                  <input
                    type="date"
                    required
                    value={hwFormData.dueDate}
                    onChange={(e) => setHwFormData({ ...hwFormData, dueDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Instructions</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Write clear instructions for students and parents..."
                  value={hwFormData.instructions}
                  onChange={(e) => setHwFormData({ ...hwFormData, instructions: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddHwOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  Publish Homework
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
