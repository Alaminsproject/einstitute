/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { GlobalTopNav } from './components/GlobalTopNav';
import { TechnicalSpecsModal } from './components/TechnicalSpecsModal';
import { PortalSelector } from './pages/PortalSelector';
import { AuthorityPortal } from './portals/authority/AuthorityPortal';
import { TeacherPortal } from './portals/teacher/TeacherPortal';
import { ParentPortal } from './portals/parent/ParentPortal';
import { StorageService } from './services/storageService';
import {
  AppSettings,
  ClassRoom,
  Homework,
  Language,
  LocationData,
  Notice,
  ParentGuardian,
  PortalRole,
  School,
  Student,
  StudentAttendanceRecord,
  Teacher,
  TeacherAttendanceRecord,
  LeaveApplication,
  DismissalNotice,
  Message,
} from './types';
import { CheckCircle2, Info, X } from 'lucide-react';

export default function App() {
  const [currentRole, setCurrentRole] = useState<PortalRole>('landing');
  const [specsModalOpen, setSpecsModalOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Entities loaded from StorageService
  const [schools, setSchools] = useState<School[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [parents, setParents] = useState<ParentGuardian[]>([]);
  const [classes, setClasses] = useState<ClassRoom[]>([]);
  const [homeworkList, setHomeworkList] = useState<Homework[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [teacherAttendance, setTeacherAttendance] = useState<TeacherAttendanceRecord[]>([]);
  const [studentAttendance, setStudentAttendance] = useState<StudentAttendanceRecord[]>([]);
  const [leaveApplications, setLeaveApplications] = useState<LeaveApplication[]>([]);
  const [dismissalNotices, setDismissalNotices] = useState<DismissalNotice[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [settings, setSettings] = useState<AppSettings>(StorageService.getSettings());

  // Global toast
  const [toast, setToast] = useState<{
    id: number;
    message: string;
    type: 'success' | 'info' | 'error';
  } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ id: Date.now(), message, type });
  };

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 4000);
    return () => clearTimeout(timer);
  }, [toast]);

  // Refresh state from storage
  const refreshState = useCallback(() => {
    setSchools(StorageService.getSchools());
    setTeachers(StorageService.getTeachers());
    setStudents(StorageService.getStudents());
    setParents(StorageService.getParents());
    setClasses(StorageService.getClasses());
    setHomeworkList(StorageService.getHomework());
    setNotices(StorageService.getNotices());
    setTeacherAttendance(StorageService.getTeacherAttendance());
    setStudentAttendance(StorageService.getStudentAttendance());
    setLeaveApplications(StorageService.getLeaveApplications());
    setDismissalNotices(StorageService.getDismissalNotices());
    setMessages(StorageService.getMessages());
    setSettings(StorageService.getSettings());
  }, []);

  useEffect(() => {
    refreshState();
  }, [refreshState]);

  // Current active teacher & parent
  const currentTeacher = useMemo(() => {
    return (
      teachers.find((t) => t.id === settings.currentTeacherId) ||
      teachers[0] || {
        id: 'TCH-1002',
        name: 'Syeda Nusrat Jahan',
        designation: 'Senior Teacher',
        schoolId: 'SCH-01',
        schoolName: 'Chatkhil Panchgaon Mahbub Government College',
        phone: '01815-440002',
        email: 'nusrat.jahan@institution.edu.bd',
        subject: 'Mathematics',
        joinDate: '2016-08-15',
        status: 'active' as const,
      }
    );
  }, [teachers, settings.currentTeacherId]);

  const currentParent = useMemo(() => {
    return (
      parents.find((p) => p.id === settings.currentParentId) ||
      parents[0] || {
        id: 'PRN-101',
        name: 'Mrs. Shamima Begum',
        relation: 'Mother' as const,
        phone: '01722-114455',
        email: 'shamima.b@example.com',
        occupation: 'Government Service',
        address: 'Chatkhil, Noakhali',
        studentIds: ['STD-901'],
      }
    );
  }, [parents, settings.currentParentId]);

  // --- Handlers ---
  const handleToggleOffline = () => {
    const newMode = StorageService.toggleOfflineMode();
    setSettings({ ...settings, isOfflineMode: newMode });
    showToast(
      newMode
        ? 'Offline Mode Active: New attendance records will queue locally.'
        : 'Online Mode Active: Direct recording mode.',
      'info'
    );
  };

  const handleSimulateSync = async () => {
    setIsSyncing(true);
    await new Promise((resolve) => setTimeout(resolve, 800));
    const res = await StorageService.simulateSync();
    setIsSyncing(false);
    refreshState();
    showToast(`Simulated Sync: ${res.syncedCount} queued record(s) marked synced.`);
  };

  const handleChangeLanguage = (lang: Language) => {
    StorageService.setLanguage(lang);
    setSettings({ ...settings, language: lang });
    showToast(lang === 'en' ? 'Language switched to English.' : 'ভাষা পরিবর্তন: বাংলা।', 'info');
  };

  const handleSelectTeacherId = (id: string) => {
    StorageService.setCurrentTeacherId(id);
    setSettings({ ...settings, currentTeacherId: id });
  };

  const handleSelectParentId = (id: string) => {
    StorageService.setCurrentParentId(id);
    setSettings({ ...settings, currentParentId: id });
  };

  // Teacher Attendance Check-In / Check-Out
  const handleRecordCheckIn = (
    teacher: Teacher,
    options?: { location?: LocationData; status?: any; remarks?: string }
  ) => {
    const rec = StorageService.recordCheckIn(teacher, options);
    refreshState();
    showToast(
      rec.syncStatus === 'pending'
        ? `Check-In queued offline for ${teacher.name}.`
        : `Check-In recorded for ${teacher.name} at ${rec.checkInTime}.`
    );
  };

  const handleRecordCheckOut = (teacherId: string) => {
    const rec = StorageService.recordCheckOut(teacherId);
    refreshState();
    if (rec) {
      showToast(`Check-Out recorded at ${rec.checkOutTime}.`);
    }
  };

  // Homework actions
  const handleAddHomework = (data: Omit<Homework, 'id' | 'createdAt'>) => {
    const item = StorageService.addHomework(data);
    refreshState();
    showToast(`Homework "${item.title}" assigned to ${item.className}. Parent view updated.`);
  };

  const handleUpdateHomework = (item: Homework) => {
    StorageService.updateHomework(item);
    refreshState();
    showToast(`Homework "${item.title}" updated.`);
  };

  const handleDeleteHomework = (id: string) => {
    StorageService.deleteHomework(id);
    refreshState();
    showToast('Homework deleted.', 'info');
  };

  const handleToggleHomeworkReviewed = (id: string) => {
    const reviewed = StorageService.toggleHomeworkReviewed(id);
    refreshState();
    showToast(reviewed ? 'Marked as reviewed at home.' : 'Review status cleared.');
  };

  const handleUpdateStudentAttendance = (records: StudentAttendanceRecord[]) => {
    StorageService.saveStudentAttendance(records);
    refreshState();
    showToast('Student attendance updated.');
  };

  // Notice actions
  const handleAddNotice = (noticeData: Omit<Notice, 'id' | 'createdAt'>) => {
    const notice = StorageService.addNotice(noticeData);
    refreshState();
    showToast(`Notice "${notice.title}" published. Visible in relevant portals.`);
  };

  const handleUpdateNotice = (notice: Notice) => {
    StorageService.updateNotice(notice);
    refreshState();
    showToast(`Notice "${notice.title}" updated.`);
  };

  const handleDeleteNotice = (id: string) => {
    StorageService.deleteNotice(id);
    refreshState();
    showToast('Notice removed.', 'info');
  };

  const handleSaveLeaveApplication = (application: LeaveApplication) => {
    StorageService.saveLeaveApplication(application);
    refreshState();
    showToast(`Leave application for ${application.studentName} updated to ${application.status}.`);
  };

  const handleSendDismissalNotice = (notice: DismissalNotice) => {
    StorageService.saveDismissalNotice(notice);
    refreshState();
    showToast('Dismissal notice sent to all parents.');
  };

  const handleSaveMessage = (message: Message) => {
    StorageService.saveMessage(message);
    refreshState();
    showToast('Message sent successfully.');
  };

  // Schools actions
  const handleAddSchool = (data: Omit<School, 'id'>) => {
    const created = StorageService.addSchool(data);
    refreshState();
    showToast(`Institution ${created.name} registered.`);
  };

  const handleUpdateSchool = (school: School) => {
    StorageService.updateSchool(school);
    refreshState();
    showToast(`School ${school.name} updated.`);
  };

  const handleDeleteSchool = (id: string) => {
    StorageService.deleteSchool(id);
    refreshState();
    showToast('School removed.', 'info');
  };

  // Teachers actions
  const handleAddTeacher = (data: Omit<Teacher, 'id'>) => {
    const created = StorageService.addTeacher(data);
    refreshState();
    showToast(`Teacher ${created.name} (${created.id}) registered.`);
  };

  const handleUpdateTeacher = (teacher: Teacher) => {
    StorageService.updateTeacher(teacher);
    refreshState();
    showToast(`Teacher ${teacher.name} updated.`);
  };

  const handleDeleteTeacher = (id: string) => {
    StorageService.deleteTeacher(id);
    refreshState();
    showToast('Teacher record deleted.', 'info');
  };

  // Reset & Backup
  const handleResetToDefault = () => {
    StorageService.resetToDefault();
    refreshState();
    showToast('Initial dataset restored across all three portals.', 'success');
  };

  const handleClearAll = () => {
    StorageService.clearAll();
    refreshState();
    showToast('Data tables cleared for empty state verification.', 'info');
  };

  const handleExportBackup = () => {
    const json = StorageService.exportBackupJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `e-institution-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    showToast('Complete platform backup exported.');
  };

  const handleImportBackup = (jsonStr: string) => {
    const ok = StorageService.importBackupJson(jsonStr);
    if (ok) {
      refreshState();
      showToast('Platform state imported successfully.');
    }
    return ok;
  };

  const pendingRecords = teacherAttendance.filter((r) => r.syncStatus === 'pending');

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      {/* Global Top Navigation for Active Portals */}
      {currentRole !== 'landing' && (
        <GlobalTopNav
          currentRole={currentRole}
          onSelectRole={setCurrentRole}
          settings={settings}
          onToggleOffline={handleToggleOffline}
          pendingRecords={pendingRecords}
          onSimulateSync={handleSimulateSync}
          isSyncing={isSyncing}
          onOpenSpecsModal={() => setSpecsModalOpen(true)}
          onChangeLanguage={handleChangeLanguage}
        />
      )}

      {/* Main Container */}
      <main className="flex-1 bg-white">
        {currentRole === 'landing' && (
          <PortalSelector
            onSelectRole={setCurrentRole}
            teachers={teachers}
            parents={parents}
            currentTeacherId={settings.currentTeacherId}
            onSelectTeacherId={handleSelectTeacherId}
            currentParentId={settings.currentParentId}
            onSelectParentId={handleSelectParentId}
            schools={schools}
            language={settings.language}
            onChangeLanguage={handleChangeLanguage}
          />
        )}

        {currentRole === 'authority' && (
          <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
            <AuthorityPortal
              schools={schools}
              teachers={teachers}
              students={students}
              attendanceRecords={teacherAttendance}
              notices={notices}
              settings={settings}
              onAddSchool={handleAddSchool}
              onUpdateSchool={handleUpdateSchool}
              onDeleteSchool={handleDeleteSchool}
              onAddTeacher={handleAddTeacher}
              onUpdateTeacher={handleUpdateTeacher}
              onDeleteTeacher={handleDeleteTeacher}
              onAddNotice={handleAddNotice}
              onUpdateNotice={handleUpdateNotice}
              onDeleteNotice={handleDeleteNotice}
              onResetToDefault={handleResetToDefault}
              onClearAll={handleClearAll}
              onExportBackup={handleExportBackup}
              onImportBackup={handleImportBackup}
            />
          </div>
        )}

        {currentRole === 'teacher' && (
          <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
            <TeacherPortal
              currentTeacher={currentTeacher}
              allTeachers={teachers}
              onSelectTeacherId={handleSelectTeacherId}
              schools={schools}
              classes={classes}
              students={students}
              homeworkList={homeworkList}
              onAddHomework={handleAddHomework}
              onUpdateHomework={handleUpdateHomework}
              onDeleteHomework={handleDeleteHomework}
              notices={notices}
              attendanceRecords={teacherAttendance}
              studentAttendance={studentAttendance}
              leaveApplications={leaveApplications}
              dismissalNotices={dismissalNotices}
              messages={messages}
              onRecordCheckIn={handleRecordCheckIn}
              onRecordCheckOut={handleRecordCheckOut}
              onUpdateTeacher={handleUpdateTeacher}
              onUpdateStudentAttendance={handleUpdateStudentAttendance}
              onSaveLeaveApplication={handleSaveLeaveApplication}
              onSendDismissalNotice={handleSendDismissalNotice}
              onSaveMessage={handleSaveMessage}
              isOfflineMode={settings.isOfflineMode}
            />
          </div>
        )}

        {currentRole === 'parent' && (
          <div className="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8">
            <ParentPortal
              currentParent={currentParent}
              allParents={parents}
              onSelectParentId={handleSelectParentId}
              students={students}
              schools={schools}
              teachers={teachers}
              homeworkList={homeworkList}
              onToggleHomeworkReviewed={handleToggleHomeworkReviewed}
              notices={notices}
              studentAttendance={studentAttendance}
              leaveApplications={leaveApplications}
              dismissalNotices={dismissalNotices}
              messages={messages}
              onSaveMessage={handleSaveMessage}
            />
          </div>
        )}
      </main>

      {/* Technical Specifications & Architecture Modal */}
      <TechnicalSpecsModal
        isOpen={specsModalOpen}
        onClose={() => setSpecsModalOpen(false)}
      />

      {/* Global Floating Toast */}
      {toast && (
        <aside
          aria-label="Platform alerts"
          className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs font-semibold bg-slate-900 text-white border border-slate-700 animate-slide-up"
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-teal-400 flex-shrink-0" />
          ) : (
            <Info className="w-4 h-4 text-blue-400 flex-shrink-0" />
          )}
          <span>{toast.message}</span>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="p-1 rounded-md text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </aside>
      )}
    </div>
  );
}
