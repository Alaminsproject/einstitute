import React from 'react';
import {
  LayoutDashboard,
  Fingerprint,
  Users,
  School as SchoolIcon,
  FileSpreadsheet,
  Building2,
  Sliders,
  Database,
  RotateCcw,
} from 'lucide-react';
import { NavigationPage } from '../types';

interface SidebarProps {
  currentPage: NavigationPage;
  onNavigate: (page: NavigationPage) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onResetDemo: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  mobileOpen,
  onCloseMobile,
  onResetDemo,
}) => {
  const navItems: {
    id: NavigationPage;
    label: string;
    labelBn: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string;
  }[] = [
    {
      id: 'dashboard',
      label: 'Overview Dashboard',
      labelBn: 'সার্বিক ড্যাশবোর্ড',
      icon: LayoutDashboard,
    },
    {
      id: 'attendance',
      label: 'Teacher Attendance',
      labelBn: 'শিক্ষক হাজিরা',
      icon: Fingerprint,
    },
    {
      id: 'teachers',
      label: 'Teachers',
      labelBn: 'শিক্ষক ব্যবস্থাপনা',
      icon: Users,
    },
    {
      id: 'schools',
      label: 'School Information',
      labelBn: 'প্রতিষ্ঠান তথ্য',
      icon: SchoolIcon,
    },
    {
      id: 'reports',
      label: 'Attendance Reports',
      labelBn: 'হাজিরা রিপোর্ট',
      icon: FileSpreadsheet,
    },
    {
      id: 'upazila',
      label: 'Upazila Monitoring',
      labelBn: 'উপজেলা মনিটরিং',
      icon: Building2,
      badge: 'Admin',
    },
    {
      id: 'settings',
      label: 'Settings & Demo Controls',
      labelBn: 'সেটিংস ও কন্ট্রোল',
      icon: Sliders,
    },
  ];

  const handleSelect = (page: NavigationPage) => {
    onNavigate(page);
    onCloseMobile();
  };

  const navContent = (
    <div className="flex flex-col h-full bg-slate-900 border-r border-slate-800 text-slate-300 w-64">
      {/* Navigation Links */}
      <div className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <p className="px-3 text-[11px] font-semibold tracking-wider text-slate-400 uppercase mb-2">
          Main Navigation
        </p>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => handleSelect(item.id)}
              aria-current={isActive ? 'page' : undefined}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all text-left ${
                isActive
                  ? 'bg-teal-600/20 text-teal-300 border border-teal-500/40 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-5 h-5 flex-shrink-0 ${
                    isActive ? 'text-teal-400' : 'text-slate-400'
                  }`}
                />
                <div>
                  <span className="block leading-tight font-medium text-[13px]">{item.label}</span>
                  <span className="block text-[11px] text-slate-400 font-normal leading-tight">
                    {item.labelBn}
                  </span>
                </div>
              </div>

              {item.badge && (
                <span className="px-1.5 py-0.5 text-[10px] font-semibold rounded bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Sidebar Footer info */}
      <div className="p-3 m-3 rounded-xl bg-slate-800/60 border border-slate-700/50 text-xs">
        <div className="flex items-center gap-2 text-slate-300 mb-1 font-medium">
          <Database className="w-3.5 h-3.5 text-teal-400" />
          <span>Local Demo Storage</span>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed mb-2.5">
          Records are stored in this browser's localStorage for demonstration purposes.
        </p>
        <button
          type="button"
          onClick={onResetDemo}
          className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-[11px] font-medium bg-slate-700/70 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-600/50"
        >
          <RotateCcw className="w-3 h-3 text-slate-400" />
          <span>Reset Sample Data</span>
        </button>
      </div>

      <div className="px-4 py-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
        <span>e-Institution v1.0</span>
        <span className="text-teal-400 font-mono">Frontend Demo</span>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden md:block flex-shrink-0">
        {navContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-50 flex flex-col max-w-xs w-full">
            {navContent}
          </div>
        </div>
      )}
    </>
  );
};
