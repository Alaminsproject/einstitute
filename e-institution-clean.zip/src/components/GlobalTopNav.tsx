import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Wifi,
  WifiOff,
  RefreshCw,
  Clock,
  Layers,
  ChevronDown,
  Globe,
  Building2,
  UserCheck,
  HeartHandshake,
  ArrowLeft,
  FileCode,
} from 'lucide-react';
import { AppSettings, Language, PortalRole, TeacherAttendanceRecord } from '../types';
import { formatTime12h } from '../services/storageService';

interface GlobalTopNavProps {
  currentRole: PortalRole;
  onSelectRole: (role: PortalRole) => void;
  settings: AppSettings;
  onToggleOffline: () => void;
  pendingRecords: TeacherAttendanceRecord[];
  onSimulateSync: () => void;
  isSyncing: boolean;
  onOpenSpecsModal: () => void;
  onChangeLanguage: (lang: Language) => void;
}

export const GlobalTopNav: React.FC<GlobalTopNavProps> = ({
  currentRole,
  onSelectRole,
  settings,
  onToggleOffline,
  pendingRecords,
  onSimulateSync,
  isSyncing,
  onOpenSpecsModal,
  onChangeLanguage,
}) => {
  const [time, setTime] = useState<string>(formatTime12h());
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
  const pendingCount = pendingRecords.length;
  const isBn = settings.language === 'bn';

  useEffect(() => {
    const timer = setInterval(() => setTime(formatTime12h()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getPortalInfo = () => {
    switch (currentRole) {
      case 'authority':
        return {
          title: isBn ? 'উচ্চতর কর্তৃপক্ষ' : 'Higher Authority',
          icon: Building2,
          badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
          activeDot: 'bg-blue-600',
        };
      case 'teacher':
        return {
          title: isBn ? 'শিক্ষক কর্নার' : 'Teacher Portal',
          icon: UserCheck,
          badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          activeDot: 'bg-emerald-600',
        };
      case 'parent':
        return {
          title: isBn ? 'অভিভাবক কর্নার' : 'Parent Portal',
          icon: HeartHandshake,
          badgeColor: 'bg-orange-50 text-orange-700 border-orange-200',
          activeDot: 'bg-orange-500',
        };
      default:
        return {
          title: isBn ? 'পোর্টাল নির্বাচন' : 'Portal Selection',
          icon: Layers,
          badgeColor: 'bg-slate-100 text-slate-700 border-slate-200',
          activeDot: 'bg-blue-600',
        };
    }
  };

  const portalInfo = getPortalInfo();
  const Icon = portalInfo.icon;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/90 text-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: Brand & Portal Indicator */}
        <div className="flex items-center gap-3">
          {currentRole !== 'landing' && (
            <button
              type="button"
              onClick={() => onSelectRole('landing')}
              title={isBn ? 'মূল পাতায় ফিরে যান' : 'Back to Home / Portal Selection'}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}

          <div
            onClick={() => onSelectRole('landing')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm group-hover:bg-blue-700 transition-colors">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-slate-900 font-sans">
                  e-Institution
                </span>
                <span className="text-[10px] font-semibold tracking-wide uppercase px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200/60 hidden sm:inline-block">
                  {isBn ? 'শিক্ষা ব্যবস্থাপনা' : 'Education Platform'}
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium hidden md:block">
                {isBn
                  ? 'চাটখিল উপজেলা, নোয়াখালী'
                  : 'Chatkhil Upazila, Noakhali'}
              </p>
            </div>
          </div>

          {/* Active Portal Switcher Pill */}
          {currentRole !== 'landing' && (
            <div className="relative ml-2">
              <button
                type="button"
                onClick={() => setRoleDropdownOpen(!roleDropdownOpen)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${portalInfo.badgeColor}`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="whitespace-nowrap">{portalInfo.title}</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </button>

              {roleDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setRoleDropdownOpen(false)}
                  />
                  <div className="absolute left-0 mt-1.5 w-60 rounded-xl bg-white border border-slate-200 shadow-xl z-50 py-1.5 text-xs">
                    <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                      {isBn ? 'সক্রিয় পোর্টাল পরিবর্তন করুন' : 'Switch Portal'}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectRole('authority');
                        setRoleDropdownOpen(false);
                      }}
                      className="w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-slate-50 text-slate-800 transition-colors cursor-pointer"
                    >
                      <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                        <Building2 className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">
                          {isBn ? 'উচ্চতর কর্তৃপক্ষ' : 'Higher Authority'}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {isBn ? 'প্রশাসন ও পরিদর্শন' : 'Administration & Oversight'}
                        </div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onSelectRole('teacher');
                        setRoleDropdownOpen(false);
                      }}
                      className="w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-slate-50 text-slate-800 transition-colors cursor-pointer"
                    >
                      <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                        <UserCheck className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">
                          {isBn ? 'শিক্ষক কর্নার' : 'Teacher Portal'}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {isBn ? 'উপস্থিতি ও পাঠদান' : 'Attendance & Classes'}
                        </div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onSelectRole('parent');
                        setRoleDropdownOpen(false);
                      }}
                      className="w-full px-3 py-2 text-left flex items-center gap-2.5 hover:bg-slate-50 text-slate-800 transition-colors cursor-pointer"
                    >
                      <div className="w-7 h-7 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center">
                        <HeartHandshake className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-900">
                          {isBn ? 'অভিভাবক কর্নার' : 'Parent Portal'}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {isBn ? 'সন্তানের অগ্রগতি' : 'Child Progress & Homework'}
                        </div>
                      </div>
                    </button>

                    <div className="border-t border-slate-100 mt-1 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          onSelectRole('landing');
                          setRoleDropdownOpen(false);
                        }}
                        className="w-full px-3 py-2 text-left flex items-center gap-2 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors cursor-pointer"
                      >
                        <Layers className="w-3.5 h-3.5 text-slate-400" />
                        <span>{isBn ? 'সকল পোর্টালের তালিকা' : 'All Portals Overview'}</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Right Controls: Connectivity, Pending Sync, Language & Specs */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Live Bangladesh Standard Time Clock */}
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-200/80 font-mono tabular-nums">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            <span className="font-semibold text-slate-800">{time}</span>
            <span className="text-[10px] text-slate-500 font-sans">BST</span>
          </div>

          {/* Network Simulation Toggle */}
          <button
            type="button"
            onClick={onToggleOffline}
            title={settings.isOfflineMode ? 'Switch to Online Mode' : 'Simulate Offline Mode'}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all border cursor-pointer ${
              settings.isOfflineMode
                ? 'bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100'
                : 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100'
            }`}
          >
            {settings.isOfflineMode ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-600" />
                <span className="hidden sm:inline">
                  {isBn ? 'অফলাইন মোড' : 'Offline Mode'}
                </span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">{isBn ? 'অনলাইন' : 'Online'}</span>
              </>
            )}
          </button>

          {/* Pending Sync Trigger */}
          {pendingCount > 0 && (
            <button
              type="button"
              onClick={onSimulateSync}
              disabled={isSyncing}
              title="Simulate data sync for locally queued attendance records"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors shadow-xs cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? (isBn ? 'সিঙ্ক হচ্ছে...' : 'Syncing...') : `${isBn ? 'সিঙ্ক' : 'Sync'} (${pendingCount})`}</span>
            </button>
          )}

          {/* Language Toggle: Natural English / Bengali Switcher */}
          <button
            type="button"
            onClick={() => onChangeLanguage(settings.language === 'en' ? 'bn' : 'en')}
            title="Toggle Language (English / বাংলা)"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 shadow-2xs transition-colors cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span>{settings.language === 'en' ? 'বাংলা' : 'English'}</span>
          </button>

          {/* Technical Specs Modal Trigger */}
          <button
            type="button"
            onClick={onOpenSpecsModal}
            title={isBn ? 'প্রযুক্তিগত বিবরণ ও আর্কিটেকচার' : 'System Architecture & Technical Specs'}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
          >
            <FileCode className="w-4 h-4 text-slate-600" />
          </button>
        </div>
      </div>
    </header>
  );
};
