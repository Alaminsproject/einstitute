import React from 'react';
import { X, Layers, Database, Shield, Server, FileText, CheckCircle2, ArrowRight } from 'lucide-react';

interface TechnicalSpecsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TechnicalSpecsModal: React.FC<TechnicalSpecsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="specs-title"
        className="relative z-10 w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-white border-b border-slate-200 text-slate-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 id="specs-title" className="text-base font-bold text-slate-900">
                e-Institution Technical Architecture & Roadmap
              </h2>
              <p className="text-xs text-slate-500">
                Data layer specifications, storage sandbox, and production integration pathways
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close specifications modal"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-600 leading-relaxed">
          {/* Section 1 */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
              <Database className="w-4 h-4 text-blue-600" />
              <span>1. Single-Store Reactive Client Architecture</span>
            </div>
            <p>
              e-Institution connects three distinct user portals (<b>Higher Authority</b>, <b>Teacher</b>, and <b>Parent</b>) to a centralized frontend service repository (<code>storageService.ts</code>). All portals read from and write to the same shared entity models:
            </p>
            <ul className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[11px] text-slate-700">
              <li className="p-2 rounded bg-white border border-slate-200">Schools (6)</li>
              <li className="p-2 rounded bg-white border border-slate-200">Teachers (10+)</li>
              <li className="p-2 rounded bg-white border border-slate-200">Students (6+)</li>
              <li className="p-2 rounded bg-white border border-slate-200">ClassRooms (3)</li>
              <li className="p-2 rounded bg-white border border-slate-200">Homework</li>
              <li className="p-2 rounded bg-white border border-slate-200">Notices</li>
              <li className="p-2 rounded bg-white border border-slate-200">Attendance</li>
              <li className="p-2 rounded bg-white border border-slate-200">Parents (4)</li>
            </ul>
          </div>

          {/* Section 2 */}
          <div className="p-4 rounded-xl bg-teal-50/60 border border-teal-200 space-y-2 text-teal-950">
            <div className="flex items-center gap-2 font-bold text-teal-900 text-sm">
              <Shield className="w-4 h-4 text-teal-700" />
              <span>2. Multi-Portal Cross-Sync Verification</span>
            </div>
            <p>
              Actions taken in one portal immediately reflect across all corresponding interfaces in the active browser:
            </p>
            <div className="space-y-1.5 pt-1 text-[11px]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 flex-shrink-0" />
                <span><b>Teacher Attendance:</b> When recorded in the Teacher Portal, the Authority Dashboard recalculates stats, rates, and summaries instantly.</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 flex-shrink-0" />
                <span><b>Notices:</b> Published by Authority, instantly accessible in Teacher and Parent notice feeds.</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 flex-shrink-0" />
                <span><b>Homework:</b> Created by teachers for Class 9-A, immediately visible in the Parent Portal for enrolled students.</span>
              </div>
            </div>
          </div>

          {/* Section 3 */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
              <Server className="w-4 h-4 text-blue-600" />
              <span>3. Roadmap for Backend Integration (Phase 2)</span>
            </div>
            <p>
              Because <code>storageService.ts</code> is fully decoupled from the UI layer, transitioning to cloud persistence requires zero changes to React components:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <span className="font-bold text-slate-800 block mb-0.5">Authentication</span>
                Swap sample profile selection with Firebase Auth or Government SSO (e-Services ID).
              </div>
              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <span className="font-bold text-slate-800 block mb-0.5">Cloud Database</span>
                Replace <code>localStorage</code> calls with Firestore or PostgreSQL / Cloud SQL queries.
              </div>
              <div className="p-2.5 rounded-lg bg-white border border-slate-200">
                <span className="font-bold text-slate-800 block mb-0.5">Multi-Device Sync</span>
                Real-time WebSocket or Firestore listeners to propagate updates across school staff and parents simultaneously.
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <span className="text-slate-400">e-Institution Architecture Specification v2.0</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 transition-colors"
          >
            Close Documentation
          </button>
        </div>
      </div>
    </div>
  );
};
