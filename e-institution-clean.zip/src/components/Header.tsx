import React, { useEffect, useState } from 'react';
import {
  Wifi,
  WifiOff,
  RefreshCw,
  Clock,
  GraduationCap,
  Menu,
  X,
  AlertTriangle,
} from 'lucide-react';
import { AppSettings, AttendanceRecord } from '../types';
import { formatTime12h, getTodayDateString } from '../services/storageService';

interface HeaderProps {
  settings: AppSettings;
  onToggleOffline: () => void;
  pendingRecords: AttendanceRecord[];
  onOpenPendingModal: () => void;
  onSimulateSync: () => void;
  isSyncing: boolean;
  mobileMenuOpen: boolean;
  onToggleMobileMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onToggleOffline,
  pendingRecords,
  onOpenPendingModal,
  onSimulateSync,
  isSyncing,
  mobileMenuOpen,
  onToggleMobileMenu,
}) => {
  const [currentTime, setCurrentTime] = useState<string>(formatTime12h());
  const todayStr = getTodayDateString();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(formatTime12h());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const pendingCount = pendingRecords.length;

  return (
    <header className="sticky top-0 z-30 bg-slate-900 border-b border-slate-800 text-white shadow-md">
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-teal-950 border-b border-teal-800/40 px-4 py-1.5 text-xs text-slate-300 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            <AlertTriangle className="w-3 h-3 text-amber-400" />
            Frontend Demo
          </span>
          <span className="hidden sm:inline text-slate-300">
            Data is stored locally on this device in browser localStorage. No central server or official portal connected.
          </span>
          <span className="sm:hidden text-slate-300">
            Local browser demo data only.
          </span>
        </div>
        <div className="flex items-center gap-3 text-slate-400 text-[11px]">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-teal-400" />
            <span className="font-mono text-slate-200">{currentTime}</span> (BST)
          </span>
          <span className="hidden md:inline font-mono text-slate-400">Date: {todayStr}</span>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onToggleMobileMenu}
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="md:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <div className="flex items-center gap-2.5 cursor-pointer">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-blue-600 flex items-center justify-center shadow-lg shadow-teal-500/20 ring-1 ring-white/20">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-white font-sans">
                  e-Institution
                </span>
                <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  Demo
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block">
                School Management & Digital Attendance System
              </p>
            </div>
          </div>
        </div>

        {/* Right: Controls & Offline Simulation */}
        <div className="flex items-center gap-2.5 sm:gap-4">
          {/* Online/Offline Demo Mode Pill */}
          <button
            type="button"
            onClick={onToggleOffline}
            aria-label={`Switch demo mode. Currently ${settings.isOfflineMode ? 'Demo Offline' : 'Demo Online'}`}
            title="Click to toggle simulated online/offline mode"
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all shadow-sm border ${
              settings.isOfflineMode
                ? 'bg-amber-950/70 border-amber-500/50 text-amber-200 hover:bg-amber-900/80'
                : 'bg-emerald-950/70 border-emerald-500/50 text-emerald-200 hover:bg-emerald-900/80'
            }`}
          >
            {settings.isOfflineMode ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                </span>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Simulated Offline</span>
                <span className="sm:hidden">Offline</span>
              </>
            ) : (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400"></span>
                </span>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Simulated Online</span>
                <span className="sm:hidden">Online</span>
              </>
            )}
          </button>

          {/* Pending Queue Button */}
          {pendingCount > 0 && (
            <button
              type="button"
              onClick={onOpenPendingModal}
              aria-label={`View ${pendingCount} pending local records in offline queue`}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-colors animate-pulse"
            >
              <span>{pendingCount} Pending</span>
            </button>
          )}

          {/* Simulated Sync Action */}
          <button
            type="button"
            onClick={onSimulateSync}
            disabled={isSyncing || pendingCount === 0}
            title={pendingCount > 0 ? "Simulate sync for pending local records" : "No pending records to sync"}
            aria-label="Simulate sync of local records"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all shadow-sm ${
              pendingCount > 0
                ? 'bg-teal-600 hover:bg-teal-500 text-white cursor-pointer active:scale-95'
                : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed opacity-60'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-teal-300' : ''}`} />
            <span className="hidden sm:inline">
              {isSyncing ? 'Syncing...' : 'Simulate Sync'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
