import React from 'react';
import { X, RefreshCw, WifiOff, CheckCircle2, Clock, MapPin, AlertCircle } from 'lucide-react';
import { AttendanceRecord } from '../types';

interface PendingSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  pendingRecords: AttendanceRecord[];
  onSimulateSync: () => void;
  isSyncing: boolean;
}

export const PendingSyncModal: React.FC<PendingSyncModalProps> = ({
  isOpen,
  onClose,
  pendingRecords,
  onSimulateSync,
  isSyncing,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Dialog */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="pending-sync-title"
        className="relative z-10 w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <WifiOff className="w-5 h-5" />
            </div>
            <div>
              <h2 id="pending-sync-title" className="text-lg font-bold">
                Offline Pending Queue (অপেক্ষমান তালিকা)
              </h2>
              <p className="text-xs text-slate-400">
                {pendingRecords.length} record{pendingRecords.length === 1 ? '' : 's'} queued in browser localStorage
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close pending sync queue"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Informational Callout */}
        <div className="px-6 py-3.5 bg-amber-50 border-b border-amber-200/80 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900 leading-relaxed">
            <span className="font-semibold block mb-0.5">Simulated Sync — No Server Connected</span>
            This simulation showcases how teachers in areas with intermittent internet connectivity can safely record attendance offline. Records remain saved in your browser and will update to "synced" status upon simulation.
          </div>
        </div>

        {/* Records Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {pendingRecords.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3 opacity-90" />
              <p className="text-sm font-semibold text-slate-700">No Pending Records</p>
              <p className="text-xs text-slate-500 mt-1">
                All local attendance records are currently marked as synchronized.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingRecords.map((record) => (
                <div
                  key={record.id}
                  className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900 text-sm">
                        {record.teacherName}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded-md font-mono bg-slate-200 text-slate-700 font-medium">
                        {record.teacherId}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {record.schoolName}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-xs">
                    <span className="inline-flex items-center gap-1 text-slate-600">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {record.checkInTime}
                    </span>

                    {record.location && (
                      <span className="inline-flex items-center gap-1 text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                        <MapPin className="w-3 h-3 text-teal-600" />
                        GPS Logged
                      </span>
                    )}

                    <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-300">
                      Pending Sync
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-500">
            Storage Key: <code className="bg-slate-200 px-1 py-0.5 rounded text-[11px]">einst_attendance_v1</code>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200/80 rounded-xl transition-colors"
            >
              Close
            </button>
            <button
              type="button"
              onClick={onSimulateSync}
              disabled={isSyncing || pendingRecords.length === 0}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-white shadow-sm transition-all ${
                pendingRecords.length > 0 && !isSyncing
                  ? 'bg-teal-600 hover:bg-teal-700 active:scale-95'
                  : 'bg-slate-400 cursor-not-allowed'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Simulating Sync...' : 'Simulate Sync Now'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
