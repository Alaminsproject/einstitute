import React, { useState, useEffect } from 'react';
import { Quote, Sparkles } from 'lucide-react';
import { Language } from '../types';

interface EducationalQuotesProps {
  language: Language;
}

const QUOTES = {
  en: [
    "Every step in learning brings us closer to a brighter future.",
    "Teachers guide the journey; students build the future.",
    "Small, consistent efforts create meaningful progress.",
    "A better learning experience starts with better communication."
  ],
  bn: [
    "শেখার প্রতিটি পদক্ষেপই সুন্দর ভবিষ্যতের দিকে এক ধাপ।",
    "শিক্ষক পথ দেখান, শিক্ষার্থী সেই পথে এগিয়ে যায়।",
    "নিয়মিত চেষ্টা ছোট অগ্রগতিকে বড় সাফল্যে পরিণত করে।",
    "একটি ভালো শিক্ষা, একটি সম্ভাবনাময় ভবিষ্যৎ।"
  ]
};

export const EducationalQuotes: React.FC<EducationalQuotesProps> = ({ language }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const currentList = QUOTES[language] || QUOTES.en;

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % currentList.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [currentList.length]);

  return (
    <div className="bg-gradient-to-r from-blue-50 via-teal-50 to-orange-50 border border-slate-200/80 rounded-2xl p-4 sm:p-5 shadow-2xs flex items-center gap-3.5 my-4">
      <div className="w-10 h-10 rounded-xl bg-white text-blue-600 flex items-center justify-center shrink-0 shadow-xs border border-slate-100">
        <Sparkles className="w-5 h-5 text-amber-500 animate-pulse" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">
          <Quote className="w-3 h-3 text-slate-400" />
          <span>{language === 'bn' ? 'আজকের অনুপ্রেরণা' : 'Daily Inspiration'}</span>
        </div>
        <p className="text-xs sm:text-sm font-semibold text-slate-800 italic transition-all duration-500">
          "{currentList[currentIndex]}"
        </p>
      </div>
    </div>
  );
};
