import React, { useState } from 'react';
import { MapPin, AlertCircle, CheckCircle2, Loader2, Info } from 'lucide-react';
import { LocationData } from '../types';

interface GeolocationWidgetProps {
  onLocationCaptured: (location: LocationData | undefined) => void;
  currentLocation?: LocationData;
}

export const GeolocationWidget: React.FC<GeolocationWidgetProps> = ({
  onLocationCaptured,
  currentLocation,
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleRequestLocation = () => {
    if (!navigator.geolocation) {
      setErrorMessage('Geolocation is not supported by your browser or device.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLoading(false);
        const data: LocationData = {
          latitude: Number(pos.coords.latitude.toFixed(6)),
          longitude: Number(pos.coords.longitude.toFixed(6)),
          accuracy: Math.round(pos.coords.accuracy),
          capturedAt: new Date().toISOString(),
          permissionGranted: true,
        };
        onLocationCaptured(data);
      },
      (err) => {
        setLoading(false);
        let msg = 'Could not capture location.';
        switch (err.code) {
          case err.PERMISSION_DENIED:
            msg = 'Location permission was denied in your browser settings.';
            break;
          case err.POSITION_UNAVAILABLE:
            msg = 'Location coordinates are currently unavailable.';
            break;
          case err.TIMEOUT:
            msg = 'Location request timed out. Please try again.';
            break;
        }
        setErrorMessage(msg);
        onLocationCaptured(undefined);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000,
      }
    );
  };

  const handleClearLocation = () => {
    setErrorMessage(null);
    onLocationCaptured(undefined);
  };

  return (
    <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/80 text-xs text-slate-700">
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5 font-semibold text-slate-800">
          <MapPin className="w-4 h-4 text-teal-600" />
          <span>Device Geolocation (ঐচ্ছিক জিপিএস অবস্থান)</span>
        </div>
        <span className="text-[10px] uppercase font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
          Client GPS
        </span>
      </div>

      <p className="text-[11px] text-slate-500 leading-relaxed mb-3">
        Click below to capture device browser coordinates. Coordinates remain stored locally on device.
      </p>

      {/* Button to request */}
      {!currentLocation ? (
        <div className="flex flex-col sm:flex-row sm:items-center gap-2">
          <button
            type="button"
            onClick={handleRequestLocation}
            disabled={loading}
            className="inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-white border border-slate-300 hover:border-teal-500 hover:text-teal-700 font-medium text-xs transition-colors shadow-xs active:bg-slate-100"
          >
            {loading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-teal-600" />
                <span>Requesting Browser Location...</span>
              </>
            ) : (
              <>
                <MapPin className="w-3.5 h-3.5 text-teal-600" />
                <span>Capture Browser Coordinates</span>
              </>
            )}
          </button>
        </div>
      ) : (
        <div className="p-2.5 rounded-lg bg-teal-50 border border-teal-200 text-teal-900 space-y-1">
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1 font-semibold text-teal-800 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
              Coordinates Captured Successfully
            </span>
            <button
              type="button"
              onClick={handleClearLocation}
              className="text-[10px] text-slate-500 hover:text-red-600 underline font-medium"
            >
              Clear
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] font-mono mt-1">
            <div>
              <span className="text-slate-500 font-sans block text-[10px]">Latitude</span>
              <span className="font-semibold">{currentLocation.latitude}° N</span>
            </div>
            <div>
              <span className="text-slate-500 font-sans block text-[10px]">Longitude</span>
              <span className="font-semibold">{currentLocation.longitude}° E</span>
            </div>
          </div>
          <div className="text-[10px] text-teal-700 pt-0.5">
            Reported Accuracy: ±{currentLocation.accuracy} meters
          </div>
        </div>
      )}

      {errorMessage && (
        <div className="mt-2.5 p-2 rounded-lg bg-red-50 border border-red-200 text-red-700 text-[11px] flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-500" />
          <span>{errorMessage}</span>
        </div>
      )}

      <div className="mt-2 pt-2 border-t border-slate-200 flex items-center gap-1.5 text-[10px] text-slate-400">
        <Info className="w-3 h-3 flex-shrink-0" />
        <span>Demonstration only. Does not represent official geofence validation.</span>
      </div>
    </div>
  );
};
