import React, { useState, useMemo } from 'react';
import {
  Building2,
  Calendar,
  Users,
  CheckCircle2,
  XCircle,
  TrendingUp,
  WifiOff,
  AlertTriangle,
  ChevronRight,
  School as SchoolIcon,
  X,
  Phone,
  Clock,
  MapPin,
  ExternalLink,
} from 'lucide-react';
import { AttendanceRecord, School, Teacher } from '../types';
import {
  calculateAttendanceStats,
  calculateSchoolSummaries,
  SchoolAttendanceSummary,
} from '../utils/attendanceLogic';
import { getTodayDateString } from '../services/storageService';

interface UpazilaMonitoringPageProps {
  schools: School[];
  teachers: Teacher[];
  attendanceRecords: AttendanceRecord[];
}

export const UpazilaMonitoringPage: React.FC<UpazilaMonitoringPageProps> = ({
  schools,
  teachers,
  attendanceRecords,
}) => {
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());
  const [drillDownSchoolId, setDrillDownSchoolId] = useState<string | null>(null);

  // Overall upazila stats
  const upazilaStats = calculateAttendanceStats(teachers, attendanceRecords, selectedDate);
  const schoolSummaries = calculateSchoolSummaries(
    schools,
    teachers,
    attendanceRecords,
    selectedDate
  );

  // Drill down details
  const drillDownSchool = useMemo(() => {
    if (!drillDownSchoolId) return null;
    return schools.find((s) => s.id === drillDownSchoolId) || null;
  }, [schools, drillDownSchoolId]);

  const drillDownTeachers = useMemo(() => {
    if (!drillDownSchoolId) return [];
    return teachers.filter((t) => t.schoolId === drillDownSchoolId && t.status === 'active');
  }, [teachers, drillDownSchoolId]);

  const drillDownRecordsMap = useMemo(() => {
    const map = new Map<string, AttendanceRecord>();
    if (!drillDownSchoolId) return map;
    attendanceRecords
      .filter((r) => r.schoolId === drillDownSchoolId && r.date === selectedDate)
      .forEach((r) => map.set(r.teacherId, r));
    return map;
  }, [attendanceRecords, drillDownSchoolId, selectedDate]);

  return (
    <div className="space-y-6">
      {/* Persistent Disclaimer Banner */}
      <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div className="text-xs leading-relaxed">
          <span className="font-bold block">
            Administrative Demonstration Notice (উপজেলা শিক্ষা কর্মকর্তা ডেমো ভিউ)
          </span>
          Demonstration only. No real school data, official portal, or central government server is connected. All figures are dynamically calculated from this browser's local sandbox records.
        </div>
      </div>

      {/* Upazila Title Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
                Chatkhil Upazila Secondary Education Monitoring
              </h1>
              <p className="text-xs text-slate-400">
                উপজেলা মাধ্যমিক শিক্ষা কর্মকর্তার পর্যবেক্ষণ ড্যাশবোর্ড • Noakhali District
              </p>
            </div>
          </div>
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-2 self-start md:self-auto bg-slate-800/80 px-3 py-2 rounded-xl border border-slate-700">
          <label htmlFor="upazila-date" className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-teal-400" />
            <span>Inspection Date:</span>
          </label>
          <input
            id="upazila-date"
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-2.5 py-1 rounded-lg text-xs font-medium border border-slate-600 bg-slate-900 text-slate-200 outline-none focus:ring-1 focus:ring-teal-400"
          />
        </div>
      </div>

      {/* Upazila Key Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
            Demo Schools
          </span>
          <p className="text-2xl font-black text-slate-900 mt-1">{schools.length}</p>
          <span className="text-[11px] text-slate-400">Institutions</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
            Total Staff
          </span>
          <p className="text-2xl font-black text-slate-900 mt-1">
            {upazilaStats.totalTeachers}
          </p>
          <span className="text-[11px] text-slate-400">Active Teachers</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider">
            Present Staff
          </span>
          <p className="text-2xl font-black text-emerald-700 mt-1">
            {upazilaStats.presentCount}
          </p>
          <span className="text-[11px] text-emerald-600 font-medium">
            {upazilaStats.lateCount} late
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-rose-700 uppercase tracking-wider">
            Absent Staff
          </span>
          <p className="text-2xl font-black text-rose-700 mt-1">
            {upazilaStats.absentCount}
          </p>
          <span className="text-[11px] text-rose-500">Unrecorded</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs col-span-2 sm:col-span-1">
          <span className="text-[11px] font-semibold text-teal-700 uppercase tracking-wider">
            Upazila Average
          </span>
          <p className="text-2xl font-black text-teal-800 mt-1">
            {upazilaStats.attendanceRate}%
          </p>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2">
            <div
              className="bg-teal-600 h-1.5 rounded-full"
              style={{ width: `${upazilaStats.attendanceRate}%` }}
            />
          </div>
        </div>
      </div>

      {/* School Comparison & Drill-down List */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Institution Performance & Attendance Comparison
            </h2>
            <p className="text-xs text-slate-500">
              Click any school row to inspect teacher-level attendance records for {selectedDate}
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {schoolSummaries.length} institutions tracked
          </span>
        </div>

        <div className="divide-y divide-slate-100">
          {schoolSummaries.map((s) => (
            <div
              key={s.schoolId}
              onClick={() => setDrillDownSchoolId(s.schoolId)}
              className="p-5 hover:bg-slate-50/80 transition-colors cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <SchoolIcon className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{s.schoolName}</span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-semibold">
                      EIIN: {s.eiin}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Category: {s.category} • Total staff: <b>{s.totalTeachers}</b>
                  </div>
                </div>
              </div>

              {/* Attendance metrics & Progress bar */}
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-emerald-700 font-semibold">
                      Present: {s.presentCount}
                    </span>
                    <span className="text-rose-700 font-semibold">
                      Absent: {s.absentCount}
                    </span>
                    <span className="font-bold text-slate-900 font-mono text-sm">
                      {s.attendanceRate}%
                    </span>
                  </div>

                  <div className="w-48 bg-slate-100 rounded-full h-2 mt-1.5 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        s.attendanceRate >= 80
                          ? 'bg-emerald-500'
                          : s.attendanceRate >= 50
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${s.attendanceRate}%` }}
                    />
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-slate-100 text-slate-600 hover:bg-teal-50 hover:text-teal-700 transition-colors">
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Drill-down Modal */}
      {drillDownSchool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => setDrillDownSchoolId(null)}
            aria-hidden="true"
          />

          <div
            role="dialog"
            aria-modal="true"
            className="relative z-10 w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold flex items-center gap-2">
                  <SchoolIcon className="w-4 h-4 text-teal-400" />
                  <span>{drillDownSchool.name}</span>
                </h2>
                <p className="text-xs text-slate-400">
                  EIIN: {drillDownSchool.eiin} • {drillDownSchool.address} • Inspection Date: {selectedDate}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDrillDownSchoolId(null)}
                aria-label="Close institution drill-down"
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Roster */}
            <div className="p-6 overflow-y-auto space-y-4">
              <div className="text-xs text-slate-600">
                Staff Roster & Attendance Status on <b>{selectedDate}</b>:
              </div>

              {drillDownTeachers.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No active teachers registered under this school.
                </div>
              ) : (
                <div className="space-y-2">
                  {drillDownTeachers.map((t) => {
                    const record = drillDownRecordsMap.get(t.id);
                    return (
                      <div
                        key={t.id}
                        className="p-3 rounded-xl border border-slate-200 bg-slate-50/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900">{t.name}</span>
                            <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-slate-200 text-slate-700">
                              {t.id}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500">
                            {t.designation} • {t.subject}
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {record ? (
                            <div className="text-right">
                              <span
                                className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                                  record.status === 'present'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {record.status} ({record.checkInTime})
                              </span>
                              {record.checkOutTime && (
                                <div className="text-[10px] text-slate-500 font-mono">
                                  Out: {record.checkOutTime}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-rose-100 text-rose-800">
                              Absent / Not Logged
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500">
                Total Teachers: <b>{drillDownTeachers.length}</b>
              </span>
              <button
                type="button"
                onClick={() => setDrillDownSchoolId(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 font-semibold text-slate-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
