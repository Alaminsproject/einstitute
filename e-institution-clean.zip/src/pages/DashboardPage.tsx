import React, { useState } from 'react';
import {
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  WifiOff,
  TrendingUp,
  School as SchoolIcon,
  Calendar,
  ArrowRight,
  PlusCircle,
  FileSpreadsheet,
  AlertCircle,
} from 'lucide-react';
import { AttendanceRecord, NavigationPage, School, Teacher } from '../types';
import {
  calculateAttendanceStats,
  calculateSchoolSummaries,
} from '../utils/attendanceLogic';
import { getTodayDateString } from '../services/storageService';

interface DashboardPageProps {
  schools: School[];
  teachers: Teacher[];
  attendanceRecords: AttendanceRecord[];
  onNavigate: (page: NavigationPage) => void;
  onOpenPendingModal: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  schools,
  teachers,
  attendanceRecords,
  onNavigate,
  onOpenPendingModal,
}) => {
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());

  // Dynamic calculations from current local dataset
  const stats = calculateAttendanceStats(teachers, attendanceRecords, selectedDate);
  const schoolSummaries = calculateSchoolSummaries(
    schools,
    teachers,
    attendanceRecords,
    selectedDate
  );

  // Recent attendance records for the selected date or overall
  const dayRecords = attendanceRecords
    .filter((r) => r.date === selectedDate)
    .slice(0, 7);

  const isToday = selectedDate === getTodayDateString();

  return (
    <div className="space-y-6">
      {/* Top Banner & Date Filter Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-xs border border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Institutional Overview Dashboard
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-teal-50 text-teal-700 border border-teal-200">
              Live Local Data
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time local summary for Chatkhil Upazila educational institutions.
          </p>
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <label htmlFor="dashboard-date" className="text-xs font-semibold text-slate-600 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-teal-600" />
            <span>Inspection Date:</span>
          </label>
          <input
            id="dashboard-date"
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-1.5 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none"
          />
          {!isToday && (
            <button
              type="button"
              onClick={() => setSelectedDate(getTodayDateString())}
              className="text-xs font-semibold text-teal-700 hover:text-teal-800 px-2 py-1 rounded-lg bg-teal-50 hover:bg-teal-100 transition-colors"
            >
              Reset to Today
            </button>
          )}
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Teachers */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Active Teachers
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-sans">
              {stats.totalTeachers}
            </span>
            <span className="text-xs text-slate-500">teachers</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Across {schools.length} demo institutions</p>
        </div>

        {/* Present Today */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-emerald-200 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">
              Present Today
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-700">
              {stats.presentCount}
            </span>
            <span className="text-xs text-emerald-600 font-medium">
              ({stats.attendanceRate}%)
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            {stats.lateCount > 0 ? `${stats.lateCount} marked late arrival` : 'All on time'}
          </p>
        </div>

        {/* Absent Today */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-rose-200 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-700 uppercase tracking-wider">
              Absent Today
            </span>
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <XCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-rose-700">
              {stats.absentCount}
            </span>
            <span className="text-xs text-slate-400">teachers</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Pending check-in or leave</p>
        </div>

        {/* Attendance Rate */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-teal-200 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-teal-700 uppercase tracking-wider">
              Attendance Rate
            </span>
            <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-teal-800">
              {stats.attendanceRate}%
            </span>
          </div>
          {/* Visual Mini Progress Bar */}
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div
              className="bg-teal-600 h-1.5 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, stats.attendanceRate)}%` }}
            />
          </div>
        </div>

        {/* Pending Local Sync */}
        <div
          onClick={stats.pendingSyncCount > 0 ? onOpenPendingModal : undefined}
          className={`p-5 rounded-2xl border transition-all ${
            stats.pendingSyncCount > 0
              ? 'bg-amber-50/70 border-amber-300 shadow-xs cursor-pointer hover:bg-amber-50'
              : 'bg-white border-slate-200/90 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider">
              Pending Sync
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <WifiOff className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-900">
              {stats.pendingSyncCount}
            </span>
            <span className="text-xs text-amber-700 font-medium">records</span>
          </div>
          <p className="text-[11px] text-amber-700/80 mt-1">
            {stats.pendingSyncCount > 0
              ? 'Click to review offline queue'
              : 'Queue is clear'}
          </p>
        </div>
      </div>

      {/* Main Grid: Visual Breakdown & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance Breakdown Bar */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Attendance Breakdown ({selectedDate})
              </h2>
              <p className="text-xs text-slate-500">
                Calculated dynamically from current active teacher roster
              </p>
            </div>
            <span className="text-xs font-medium text-slate-500">
              Total: {stats.totalTeachers} teachers
            </span>
          </div>

          {/* Stacked visualization bar */}
          <div className="space-y-3">
            <div className="h-6 w-full rounded-xl bg-slate-100 flex overflow-hidden p-0.5">
              {stats.presentCount - stats.lateCount > 0 && (
                <div
                  title={`On-time Present: ${stats.presentCount - stats.lateCount}`}
                  style={{
                    width: `${((stats.presentCount - stats.lateCount) / Math.max(1, stats.totalTeachers)) * 100}%`,
                  }}
                  className="bg-emerald-500 hover:bg-emerald-600 transition-all rounded-l-lg flex items-center justify-center text-[10px] font-bold text-white shadow-2xs"
                >
                  {stats.presentCount - stats.lateCount > 1 ? `${stats.presentCount - stats.lateCount}` : ''}
                </div>
              )}
              {stats.lateCount > 0 && (
                <div
                  title={`Late Arrival: ${stats.lateCount}`}
                  style={{
                    width: `${(stats.lateCount / Math.max(1, stats.totalTeachers)) * 100}%`,
                  }}
                  className="bg-amber-400 hover:bg-amber-500 transition-all flex items-center justify-center text-[10px] font-bold text-amber-950 shadow-2xs"
                >
                  {stats.lateCount}
                </div>
              )}
              {stats.absentCount > 0 && (
                <div
                  title={`Absent: ${stats.absentCount}`}
                  style={{
                    width: `${(stats.absentCount / Math.max(1, stats.totalTeachers)) * 100}%`,
                  }}
                  className="bg-rose-400 hover:bg-rose-500 transition-all rounded-r-lg flex items-center justify-center text-[10px] font-bold text-white shadow-2xs"
                >
                  {stats.absentCount > 1 ? `${stats.absentCount}` : ''}
                </div>
              )}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center gap-4 text-xs pt-1">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                <span className="text-slate-700 font-medium">
                  On-Time Present: <b>{stats.presentCount - stats.lateCount}</b>
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-amber-400"></span>
                <span className="text-slate-700 font-medium">
                  Late Arrival: <b>{stats.lateCount}</b>
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-400"></span>
                <span className="text-slate-700 font-medium">
                  Absent / Unrecorded: <b>{stats.absentCount}</b>
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                <span className="text-slate-700 font-medium">
                  Checked Out: <b>{stats.checkedOutCount}</b>
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions Bar */}
          <div className="mt-6 pt-5 border-t border-slate-100 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('attendance')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold shadow-xs transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Record Teacher Check-In</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('reports')}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4 text-slate-600" />
              <span>View Attendance Reports</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('upazila')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-teal-700 hover:text-teal-800 hover:bg-teal-50 text-xs font-semibold transition-colors"
            >
              <span>Upazila Comparison</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Recent Activity Feed */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Recent Activity</h2>
            <span className="text-xs text-slate-400">{dayRecords.length} records</span>
          </div>

          <div className="space-y-3 flex-1 overflow-y-auto max-h-72 pr-1">
            {dayRecords.length === 0 ? (
              <div className="text-center py-8 text-slate-400 text-xs">
                <Clock className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-500" />
                <p>No check-in activity on this date.</p>
              </div>
            ) : (
              dayRecords.map((record) => (
                <div
                  key={record.id}
                  className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center justify-between text-xs"
                >
                  <div className="min-w-0 pr-2">
                    <p className="font-semibold text-slate-900 truncate">
                      {record.teacherName}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {record.schoolName}
                    </p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span className="font-mono text-slate-700 font-medium">
                      {record.checkInTime}
                    </span>
                    <span
                      className={`block text-[10px] font-semibold uppercase ${
                        record.status === 'present'
                          ? 'text-emerald-700'
                          : record.status === 'late'
                          ? 'text-amber-700'
                          : 'text-slate-600'
                      }`}
                    >
                      {record.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* School-wise Summary Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              School-wise Attendance Summary (প্রতিষ্ঠানভিত্তিক সারাংশ)
            </h2>
            <p className="text-xs text-slate-500">
              Comparative stats for demo institutions in Chatkhil Upazila for {selectedDate}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('schools')}
            className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Manage All Schools</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[11px] border-b border-slate-200">
              <tr>
                <th className="px-6 py-3.5">Institution Name</th>
                <th className="px-4 py-3.5">EIIN</th>
                <th className="px-4 py-3.5">Category</th>
                <th className="px-4 py-3.5 text-center">Total Staff</th>
                <th className="px-4 py-3.5 text-center">Present</th>
                <th className="px-4 py-3.5 text-center">Absent</th>
                <th className="px-4 py-3.5 text-center">Rate</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {schoolSummaries.map((s) => (
                <tr key={s.schoolId} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-6 py-3.5 font-medium text-slate-900">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center flex-shrink-0">
                        <SchoolIcon className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-semibold">{s.schoolName}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5 font-mono text-slate-600">{s.eiin}</td>
                  <td className="px-4 py-3.5">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-700">
                      {s.category}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-center font-semibold text-slate-800">
                    {s.totalTeachers}
                  </td>
                  <td className="px-4 py-3.5 text-center text-emerald-700 font-bold">
                    {s.presentCount}
                  </td>
                  <td className="px-4 py-3.5 text-center text-rose-700 font-bold">
                    {s.absentCount}
                  </td>
                  <td className="px-4 py-3.5 text-center">
                    <div className="inline-flex items-center gap-1.5">
                      <span className="font-bold text-slate-900">{s.attendanceRate}%</span>
                      <div className="w-12 bg-slate-100 rounded-full h-1.5 hidden sm:block">
                        <div
                          className={`h-1.5 rounded-full ${
                            s.attendanceRate >= 80
                              ? 'bg-emerald-500'
                              : s.attendanceRate >= 50
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${s.attendanceRate}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-3.5 text-right">
                    <button
                      type="button"
                      onClick={() => onNavigate('upazila')}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold text-teal-700 hover:bg-teal-50 transition-colors"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
