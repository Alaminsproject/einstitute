import React, { useState, useMemo } from 'react';
import {
  Fingerprint,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  MapPin,
  LogOut,
  Calendar,
  Filter,
  Check,
  Building2,
  Info,
} from 'lucide-react';
import {
  AttendanceRecord,
  AttendanceStatus,
  LocationData,
  School,
  Teacher,
} from '../types';
import { GeolocationWidget } from '../components/GeolocationWidget';
import { canCheckIn, canCheckOut } from '../utils/attendanceLogic';
import { formatTime12h, getTodayDateString } from '../services/storageService';

interface AttendancePageProps {
  schools: School[];
  teachers: Teacher[];
  attendanceRecords: AttendanceRecord[];
  onRecordCheckIn: (
    teacher: Teacher,
    options?: {
      location?: LocationData;
      status?: AttendanceStatus;
      remarks?: string;
      customTime?: string;
    }
  ) => void;
  onRecordCheckOut: (teacherId: string, customTime?: string) => void;
  isOfflineMode: boolean;
}

export const AttendancePage: React.FC<AttendancePageProps> = ({
  schools,
  teachers,
  attendanceRecords,
  onRecordCheckIn,
  onRecordCheckOut,
  isOfflineMode,
}) => {
  const todayStr = getTodayDateString();

  // Selected teacher for check-in/out
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>('');
  const [teacherSearch, setTeacherSearch] = useState<string>('');
  const [selectedSchoolFilter, setSelectedSchoolFilter] = useState<string>('all');

  // Attendance form options
  const [attendanceStatus, setAttendanceStatus] = useState<AttendanceStatus>('present');
  const [remarks, setRemarks] = useState<string>('');
  const [capturedLocation, setCapturedLocation] = useState<LocationData | undefined>(undefined);

  // Success / error feedback banner
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
  } | null>(null);

  // Tab: 'today' or 'history'
  const [activeTab, setActiveTab] = useState<'today' | 'history'>('today');

  // History filters
  const [historyDate, setHistoryDate] = useState<string>(todayStr);
  const [historyTeacherId, setHistoryTeacherId] = useState<string>('all');
  const [historyStatus, setHistoryStatus] = useState<string>('all');

  // Filtered teachers for selection dropdown/search
  const filteredTeachers = useMemo(() => {
    return teachers.filter((t) => {
      if (t.status !== 'active') return false;
      if (selectedSchoolFilter !== 'all' && t.schoolId !== selectedSchoolFilter) return false;
      if (teacherSearch.trim()) {
        const q = teacherSearch.toLowerCase();
        const matchesName = t.name.toLowerCase().includes(q) || (t.nameBn && t.nameBn.includes(q));
        const matchesId = t.id.toLowerCase().includes(q);
        const matchesSchool = t.schoolName.toLowerCase().includes(q);
        return matchesName || matchesId || matchesSchool;
      }
      return true;
    });
  }, [teachers, selectedSchoolFilter, teacherSearch]);

  const selectedTeacher = useMemo(() => {
    return teachers.find((t) => t.id === selectedTeacherId);
  }, [teachers, selectedTeacherId]);

  // Validation check for selected teacher today
  const checkInValidation = useMemo(() => {
    if (!selectedTeacherId) return { allowed: false, reason: 'Select a teacher first.' };
    return canCheckIn(selectedTeacherId, todayStr, attendanceRecords);
  }, [selectedTeacherId, todayStr, attendanceRecords]);

  const checkOutValidation = useMemo(() => {
    if (!selectedTeacherId) return { allowed: false, reason: 'Select a teacher first.' };
    return canCheckOut(selectedTeacherId, todayStr, attendanceRecords);
  }, [selectedTeacherId, todayStr, attendanceRecords]);

  // Handler for Check-In
  const handleCheckIn = () => {
    if (!selectedTeacher) {
      setFeedback({ type: 'error', message: 'Please select a teacher from the list.' });
      return;
    }

    const val = canCheckIn(selectedTeacher.id, todayStr, attendanceRecords);
    if (!val.allowed) {
      setFeedback({
        type: 'error',
        message: val.reason || 'Duplicate check-in prevented: Teacher already has an attendance record for today.',
      });
      return;
    }

    onRecordCheckIn(selectedTeacher, {
      location: capturedLocation,
      status: attendanceStatus,
      remarks: remarks.trim() || undefined,
    });

    setFeedback({
      type: 'success',
      message: `Check-in recorded successfully for ${selectedTeacher.name} (${formatTime12h()})${
        isOfflineMode ? ' — Stored in offline queue.' : '.'
      }`,
    });

    // Reset remarks and location
    setRemarks('');
  };

  // Handler for Check-Out
  const handleCheckOut = () => {
    if (!selectedTeacher) return;

    const val = canCheckOut(selectedTeacher.id, todayStr, attendanceRecords);
    if (!val.allowed) {
      setFeedback({
        type: 'error',
        message: val.reason || 'Cannot check out: Check-in record is required first.',
      });
      return;
    }

    onRecordCheckOut(selectedTeacher.id);
    setFeedback({
      type: 'success',
      message: `Check-out recorded successfully for ${selectedTeacher.name} at ${formatTime12h()}.`,
    });
  };

  // Today's records
  const todayRecords = useMemo(() => {
    return attendanceRecords.filter((r) => r.date === todayStr);
  }, [attendanceRecords, todayStr]);

  // History filtered records
  const filteredHistory = useMemo(() => {
    return attendanceRecords.filter((r) => {
      if (historyDate && r.date !== historyDate) return false;
      if (historyTeacherId !== 'all' && r.teacherId !== historyTeacherId) return false;
      if (historyStatus !== 'all' && r.status !== historyStatus) return false;
      return true;
    });
  }, [attendanceRecords, historyDate, historyTeacherId, historyStatus]);

  return (
    <div className="space-y-6">
      {/* Top Banner Notice */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Teacher Digital Attendance Kiosk
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-blue-50 text-blue-700 border border-blue-200">
              Interactive Terminal
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Record real-time check-in and check-out for staff. Demonstrates duplicate prevention and offline queueing.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-100 text-slate-700 border border-slate-200">
          <Clock className="w-3.5 h-3.5 text-teal-600" />
          <span>Session: {todayStr}</span>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div
          role="alert"
          className={`p-4 rounded-xl text-xs flex items-center justify-between border ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : feedback.type === 'error'
              ? 'bg-rose-50 text-rose-900 border-rose-300'
              : 'bg-blue-50 text-blue-900 border-blue-300'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            ) : feedback.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-blue-600 flex-shrink-0" />
            )}
            <span className="font-medium">{feedback.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="text-xs font-bold underline px-2 py-0.5 rounded hover:bg-black/5"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Kiosk Layout: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Teacher Selection & Actions (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Fingerprint className="w-5 h-5 text-teal-600" />
                <span>1. Select Teacher for Attendance</span>
              </h2>
              <span className="text-xs text-slate-400">
                {filteredTeachers.length} available
              </span>
            </div>

            {/* School Filter + Search */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Filter by School
                </label>
                <select
                  value={selectedSchoolFilter}
                  onChange={(e) => {
                    setSelectedSchoolFilter(e.target.value);
                    setSelectedTeacherId('');
                  }}
                  className="w-full px-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
                >
                  <option value="all">All Demo Schools</option>
                  {schools.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Search by Name or ID
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="e.g. Rafiqul or TCH-1001"
                    value={teacherSearch}
                    onChange={(e) => setTeacherSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Teacher Select Box */}
            <div>
              <label htmlFor="teacher-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Choose Teacher: <span className="text-rose-500">*</span>
              </label>
              <select
                id="teacher-select"
                value={selectedTeacherId}
                onChange={(e) => {
                  setSelectedTeacherId(e.target.value);
                  setFeedback(null);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl text-xs font-semibold border border-slate-300 bg-slate-50 text-slate-900 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
              >
                <option value="">-- Choose a teacher from the roster --</option>
                {filteredTeachers.map((t) => {
                  const alreadyCheckedIn = todayRecords.some((r) => r.teacherId === t.id);
                  return (
                    <option key={t.id} value={t.id}>
                      {t.id} - {t.name} ({t.designation}) {alreadyCheckedIn ? '✓ [Marked Today]' : ''}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* Selected Teacher Details Card */}
            {selectedTeacher && (
              <div className="p-4 rounded-xl border border-teal-200 bg-teal-50/40 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">
                        {selectedTeacher.name}
                      </span>
                      {selectedTeacher.nameBn && (
                        <span className="text-xs text-slate-500">
                          ({selectedTeacher.nameBn})
                        </span>
                      )}
                      <span className="px-2 py-0.5 rounded font-mono text-[10px] bg-teal-100 text-teal-800 font-bold">
                        {selectedTeacher.id}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      {selectedTeacher.designation} • {selectedTeacher.subject}
                    </div>
                  </div>

                  {/* Status Indicator for Today */}
                  <div>
                    {checkInValidation.existingRecord ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                        <span>Checked In: {checkInValidation.existingRecord.checkInTime}</span>
                        {checkInValidation.existingRecord.checkOutTime && (
                          <span className="ml-1 text-[11px] text-slate-600">
                            (Out: {checkInValidation.existingRecord.checkOutTime})
                          </span>
                        )}
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-300">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        <span>Not checked in yet today</span>
                      </span>
                    )}
                  </div>
                </div>

                <div className="text-xs text-slate-600 flex items-center gap-1.5 pt-1 border-t border-teal-100">
                  <Building2 className="w-3.5 h-3.5 text-teal-600" />
                  <span>{selectedTeacher.schoolName}</span>
                </div>
              </div>
            )}

            {/* Attendance Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Attendance Status
                </label>
                <select
                  value={attendanceStatus}
                  onChange={(e) => setAttendanceStatus(e.target.value as AttendanceStatus)}
                  className="w-full px-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
                >
                  <option value="present">Present (উপস্থিত - On Time)</option>
                  <option value="late">Late Arrival (দেরিতে উপস্থিতি)</option>
                  <option value="half_day">Half Day (অর্ধ দিবস)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Optional Remarks / Note
                </label>
                <input
                  type="text"
                  placeholder="e.g. Exam duty, morning shift"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>
            </div>

            {/* Geolocation Section */}
            <GeolocationWidget
              onLocationCaptured={setCapturedLocation}
              currentLocation={capturedLocation}
            />

            {/* Action Buttons: Check-In & Check-Out */}
            <div className="pt-2 space-y-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Check In Action */}
                <button
                  type="button"
                  onClick={handleCheckIn}
                  disabled={!checkInValidation.allowed}
                  className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-bold transition-all shadow-xs ${
                    checkInValidation.allowed
                      ? 'bg-teal-600 hover:bg-teal-700 text-white cursor-pointer active:scale-98'
                      : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Record Check-In (হাজিরা গ্রহণ)</span>
                </button>

                {/* Check Out Action */}
                <button
                  type="button"
                  onClick={handleCheckOut}
                  disabled={!checkOutValidation.allowed}
                  className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-bold transition-all shadow-xs ${
                    checkOutValidation.allowed
                      ? 'bg-slate-900 hover:bg-slate-800 text-white cursor-pointer active:scale-98'
                      : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                  }`}
                >
                  <LogOut className="w-4 h-4" />
                  <span>Record Check-Out (প্রস্থান)</span>
                </button>
              </div>

              {/* Explanatory validation message under buttons */}
              {selectedTeacherId && !checkInValidation.allowed && (
                <div className="p-2.5 rounded-lg bg-amber-50 text-amber-900 border border-amber-200 text-[11px] flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                  <span>{checkInValidation.reason}</span>
                </div>
              )}
            </div>

            {/* Safety & Local Record Notice */}
            <div className="text-[11px] text-slate-400 leading-relaxed border-t border-slate-100 pt-3">
              <b>Notice:</b> Attendance recorded through this portal is saved locally on your device as a <i>Local Demo Record</i>. It does not represent verified official government attendance.
            </div>
          </div>
        </div>

        {/* Right Column: Today's Log & Attendance Feed (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col h-full">
            {/* Header Tabs */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('today')}
                  className={`text-xs font-bold pb-1 border-b-2 transition-all ${
                    activeTab === 'today'
                      ? 'text-teal-700 border-teal-600'
                      : 'text-slate-500 border-transparent hover:text-slate-800'
                  }`}
                >
                  Today's Feed ({todayRecords.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('history')}
                  className={`text-xs font-bold pb-1 border-b-2 transition-all ${
                    activeTab === 'history'
                      ? 'text-teal-700 border-teal-600'
                      : 'text-slate-500 border-transparent hover:text-slate-800'
                  }`}
                >
                  History Log
                </button>
              </div>

              <span className="text-[11px] font-mono text-slate-400">
                {activeTab === 'today' ? todayStr : 'Filter View'}
              </span>
            </div>

            {/* Tab: Today's Feed */}
            {activeTab === 'today' && (
              <div className="space-y-3 flex-1 overflow-y-auto max-h-[600px] pr-1">
                {todayRecords.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-xs">
                    <Fingerprint className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-slate-600">No Check-ins Yet Today</p>
                    <p className="mt-1 text-slate-400">
                      Select a teacher on the left and click Record Check-In.
                    </p>
                  </div>
                ) : (
                  todayRecords.map((r) => (
                    <div
                      key={r.id}
                      className="p-3 rounded-xl border border-slate-200/80 bg-slate-50 hover:bg-white transition-all space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-semibold text-xs text-slate-900 truncate pr-2">
                          {r.teacherName}
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            r.status === 'present'
                              ? 'bg-emerald-100 text-emerald-800'
                              : r.status === 'late'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {r.status}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-500 truncate">
                        {r.schoolName}
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px] text-slate-600">
                        <div className="flex items-center gap-2">
                          <span className="font-mono">In: {r.checkInTime}</span>
                          {r.checkOutTime && (
                            <span className="font-mono text-slate-500">
                              Out: {r.checkOutTime}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5">
                          {r.location && (
                            <span
                              title={`GPS: ${r.location.latitude}, ${r.location.longitude} (±${r.location.accuracy}m)`}
                              className="text-[10px] text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded flex items-center gap-0.5"
                            >
                              <MapPin className="w-2.5 h-2.5" />
                              GPS
                            </span>
                          )}

                          <span
                            className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                              r.syncStatus === 'pending'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-200 text-slate-700'
                            }`}
                          >
                            {r.syncStatus === 'pending' ? 'Pending' : 'Synced'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Tab: History Log */}
            {activeTab === 'history' && (
              <div className="space-y-3 flex-1 flex flex-col">
                {/* Filters */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                      Date
                    </label>
                    <input
                      type="date"
                      value={historyDate}
                      onChange={(e) => setHistoryDate(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                      Status
                    </label>
                    <select
                      value={historyStatus}
                      onChange={(e) => setHistoryStatus(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                    >
                      <option value="all">All Statuses</option>
                      <option value="present">Present</option>
                      <option value="late">Late</option>
                      <option value="half_day">Half Day</option>
                    </select>
                  </div>
                </div>

                {/* History List */}
                <div className="space-y-2 flex-1 overflow-y-auto max-h-[500px] pr-1">
                  {filteredHistory.length === 0 ? (
                    <div className="text-center py-10 text-slate-400 text-xs">
                      No records match the selected date or filter.
                    </div>
                  ) : (
                    filteredHistory.map((r) => (
                      <div
                        key={r.id}
                        className="p-2.5 rounded-lg border border-slate-200 bg-slate-50/70 text-xs space-y-1"
                      >
                        <div className="flex items-center justify-between font-medium">
                          <span className="text-slate-900">{r.teacherName}</span>
                          <span className="font-mono text-[11px] text-slate-500">{r.date}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">{r.schoolName}</div>
                        <div className="flex items-center justify-between text-[11px] text-slate-600">
                          <span>
                            {r.checkInTime}
                            {r.checkOutTime ? ` → ${r.checkOutTime}` : ''}
                          </span>
                          <span className="uppercase font-semibold text-[10px] text-teal-700">
                            {r.status}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
