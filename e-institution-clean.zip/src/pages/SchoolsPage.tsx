import React, { useState, useMemo } from 'react';
import {
  School as SchoolIcon,
  Search,
  Plus,
  Edit2,
  Trash2,
  Users,
  MapPin,
  Phone,
  Calendar,
  X,
  AlertTriangle,
  Building,
} from 'lucide-react';
import { School, SchoolCategory, Teacher } from '../types';

interface SchoolsPageProps {
  schools: School[];
  teachers: Teacher[];
  onAddSchool: (school: Omit<School, 'id'>) => void;
  onUpdateSchool: (school: School) => void;
  onDeleteSchool: (id: string) => void;
}

const CATEGORIES: SchoolCategory[] = [
  'Secondary High School',
  'Higher Secondary College',
  'Dakhil Madrasah',
  'Model Primary',
];

export const SchoolsPage: React.FC<SchoolsPageProps> = ({
  schools,
  teachers,
  onAddSchool,
  onUpdateSchool,
  onDeleteSchool,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSchool, setEditingSchool] = useState<School | null>(null);
  const [deletingSchool, setDeletingSchool] = useState<School | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    nameBn: '',
    eiin: '',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Secondary High School' as SchoolCategory,
    status: 'active' as 'active' | 'inactive',
    contactPhone: '',
    address: '',
    establishedYear: 1985,
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const resetForm = () => {
    setFormData({
      name: '',
      nameBn: '',
      eiin: '',
      upazila: 'Chatkhil',
      district: 'Noakhali',
      category: 'Secondary High School',
      status: 'active',
      contactPhone: '',
      address: '',
      establishedYear: 1990,
    });
    setFormErrors({});
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (s: School) => {
    setEditingSchool(s);
    setFormData({
      name: s.name,
      nameBn: s.nameBn || '',
      eiin: s.eiin,
      upazila: s.upazila,
      district: s.district,
      category: s.category as SchoolCategory,
      status: s.status,
      contactPhone: s.contactPhone,
      address: s.address,
      establishedYear: s.establishedYear,
    });
    setFormErrors({});
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'School name is required.';
    if (!formData.eiin.trim()) errs.eiin = 'School Code / EIIN is required.';
    if (!formData.contactPhone.trim()) errs.contactPhone = 'Contact phone is required.';
    if (!formData.address.trim()) errs.address = 'Address is required.';
    setFormErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    if (editingSchool) {
      onUpdateSchool({
        ...editingSchool,
        ...formData,
      });
      setEditingSchool(null);
    } else {
      onAddSchool(formData);
      setIsAddModalOpen(false);
    }
    resetForm();
  };

  // Compute teacher counts per school
  const teacherCountMap = useMemo(() => {
    const map = new Map<string, number>();
    teachers.forEach((t) => {
      if (t.status === 'active') {
        map.set(t.schoolId, (map.get(t.schoolId) || 0) + 1);
      }
    });
    return map;
  }, [teachers]);

  const filteredSchools = useMemo(() => {
    return schools.filter((s) => {
      if (categoryFilter !== 'all' && s.category !== categoryFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          s.name.toLowerCase().includes(q) ||
          (s.nameBn && s.nameBn.includes(q)) ||
          s.eiin.includes(q) ||
          s.address.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [schools, categoryFilter, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Educational Institutions Directory (প্রতিষ্ঠান পরিচিতি)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Registered demo schools, colleges, and madrasahs in Chatkhil Upazila, Noakhali.
          </p>
        </div>

        <button
          type="button"
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Register New Institution</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Search by school name, EIIN, or location..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
          />
        </div>

        <div>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full px-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
          >
            <option value="all">All Institution Categories</option>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Schools Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredSchools.map((s) => {
          const teacherCount = teacherCountMap.get(s.id) || 0;
          return (
            <div
              key={s.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:border-teal-300 transition-all p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center flex-shrink-0">
                    <SchoolIcon className="w-5 h-5" />
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                    {s.category}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-sm">{s.name}</h3>
                {s.nameBn && (
                  <p className="text-xs text-slate-500 mt-0.5">{s.nameBn}</p>
                )}

                <div className="mt-3 pt-3 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">School Code / EIIN:</span>
                    <span className="font-mono font-bold text-slate-800">{s.eiin}</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Upazila & District:</span>
                    <span className="font-medium text-slate-700">
                      {s.upazila}, {s.district}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Active Teachers:</span>
                    <span className="font-bold text-teal-700 flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {teacherCount} staff
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Contact:</span>
                    <span className="font-mono text-slate-700">{s.contactPhone}</span>
                  </div>

                  <div className="flex items-start gap-1 pt-1 text-[11px] text-slate-500">
                    <MapPin className="w-3 h-3 text-slate-400 flex-shrink-0 mt-0.5" />
                    <span>{s.address}</span>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] font-mono text-slate-400">Est. {s.establishedYear}</span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(s)}
                    aria-label={`Edit ${s.name}`}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-teal-700 hover:bg-teal-50 transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeletingSchool(s)}
                    aria-label={`Delete ${s.name}`}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-700 hover:bg-rose-50 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit School Modal */}
      {(isAddModalOpen || editingSchool) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => {
              setIsAddModalOpen(false);
              setEditingSchool(null);
            }}
            aria-hidden="true"
          />

          <div
            role="dialog"
            aria-modal="true"
            className="relative z-10 w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
          >
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h2 className="text-base font-bold">
                {editingSchool ? 'Edit Institution Info' : 'Register New Institution'}
              </h2>
              <button
                type="button"
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingSchool(null);
                }}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  School / Institution Name (English) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Chatkhil Panchgaon Mahbub Government College"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
                {formErrors.name && (
                  <p className="text-[11px] text-rose-600 mt-1">{formErrors.name}</p>
                )}
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  School Name (বাংলা) <span className="text-slate-400 font-normal">(ঐচ্ছিক)</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. চাটখিল পাঁচগাঁও মাহবুব সরকারি কলেজ"
                  value={formData.nameBn}
                  onChange={(e) => setFormData({ ...formData, nameBn: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    School Code / EIIN <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 112450"
                    value={formData.eiin}
                    onChange={(e) => setFormData({ ...formData, eiin: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none font-mono"
                  />
                  {formErrors.eiin && (
                    <p className="text-[11px] text-rose-600 mt-1">{formErrors.eiin}</p>
                  )}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Category
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({ ...formData, category: e.target.value as SchoolCategory })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-teal-500 outline-none"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Upazila</label>
                  <input
                    type="text"
                    value={formData.upazila}
                    onChange={(e) => setFormData({ ...formData, upazila: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">District</label>
                  <input
                    type="text"
                    value={formData.district}
                    onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Contact Phone <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="01712-XXXXXX"
                    value={formData.contactPhone}
                    onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none font-mono"
                  />
                  {formErrors.contactPhone && (
                    <p className="text-[11px] text-rose-600 mt-1">{formErrors.contactPhone}</p>
                  )}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Established Year
                  </label>
                  <input
                    type="number"
                    value={formData.establishedYear}
                    onChange={(e) =>
                      setFormData({ ...formData, establishedYear: parseInt(e.target.value, 10) })
                    }
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Full Address <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Chatkhil, Noakhali"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
                {formErrors.address && (
                  <p className="text-[11px] text-rose-600 mt-1">{formErrors.address}</p>
                )}
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingSchool(null);
                  }}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-semibold shadow-xs"
                >
                  {editingSchool ? 'Update School' : 'Save School'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete School Confirmation */}
      {deletingSchool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => setDeletingSchool(null)}
            aria-hidden="true"
          />
          <div
            role="dialog"
            aria-modal="true"
            className="relative z-10 w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 space-y-4"
          >
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Confirm Deletion</h3>
                <p className="text-xs text-slate-500">Institution will be removed locally.</p>
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              Are you sure you want to delete <b>{deletingSchool.name}</b> (EIIN: {deletingSchool.eiin})?
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeletingSchool(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteSchool(deletingSchool.id);
                  setDeletingSchool(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white shadow-xs"
              >
                Delete Institution
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
