import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Download,
  Calendar,
  Filter,
  Users,
  CheckCircle2,
  XCircle,
  WifiOff,
  Search,
  MapPin,
  TrendingUp,
} from 'lucide-react';
import { AttendanceRecord, School, Teacher } from '../types';
import {
  generateAttendanceCsv,
  filterRecords,
} from '../utils/attendanceLogic';
import { getTodayDateString } from '../services/storageService';

interface ReportsPageProps {
  schools: School[];
  teachers: Teacher[];
  attendanceRecords: AttendanceRecord[];
}

export const ReportsPage: React.FC<ReportsPageProps> = ({
  schools,
  teachers,
  attendanceRecords,
}) => {
  const todayStr = getTodayDateString();

  // Date range presets
  const [dateFilterMode, setDateFilterMode] = useState<'today' | 'last7' | 'month' | 'custom'>('today');
  const [customStartDate, setCustomStartDate] = useState(todayStr);
  const [customEndDate, setCustomEndDate] = useState(todayStr);

  // Other filters
  const [selectedSchoolId, setSelectedSchoolId] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Compute effective date range
  const { startDate, endDate } = useMemo(() => {
    const today = new Date();
    if (dateFilterMode === 'today') {
      return { startDate: todayStr, endDate: todayStr };
    }
    if (dateFilterMode === 'last7') {
      const past = new Date();
      past.setDate(today.getDate() - 6);
      return { startDate: past.toISOString().split('T')[0], endDate: todayStr };
    }
    if (dateFilterMode === 'month') {
      const past = new Date();
      past.setDate(today.getDate() - 30);
      return { startDate: past.toISOString().split('T')[0], endDate: todayStr };
    }
    return { startDate: customStartDate, endDate: customEndDate };
  }, [dateFilterMode, todayStr, customStartDate, customEndDate]);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return filterRecords(attendanceRecords, {
      startDate,
      endDate,
      schoolId: selectedSchoolId === 'all' ? undefined : selectedSchoolId,
      status: statusFilter === 'all' ? undefined : statusFilter,
      searchQuery: searchQuery.trim() || undefined,
    });
  }, [attendanceRecords, startDate, endDate, selectedSchoolId, statusFilter, searchQuery]);

  // Aggregate metrics for filtered view
  const metrics = useMemo(() => {
    const totalRecords = filteredRecords.length;
    const presentCount = filteredRecords.filter(
      (r) => r.status === 'present' || r.status === 'late' || r.status === 'half_day'
    ).length;
    const lateCount = filteredRecords.filter((r) => r.status === 'late').length;
    const pendingSyncCount = filteredRecords.filter((r) => r.syncStatus === 'pending').length;
    const withGpsCount = filteredRecords.filter((r) => !!r.location).length;

    // Rate relative to active teachers * days in window or total records
    const rate = totalRecords > 0 ? Math.round((presentCount / totalRecords) * 1000) / 10 : 0;

    return {
      totalRecords,
      presentCount,
      lateCount,
      pendingSyncCount,
      withGpsCount,
      rate,
    };
  }, [filteredRecords]);

  // Handler for CSV Export
  const handleExportCsv = () => {
    const csvContent = generateAttendanceCsv(filteredRecords);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute(
      'download',
      `e-institution-attendance-report-${startDate}-to-${endDate}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-slate-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Attendance Analytics & Reports
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-teal-50 text-teal-700 border border-teal-200">
              CSV Export Ready
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Query historical and daily logs across demo institutions in Chatkhil Upazila.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportCsv}
          disabled={filteredRecords.length === 0}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xs transition-all self-start md:self-auto ${
            filteredRecords.length > 0
              ? 'bg-teal-600 hover:bg-teal-700 text-white cursor-pointer active:scale-95'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          <Download className="w-4 h-4" />
          <span>Export Current Records (.CSV)</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
        {/* Date presets */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-teal-600" />
            <span className="text-xs font-bold text-slate-800">Date Range Preset:</span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'today', label: "Today's Attendance" },
              { id: 'last7', label: 'Last 7 Days' },
              { id: 'month', label: 'Last 30 Days' },
              { id: 'custom', label: 'Custom Range' },
            ].map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setDateFilterMode(p.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  dateFilterMode === p.id
                    ? 'bg-teal-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Range Inputs if selected */}
        {dateFilterMode === 'custom' && (
          <div className="p-3 bg-teal-50/50 rounded-xl border border-teal-100 flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-600 font-medium">From:</span>
              <input
                type="date"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-600 font-medium">To:</span>
              <input
                type="date"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white"
              />
            </div>
          </div>
        )}

        {/* Search, School & Status dropdowns */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search teacher name, ID, or school..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
            />
          </div>

          <div>
            <select
              value={selectedSchoolId}
              onChange={(e) => setSelectedSchoolId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
            >
              <option value="all">All Demo Institutions</option>
              {schools.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-xs font-medium border border-slate-300 bg-white text-slate-800 shadow-2xs focus:ring-2 focus:ring-teal-500 outline-none"
            >
              <option value="all">All Attendance Statuses</option>
              <option value="present">Present (On Time)</option>
              <option value="late">Late Arrival</option>
              <option value="half_day">Half Day</option>
            </select>
          </div>
        </div>
      </div>

      {/* Aggregate Metrics Bar for this filter */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Filtered Records
          </span>
          <p className="text-xl font-bold text-slate-900 mt-1">{metrics.totalRecords}</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-emerald-700 uppercase">
            Present Records
          </span>
          <p className="text-xl font-bold text-emerald-700 mt-1">{metrics.presentCount}</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-amber-700 uppercase">
            Late Arrivals
          </span>
          <p className="text-xl font-bold text-amber-700 mt-1">{metrics.lateCount}</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-[11px] font-semibold text-teal-700 uppercase">
            GPS Coordinates Logged
          </span>
          <p className="text-xl font-bold text-teal-800 mt-1">{metrics.withGpsCount}</p>
        </div>
      </div>

      {/* Report Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="px-6 py-3.5 border-b border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            Displaying <b>{filteredRecords.length}</b> attendance logs ({startDate} to {endDate})
          </span>
          <span className="text-teal-700 font-medium">Ready for CSV download</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[11px] border-b border-slate-200">
              <tr>
                <th className="px-6 py-3.5">Date</th>
                <th className="px-4 py-3.5">Teacher & ID</th>
                <th className="px-4 py-3.5">Institution</th>
                <th className="px-4 py-3.5">Check-In</th>
                <th className="px-4 py-3.5">Check-Out</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                <th className="px-4 py-3.5 text-center">GPS</th>
                <th className="px-6 py-3.5 text-right">Sync Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-slate-400">
                    <FileSpreadsheet className="w-10 h-10 mx-auto mb-2 text-slate-300" />
                    <p className="font-semibold text-slate-600">No records found</p>
                    <p className="text-xs text-slate-400 mt-1">
                      No attendance was logged matching these criteria.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-6 py-3.5 font-mono text-slate-800 font-medium">
                      {r.date}
                    </td>

                    <td className="px-4 py-3.5">
                      <div className="font-bold text-slate-900">{r.teacherName}</div>
                      <span className="font-mono text-[10px] text-slate-500">{r.teacherId}</span>
                    </td>

                    <td className="px-4 py-3.5 text-slate-700">{r.schoolName}</td>

                    <td className="px-4 py-3.5 font-mono text-slate-700">{r.checkInTime}</td>

                    <td className="px-4 py-3.5 font-mono text-slate-500">
                      {r.checkOutTime || '—'}
                    </td>

                    <td className="px-4 py-3.5 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          r.status === 'present'
                            ? 'bg-emerald-100 text-emerald-800'
                            : r.status === 'late'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {r.status}
                      </span>
                    </td>

                    <td className="px-4 py-3.5 text-center">
                      {r.location ? (
                        <span
                          title={`Lat: ${r.location.latitude}, Lng: ${r.location.longitude}`}
                          className="inline-flex items-center gap-1 text-[10px] text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded border border-teal-200"
                        >
                          <MapPin className="w-2.5 h-2.5" />
                          Logged
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-400">None</span>
                      )}
                    </td>

                    <td className="px-6 py-3.5 text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                          r.syncStatus === 'pending'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {r.syncStatus === 'pending' ? 'Pending' : 'Synced'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
