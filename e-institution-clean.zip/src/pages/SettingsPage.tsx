import React, { useState } from 'react';
import {
  Sliders,
  RotateCcw,
  Wifi,
  WifiOff,
  Trash2,
  Download,
  Upload,
  Database,
  CheckCircle2,
  AlertTriangle,
  Info,
  Server,
  Layers,
} from 'lucide-react';
import { AppSettings, AttendanceRecord, School, Teacher } from '../types';

interface SettingsPageProps {
  settings: AppSettings;
  onToggleOffline: () => void;
  onResetToDefault: () => void;
  onClearAll: () => void;
  onExportBackup: () => void;
  onImportBackup: (jsonStr: string) => boolean;
  schools: School[];
  teachers: Teacher[];
  attendanceRecords: AttendanceRecord[];
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  onToggleOffline,
  onResetToDefault,
  onClearAll,
  onExportBackup,
  onImportBackup,
  schools,
  teachers,
  attendanceRecords,
}) => {
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const [clearModalOpen, setClearModalOpen] = useState(false);
  const [importNotice, setImportNotice] = useState<string | null>(null);

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = onImportBackup(content);
        if (success) {
          setImportNotice('Demo dataset successfully imported and saved to localStorage!');
        } else {
          setImportNotice('Invalid JSON file format. Import failed.');
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Title */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 shadow-xs border border-slate-200/80">
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
          System Settings & Demo Sandbox Controls
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Configure the offline simulation engine, manage local storage cache, and view architecture specifications.
        </p>
      </div>

      {/* Notice Message */}
      {importNotice && (
        <div className="p-4 rounded-xl bg-teal-50 border border-teal-200 text-teal-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-teal-600 flex-shrink-0" />
            <span className="font-semibold">{importNotice}</span>
          </div>
          <button
            type="button"
            onClick={() => setImportNotice(null)}
            className="text-xs font-bold underline"
          >
            Close
          </button>
        </div>
      )}

      {/* Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Offline Engine Simulation */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                settings.isOfflineMode
                  ? 'bg-amber-100 text-amber-700'
                  : 'bg-emerald-100 text-emerald-700'
              }`}
            >
              {settings.isOfflineMode ? (
                <WifiOff className="w-5 h-5" />
              ) : (
                <Wifi className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Online / Offline Demo Simulation
              </h2>
              <p className="text-xs text-slate-500">
                Test field conditions when internet service is disconnected
              </p>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            When <b>Demo-Offline Mode</b> is active, new check-in and check-out logs are placed into the local <i>Pending Sync Queue</i> with unique stable IDs. When toggled back or synced, you can demonstrate queue flushing.
          </p>

          <div className="pt-2 flex items-center justify-between border-t border-slate-100">
            <span className="text-xs font-semibold text-slate-700">
              Current Simulation State:
            </span>
            <button
              type="button"
              onClick={onToggleOffline}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                settings.isOfflineMode
                  ? 'bg-amber-600 hover:bg-amber-700 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              {settings.isOfflineMode ? 'Turn Simulated Online' : 'Turn Simulated Offline'}
            </button>
          </div>
        </div>

        {/* Local Storage Sandbox Overview */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Device Storage (Browser Sandbox)
              </h2>
              <p className="text-xs text-slate-500">
                Client-side persistence via HTML5 localStorage
              </p>
            </div>
          </div>

          <div className="space-y-2 text-xs text-slate-600">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span>Registered Institutions:</span>
              <span className="font-bold text-slate-800">{schools.length} schools</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span>Registered Staff:</span>
              <span className="font-bold text-slate-800">{teachers.length} teachers</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span>Attendance Records:</span>
              <span className="font-bold text-slate-800">{attendanceRecords.length} records</span>
            </div>
            <div className="flex justify-between py-1">
              <span>Sync Queue:</span>
              <span className="font-bold text-amber-700">
                {attendanceRecords.filter((r) => r.syncStatus === 'pending').length} pending
              </span>
            </div>
          </div>
        </div>

        {/* Data Reset & Sample Restoration */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Sample Data Management
              </h2>
              <p className="text-xs text-slate-500">
                Restore defaults or purge testing records
              </p>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Need to reset after demonstrating various scenarios? Easily restore the 5 demo Bangladeshi schools and 14 teacher profiles with sample attendance history.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setResetModalOpen(true)}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white transition-colors shadow-xs"
            >
              Restore Initial Sample Data
            </button>
            <button
              type="button"
              onClick={() => setClearModalOpen(true)}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors"
            >
              Purge All Records
            </button>
          </div>
        </div>

        {/* Export / Import Backup */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Data Backup & Migration (JSON)
              </h2>
              <p className="text-xs text-slate-500">
                Save or transfer your modified demo state
              </p>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Export your current schools, teachers, and attendance logs to a JSON backup file to test on another machine or preserve a demonstration state.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onExportBackup}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white transition-colors shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON Backup</span>
            </button>

            <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer border border-slate-200">
              <Upload className="w-3.5 h-3.5 text-slate-600" />
              <span>Import JSON File</span>
              <input
                type="file"
                accept=".json"
                onChange={handleFileImport}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* Backend Architecture Roadmap Callout */}
      <div className="bg-gradient-to-br from-slate-900 to-blue-950 text-white rounded-2xl p-6 shadow-md border border-slate-800 space-y-3">
        <div className="flex items-center gap-2.5">
          <Layers className="w-5 h-5 text-teal-400" />
          <h2 className="text-sm font-bold">
            e-Institution Clean Architecture & Future Backend Integration
          </h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          The application follows a decoupled service repository pattern (<code>storageService.ts</code> and <code>attendanceLogic.ts</code>). All views interact exclusively with typed interfaces (<code>Teacher</code>, <code>School</code>, <code>AttendanceRecord</code>).
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <span className="font-bold text-teal-300 block mb-1">Phase 1: Frontend Demo</span>
            Runs entirely in the browser using HTML5 localStorage with duplicate checks, simulated offline queues, and CSV exports.
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <span className="font-bold text-teal-300 block mb-1">Phase 2: Cloud Firestore</span>
            Direct replacement of <code>StorageService</code> methods with Firestore collections and real-time listeners.
          </div>
          <div className="p-3 rounded-xl bg-white/5 border border-white/10">
            <span className="font-bold text-teal-300 block mb-1">Phase 3: National Scale</span>
            Role-based authentication (Upazila Education Officer vs Head Teacher vs Staff) with multi-district sharding.
          </div>
        </div>
      </div>

      {/* Reset Confirmation Modal */}
      {resetModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => setResetModalOpen(false)}
            aria-hidden="true"
          />
          <div
            role="dialog"
            aria-modal="true"
            className="relative z-10 w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 space-y-4"
          >
            <div className="flex items-center gap-3 text-teal-700">
              <div className="w-10 h-10 rounded-full bg-teal-50 flex items-center justify-center flex-shrink-0">
                <RotateCcw className="w-5 h-5 text-teal-600" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Restore Default Sample Data?
                </h3>
                <p className="text-xs text-slate-500">
                  Will restore the 5 demo schools and 14 teacher profiles.
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Any newly added demo records or modified teachers will be reset back to the pristine Bangladeshi school dataset.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setResetModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onResetToDefault();
                  setResetModalOpen(false);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white shadow-xs"
              >
                Yes, Restore Defaults
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Modal */}
      {clearModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => setClearModalOpen(false)}
            aria-hidden="true"
          />
          <div
            role="dialog"
            aria-modal="true"
            className="relative z-10 w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 border border-slate-200 space-y-4"
          >
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-600" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Purge All Local Storage?
                </h3>
                <p className="text-xs text-slate-500">Empties all tables and test records.</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              This is useful for verifying empty states in your demo. You can restore sample data at any time afterwards.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setClearModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearAll();
                  setClearModalOpen(false);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white shadow-xs"
              >
                Yes, Purge Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
