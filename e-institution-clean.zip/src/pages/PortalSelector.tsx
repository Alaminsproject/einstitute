import React, { useState, useMemo } from 'react';
import {
  Building2,
  GraduationCap,
  HeartHandshake,
  ArrowRight,
  Globe,
} from 'lucide-react';
import { Language, ParentGuardian, PortalRole, School, Teacher } from '../types';
import { EducationalQuotes } from '../components/EducationalQuotes';

interface PortalSelectorProps {
  onSelectRole: (role: PortalRole) => void;
  teachers: Teacher[];
  parents: ParentGuardian[];
  currentTeacherId: string;
  onSelectTeacherId: (id: string) => void;
  currentParentId: string;
  onSelectParentId: (id: string) => void;
  schools?: School[];
  language?: Language;
  onChangeLanguage?: (lang: Language) => void;
}

interface PortalSelectorProps {
  onSelectRole: (role: PortalRole) => void;
  teachers: Teacher[];
  parents: ParentGuardian[];
  currentTeacherId: string;
  onSelectTeacherId: (id: string) => void;
  currentParentId: string;
  onSelectParentId: (id: string) => void;
  schools?: School[];
  language?: Language;
  onChangeLanguage?: (lang: Language) => void;
}

export const PortalSelector: React.FC<PortalSelectorProps> = ({
  onSelectRole,
  teachers,
  parents,
  currentTeacherId,
  onSelectTeacherId,
  currentParentId,
  onSelectParentId,
  schools = [],
  language = 'en',
  onChangeLanguage,
}) => {
  const isBn = language === 'bn';

  return (
    <div className="min-h-screen bg-white text-slate-800 font-sans flex flex-col">
      {/* Header */}
      <nav className="border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
            <span className="text-lg font-bold text-slate-900 tracking-tight">e-Institution</span>
          </div>
          {onChangeLanguage && (
            <button
              type="button"
              onClick={() => onChangeLanguage(isBn ? 'en' : 'bn')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-200 cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{isBn ? 'English' : 'বাংলা'}</span>
            </button>
          )}
        </div>
      </nav>

      {/* Portal Selection */}
      <section className="flex-1 flex flex-col justify-center py-12 px-4">
        <div className="max-w-5xl mx-auto text-center mb-10">
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            {isBn ? 'স্বাগতম' : 'Welcome'}
          </h1>
          <p className="mt-2 text-slate-600 text-sm">
            {isBn ? 'একটি প্ল্যাটফর্ম। উন্নত সংযুক্ত প্রতিষ্ঠান।' : 'One Platform. Better Connected Institutions.'}
          </p>
          <div className="mt-4 max-w-xl mx-auto">
            <EducationalQuotes language={language} />
          </div>
        </div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 px-4">
          {/* Authority */}
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 flex flex-col items-center text-center space-y-4 hover:border-blue-300 transition-all">
            <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg">
              <Building2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">{isBn ? 'ঊর্ধ্বতন কর্তৃপক্ষ' : 'Higher Authority'}</h3>
            <p className="text-xs text-slate-600 flex-1">{isBn ? 'প্রতিষ্ঠান তদারকি, উপস্থিতি ও রিপোর্ট।' : 'Monitor institutions, attendance, and reports.'}</p>
            <button
              onClick={() => onSelectRole('authority')}
              className="w-full py-3 rounded-xl bg-blue-600 text-white font-bold text-sm hover:bg-blue-700 cursor-pointer"
            >
              {isBn ? 'প্রবেশ করুন' : 'Open Authority Portal'}
            </button>
          </div>

          {/* Teacher */}
          <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 flex flex-col items-center text-center space-y-4 hover:border-emerald-300 transition-all">
            <div className="w-16 h-16 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg">
              <GraduationCap className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">{isBn ? 'শিক্ষক' : 'Teacher'}</h3>
            <p className="text-xs text-slate-600 flex-1">{isBn ? 'উপস্থিতি, ক্লাস ও হোমওয়ার্ক ব্যবস্থাপনা।' : 'Record attendance, manage classes, assign homework.'}</p>
            <div className="w-full space-y-2">
              <select
                value={currentTeacherId}
                onChange={(e) => onSelectTeacherId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg text-xs border border-emerald-200 bg-white"
              >
                {teachers.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
              <button
                onClick={() => onSelectRole('teacher')}
                className="w-full py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 cursor-pointer"
              >
                {isBn ? 'প্রবেশ করুন' : 'Open Teacher Portal'}
              </button>
            </div>
          </div>

          {/* Parent */}
          <div className="bg-orange-50 border border-orange-100 rounded-2xl p-6 flex flex-col items-center text-center space-y-4 hover:border-orange-300 transition-all">
            <div className="w-16 h-16 rounded-2xl bg-orange-600 text-white flex items-center justify-center shadow-lg">
              <HeartHandshake className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">{isBn ? 'অভিভাবক' : 'Parent'}</h3>
            <p className="text-xs text-slate-600 flex-1">{isBn ? 'উপস্থিতি ও সন্তানের অগ্রগতি দেখুন।' : 'View attendance, homework, and reports.'}</p>
            <div className="w-full space-y-2">
              <select
                value={currentParentId}
                onChange={(e) => onSelectParentId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg text-xs border border-orange-200 bg-white"
              >
                {parents.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <button
                onClick={() => onSelectRole('parent')}
                className="w-full py-3 rounded-xl bg-orange-600 text-white font-bold text-sm hover:bg-orange-700 cursor-pointer"
              >
                {isBn ? 'প্রবেশ করুন' : 'Open Parent Portal'}
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
