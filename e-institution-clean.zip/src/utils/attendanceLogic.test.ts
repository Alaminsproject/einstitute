import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canCheckIn,
  canCheckOut,
  calculateAttendanceStats,
  generateAttendanceCsv,
  calculateSchoolSummaries,
} from './attendanceLogic';
import { AttendanceRecord, Teacher, School } from '../types';

const mockTeachers: Teacher[] = [
  {
    id: 'TCH-001',
    name: 'Mohammad Rafiqul Islam',
    nameBn: 'মোহাম্মদ রফিকুল ইসলাম',
    designation: 'Head Teacher',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil PG Government High School',
    phone: '01711223344',
    email: 'rafiqul@example.com',
    subject: 'Administration',
    joinDate: '2015-01-10',
    status: 'active',
  },
  {
    id: 'TCH-002',
    name: 'Nusrat Jahan',
    nameBn: 'নুসরাত জাহান',
    designation: 'Senior Teacher',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil PG Government High School',
    phone: '01811223344',
    email: 'nusrat@example.com',
    subject: 'Mathematics',
    joinDate: '2018-03-15',
    status: 'active',
  },
  {
    id: 'TCH-003',
    name: 'Kabir Hossain',
    nameBn: 'কবীর হোসেন',
    designation: 'Assistant Teacher (Science)',
    schoolId: 'SCH-02',
    schoolName: 'Meghna Adarsha High School',
    phone: '01911223344',
    email: 'kabir@example.com',
    subject: 'General Science',
    joinDate: '2020-07-01',
    status: 'inactive', // inactive teacher should not count towards active metrics
  },
];

const mockSchools: School[] = [
  {
    id: 'SCH-01',
    name: 'Chatkhil PG Government High School',
    eiin: '112001',
    upazila: 'Chatkhil',
    district: 'Noakhali',
    category: 'Secondary High School',
    status: 'active',
    contactPhone: '01711000000',
    address: 'Chatkhil, Noakhali',
    establishedYear: 1974,
  },
];

const mockRecords: AttendanceRecord[] = [
  {
    id: 'rec-1',
    teacherId: 'TCH-001',
    teacherName: 'Mohammad Rafiqul Islam',
    schoolId: 'SCH-01',
    schoolName: 'Chatkhil PG Government High School',
    date: '2026-10-27',
    checkInTime: '08:45 AM',
    status: 'present',
    syncStatus: 'synced',
    createdAt: new Date().toISOString(),
  },
];

test('canCheckIn allows check-in when teacher has no record for the date', () => {
  const check = canCheckIn('TCH-002', '2026-10-27', mockRecords);
  assert.equal(check.allowed, true);
});

test('canCheckIn blocks duplicate check-in for the same teacher on the same day', () => {
  const check = canCheckIn('TCH-001', '2026-10-27', mockRecords);
  assert.equal(check.allowed, false);
  assert.match(check.reason || '', /already marked/i);
});

test('canCheckOut requires existing check-in and prevents double checkout', () => {
  const checkWithoutIn = canCheckOut('TCH-002', '2026-10-27', mockRecords);
  assert.equal(checkWithoutIn.allowed, false);
  assert.match(checkWithoutIn.reason || '', /No check-in record found/i);

  const checkAllowed = canCheckOut('TCH-001', '2026-10-27', mockRecords);
  assert.equal(checkAllowed.allowed, true);

  const recordsWithCheckout: AttendanceRecord[] = [
    {
      ...mockRecords[0],
      checkOutTime: '04:15 PM',
    },
  ];
  const checkDoubleOut = canCheckOut('TCH-001', '2026-10-27', recordsWithCheckout);
  assert.equal(checkDoubleOut.allowed, false);
  assert.match(checkDoubleOut.reason || '', /already checked out/i);
});

test('calculateAttendanceStats calculates correct metrics for active teachers', () => {
  const stats = calculateAttendanceStats(mockTeachers, mockRecords, '2026-10-27');
  // Total active teachers: TCH-001 and TCH-002 (2 total, TCH-003 is inactive)
  assert.equal(stats.totalTeachers, 2);
  assert.equal(stats.presentCount, 1);
  assert.equal(stats.absentCount, 1);
  assert.equal(stats.attendanceRate, 50.0);
  assert.equal(stats.pendingSyncCount, 0);
});

test('generateAttendanceCsv produces valid CSV with headers and rows', () => {
  const csv = generateAttendanceCsv(mockRecords);
  assert.ok(csv.includes('Record ID,Date,Teacher ID'));
  assert.ok(csv.includes('TCH-001'));
  assert.ok(csv.includes('Chatkhil PG Government High School'));
});

test('calculateSchoolSummaries returns school breakdown', () => {
  const summaries = calculateSchoolSummaries(mockSchools, mockTeachers, mockRecords, '2026-10-27');
  assert.equal(summaries.length, 1);
  assert.equal(summaries[0].schoolId, 'SCH-01');
  assert.equal(summaries[0].totalTeachers, 2);
  assert.equal(summaries[0].presentCount, 1);
  assert.equal(summaries[0].attendanceRate, 50.0);
});
