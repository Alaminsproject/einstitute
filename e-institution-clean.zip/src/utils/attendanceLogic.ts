import {
  AttendanceStatus,
  School,
  Student,
  StudentAttendanceRecord,
  Teacher,
  TeacherAttendanceRecord,
} from '../types';

export function canCheckIn(
  teacherId: string,
  date: string,
  records: TeacherAttendanceRecord[]
): { allowed: boolean; reason?: string; existingRecord?: TeacherAttendanceRecord } {
  const existing = records.find(
    (r) => r.teacherId === teacherId && r.date === date
  );

  if (existing) {
    return {
      allowed: false,
      reason: `Teacher is already marked ${existing.status.toUpperCase()} today with check-in at ${existing.checkInTime}.`,
      existingRecord: existing,
    };
  }

  return { allowed: true };
}

export function canCheckOut(
  teacherId: string,
  date: string,
  records: TeacherAttendanceRecord[]
): { allowed: boolean; reason?: string; existingRecord?: TeacherAttendanceRecord } {
  const existing = records.find(
    (r) => r.teacherId === teacherId && r.date === date
  );

  if (!existing) {
    return {
      allowed: false,
      reason: 'No check-in record found for this teacher today. Check-in must be recorded first.',
    };
  }

  if (existing.checkOutTime) {
    return {
      allowed: false,
      reason: `Teacher has already checked out at ${existing.checkOutTime}.`,
      existingRecord: existing,
    };
  }

  return { allowed: true, existingRecord: existing };
}

export function calculateAttendanceStats(
  teachers: Teacher[],
  records: TeacherAttendanceRecord[],
  targetDate: string
) {
  const activeTeachers = teachers.filter((t) => t.status === 'active');
  const totalTeachers = activeTeachers.length;
  const activeTeacherIds = new Set(activeTeachers.map((t) => t.id));

  const dayRecords = records.filter(
    (r) => r.date === targetDate && activeTeacherIds.has(r.teacherId)
  );

  const presentSet = new Set<string>();
  const lateSet = new Set<string>();
  const checkedOutSet = new Set<string>();

  dayRecords.forEach((r) => {
    if (r.status === 'present' || r.status === 'late' || r.status === 'half_day') {
      presentSet.add(r.teacherId);
    }
    if (r.status === 'late') {
      lateSet.add(r.teacherId);
    }
    if (r.checkOutTime) {
      checkedOutSet.add(r.teacherId);
    }
  });

  const presentCount = presentSet.size;
  const absentCount = Math.max(0, totalTeachers - presentCount);
  const pendingSyncCount = records.filter((r) => r.syncStatus === 'pending').length;
  const attendanceRate = totalTeachers > 0
    ? Math.round((presentCount / totalTeachers) * 1000) / 10
    : 0;

  return {
    totalTeachers,
    presentCount,
    absentCount,
    lateCount: lateSet.size,
    checkedOutCount: checkedOutSet.size,
    pendingSyncCount,
    attendanceRate,
  };
}

export interface SchoolAttendanceSummary {
  schoolId: string;
  schoolName: string;
  eiin: string;
  category: string;
  totalTeachers: number;
  presentCount: number;
  absentCount: number;
  attendanceRate: number;
  pendingCount: number;
}

export function calculateSchoolSummaries(
  schools: School[],
  teachers: Teacher[],
  records: TeacherAttendanceRecord[],
  targetDate: string
): SchoolAttendanceSummary[] {
  return schools.map((school) => {
    const schoolTeachers = teachers.filter(
      (t) => t.schoolId === school.id && t.status === 'active'
    );
    const totalTeachers = schoolTeachers.length;
    const teacherIds = new Set(schoolTeachers.map((t) => t.id));

    const schoolDayRecords = records.filter(
      (r) => r.date === targetDate && teacherIds.has(r.teacherId)
    );

    const presentTeachers = new Set(
      schoolDayRecords
        .filter((r) => r.status === 'present' || r.status === 'late' || r.status === 'half_day')
        .map((r) => r.teacherId)
    );

    const presentCount = presentTeachers.size;
    const absentCount = Math.max(0, totalTeachers - presentCount);
    const attendanceRate = totalTeachers > 0
      ? Math.round((presentCount / totalTeachers) * 1000) / 10
      : 0;

    const pendingCount = records.filter(
      (r) => r.schoolId === school.id && r.syncStatus === 'pending'
    ).length;

    return {
      schoolId: school.id,
      schoolName: school.name,
      eiin: school.eiin,
      category: school.category,
      totalTeachers,
      presentCount,
      absentCount,
      attendanceRate,
      pendingCount,
    };
  });
}

export function generateAttendanceCsv(records: TeacherAttendanceRecord[]): string {
  const headers = [
    'Record ID',
    'Date',
    'Teacher ID',
    'Teacher Name',
    'School Name',
    'Check-In Time',
    'Check-Out Time',
    'Status',
    'Sync Status',
    'Has GPS Coordinates',
    'Latitude',
    'Longitude',
    'Accuracy (Meters)',
    'Remarks',
  ];

  const escapeCell = (val: unknown): string => {
    if (val === undefined || val === null) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = records.map((r) => [
    escapeCell(r.id),
    escapeCell(r.date),
    escapeCell(r.teacherId),
    escapeCell(r.teacherName),
    escapeCell(r.schoolName),
    escapeCell(r.checkInTime),
    escapeCell(r.checkOutTime || 'N/A'),
    escapeCell(r.status.toUpperCase()),
    escapeCell(r.syncStatus === 'pending' ? 'Pending Local Sync' : 'Synced Locally'),
    escapeCell(r.location ? 'Yes' : 'No'),
    escapeCell(r.location?.latitude ?? ''),
    escapeCell(r.location?.longitude ?? ''),
    escapeCell(r.location?.accuracy ? `${r.location.accuracy}m` : ''),
    escapeCell(r.remarks || ''),
  ]);

  return [headers.join(','), ...rows.map((row) => row.join(','))].join('\r\n');
}

export function generateStudentAttendanceCsv(
  records: StudentAttendanceRecord[],
  students: Student[]
): string {
  const headers = [
    'Record ID',
    'Date',
    'Student ID',
    'Student Name',
    'Class',
    'Status',
    'Remarks',
  ];

  const escapeCell = (val: unknown): string => {
    if (val === undefined || val === null) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const rows = records.map((r) => [
    escapeCell(r.id),
    escapeCell(r.date),
    escapeCell(r.studentId),
    escapeCell(r.studentName),
    escapeCell(r.className),
    escapeCell(r.status.toUpperCase()),
    escapeCell(r.remarks || ''),
  ]);

  return [headers.join(','), ...rows.map((row) => row.join(','))].join('\r\n');
}

export function filterRecords(
  records: TeacherAttendanceRecord[],
  criteria: {
    startDate?: string;
    endDate?: string;
    schoolId?: string;
    teacherId?: string;
    status?: string;
    syncStatus?: 'synced' | 'pending';
    searchQuery?: string;
  }
): TeacherAttendanceRecord[] {
  return records.filter((r) => {
    if (criteria.startDate && r.date < criteria.startDate) return false;
    if (criteria.endDate && r.date > criteria.endDate) return false;
    if (criteria.schoolId && r.schoolId !== criteria.schoolId) return false;
    if (criteria.teacherId && r.teacherId !== criteria.teacherId) return false;
    if (criteria.status && criteria.status !== 'all' && r.status !== criteria.status) return false;
    if (criteria.syncStatus && r.syncStatus !== criteria.syncStatus) return false;

    if (criteria.searchQuery) {
      const q = criteria.searchQuery.toLowerCase();
      const match =
        r.teacherName.toLowerCase().includes(q) ||
        r.teacherId.toLowerCase().includes(q) ||
        r.schoolName.toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });
}
